import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/app/features/auth/components/signUpCard.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=b986c083"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import { Button } from "/src/components/ui/button.tsx";
import { Card, CardContent, CardDescription, CardTitle, CardHeader } from "/src/components/ui/card.tsx";
import { Input } from "/src/components/ui/input.tsx";
import { Label } from "/src/components/ui/label.tsx";
import { useSignUp } from "/src/app/features/auth/hooks/useSignUp.tsx";
import { useAuthToast } from "/src/app/features/auth/hooks/useAuthToasts.tsx";
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=b986c083";
export default function SignUpCard() {
  _s();
  useAuthToast();
  const {
    name,
    email,
    password,
    password_confirmation,
    handleSignUp,
    handleChangeEmail,
    handleChangePassword,
    handleChangeName,
    handleChangePasswordConfirmation,
    errors,
    isSubmitting,
    handleSubmit
  } = useSignUp();
  const nameInvalid = Boolean(errors.name);
  const emailInvalid = Boolean(errors.email);
  const passwordInvalid = Boolean(errors.password);
  const passwordConfirmationInvalid = Boolean(errors.password_confirmation);
  return /* @__PURE__ */ jsxDEV(Card, { children: [
    /* @__PURE__ */ jsxDEV(CardHeader, { children: [
      /* @__PURE__ */ jsxDEV(CardTitle, { className: "text-2xl text-center", children: "アカウント作成" }, void 0, false, {
        fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/auth/components/signUpCard.tsx",
        lineNumber: 34,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(CardDescription, { children: /* @__PURE__ */ jsxDEV("p", { className: "text-center", children: "名前、メールアドレスを入力して登録" }, void 0, false, {
        fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/auth/components/signUpCard.tsx",
        lineNumber: 36,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/auth/components/signUpCard.tsx",
        lineNumber: 35,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/auth/components/signUpCard.tsx",
      lineNumber: 33,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(CardContent, { children: /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSignUp, className: "grid gap-4", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "grid gap-2", children: [
        /* @__PURE__ */ jsxDEV(Label, { htmlFor: "name", children: "Name" }, void 0, false, {
          fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/auth/components/signUpCard.tsx",
          lineNumber: 42,
          columnNumber: 13
        }, this),
        errors.form && /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-red-500", children: errors.form }, void 0, false, {
          fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/auth/components/signUpCard.tsx",
          lineNumber: 43,
          columnNumber: 29
        }, this),
        /* @__PURE__ */ jsxDEV(
          Input,
          {
            id: "name",
            type: "text",
            value: name,
            onChange: (e) => handleChangeName(e.target.value),
            "aria-invalid": nameInvalid,
            className: nameInvalid ? "border-red-500 focus-visible:ring-red-500" : "",
            placeholder: "名前を入力"
          },
          void 0,
          false,
          {
            fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/auth/components/signUpCard.tsx",
            lineNumber: 44,
            columnNumber: 13
          },
          this
        ),
        errors.name && /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-red-500", children: errors.name }, void 0, false, {
          fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/auth/components/signUpCard.tsx",
          lineNumber: 53,
          columnNumber: 29
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/auth/components/signUpCard.tsx",
        lineNumber: 41,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "grid gap-2", children: [
        /* @__PURE__ */ jsxDEV(Label, { htmlFor: "email", children: "Email" }, void 0, false, {
          fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/auth/components/signUpCard.tsx",
          lineNumber: 56,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(
          Input,
          {
            id: "email",
            type: "email",
            value: email,
            onChange: (e) => handleChangeEmail(e.target.value),
            "aria-invalid": emailInvalid,
            className: emailInvalid ? "border-red-500 focus-visible:ring-red-500" : "",
            placeholder: "メールアドレスを入力"
          },
          void 0,
          false,
          {
            fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/auth/components/signUpCard.tsx",
            lineNumber: 57,
            columnNumber: 13
          },
          this
        ),
        errors.email && /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-red-500", children: errors.email }, void 0, false, {
          fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/auth/components/signUpCard.tsx",
          lineNumber: 66,
          columnNumber: 30
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/auth/components/signUpCard.tsx",
        lineNumber: 55,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "grid gap-2", children: [
        /* @__PURE__ */ jsxDEV(Label, { htmlFor: "password", children: "Password" }, void 0, false, {
          fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/auth/components/signUpCard.tsx",
          lineNumber: 69,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(
          Input,
          {
            id: "password",
            type: "password",
            value: password,
            onChange: (e) => handleChangePassword(e.target.value),
            "aria-invalid": passwordInvalid,
            className: passwordInvalid ? "border-red-500 focus-visible:ring-red-500" : "",
            placeholder: "パスワードを入力"
          },
          void 0,
          false,
          {
            fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/auth/components/signUpCard.tsx",
            lineNumber: 70,
            columnNumber: 13
          },
          this
        ),
        errors.password && /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-red-500", children: errors.password }, void 0, false, {
          fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/auth/components/signUpCard.tsx",
          lineNumber: 79,
          columnNumber: 33
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/auth/components/signUpCard.tsx",
        lineNumber: 68,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "grid gap-2", children: [
        /* @__PURE__ */ jsxDEV(Label, { htmlFor: "password_confirmation", children: "Password確認" }, void 0, false, {
          fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/auth/components/signUpCard.tsx",
          lineNumber: 82,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(
          Input,
          {
            id: "password_confirmation",
            type: "password",
            value: password_confirmation,
            onChange: (e) => handleChangePasswordConfirmation(e.target.value),
            "aria-invalid": passwordConfirmationInvalid,
            className: passwordConfirmationInvalid ? "border-red-500 focus-visible:ring-red-500" : "",
            placeholder: "パスワードを再入力"
          },
          void 0,
          false,
          {
            fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/auth/components/signUpCard.tsx",
            lineNumber: 83,
            columnNumber: 13
          },
          this
        ),
        errors.password_confirmation && /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-red-500", children: errors.password_confirmation }, void 0, false, {
          fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/auth/components/signUpCard.tsx",
          lineNumber: 95,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/auth/components/signUpCard.tsx",
        lineNumber: 81,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
        /* @__PURE__ */ jsxDEV(Button, { type: "submit", className: "w-full", disabled: !handleSubmit || isSubmitting, children: isSubmitting ? "アカウント作成中..." : "アカウント作成" }, void 0, false, {
          fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/auth/components/signUpCard.tsx",
          lineNumber: 99,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(
          Link,
          {
            to: "/signIn",
            className: "text-xs text-gray-500 mt-2 ml-auto underline hover:text-sm",
            children: "すでに登録されている方はこちら"
          },
          void 0,
          false,
          {
            fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/auth/components/signUpCard.tsx",
            lineNumber: 102,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/auth/components/signUpCard.tsx",
        lineNumber: 98,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/auth/components/signUpCard.tsx",
      lineNumber: 40,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/auth/components/signUpCard.tsx",
      lineNumber: 39,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/auth/components/signUpCard.tsx",
    lineNumber: 32,
    columnNumber: 5
  }, this);
}
_s(SignUpCard, "ltD6ZNFZEZteEJt/8BQhYfaO5VY=", false, function() {
  return [useAuthToast, useSignUp];
});
_c = SignUpCard;
var _c;
$RefreshReg$(_c, "SignUpCard");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/auth/components/signUpCard.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/auth/components/signUpCard.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/auth/components/signUpCard.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUNROztBQWpDUixTQUFTQSxjQUFjO0FBQ3ZCLFNBQVNDLE1BQU1DLGFBQWFDLGlCQUFpQkMsV0FBV0Msa0JBQWtCO0FBQzFFLFNBQVNDLGFBQWE7QUFDdEIsU0FBU0MsYUFBYTtBQUN0QixTQUFTQyxpQkFBaUI7QUFDMUIsU0FBU0Msb0JBQW9CO0FBQzdCLFNBQVNDLFlBQVk7QUFFckIsd0JBQXdCQyxhQUFhO0FBQUFDLEtBQUE7QUFDbkNILGVBQWE7QUFFYixRQUFNO0FBQUEsSUFDSkk7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsRUFDRixJQUFJaEIsVUFBVTtBQUVkLFFBQU1pQixjQUFjQyxRQUFRSixPQUFPVCxJQUFJO0FBQ3ZDLFFBQU1jLGVBQWVELFFBQVFKLE9BQU9SLEtBQUs7QUFDekMsUUFBTWMsa0JBQWtCRixRQUFRSixPQUFPUCxRQUFRO0FBQy9DLFFBQU1jLDhCQUE4QkgsUUFBUUosT0FBT04scUJBQXFCO0FBQ3hFLFNBQ0UsdUJBQUMsUUFDQztBQUFBLDJCQUFDLGNBQ0M7QUFBQSw2QkFBQyxhQUFVLFdBQVUsd0JBQXVCLHVCQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW1EO0FBQUEsTUFDbkQsdUJBQUMsbUJBQ0MsaUNBQUMsT0FBRSxXQUFVLGVBQWMsaUNBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNEMsS0FEOUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBS0E7QUFBQSxJQUNBLHVCQUFDLGVBQ0MsaUNBQUMsVUFBSyxVQUFVQyxjQUFjLFdBQVUsY0FDdEM7QUFBQSw2QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLCtCQUFDLFNBQU0sU0FBUSxRQUFPLG9CQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBCO0FBQUEsUUFDekJLLE9BQU9RLFFBQVEsdUJBQUMsT0FBRSxXQUFVLHdCQUF3QlIsaUJBQU9RLFFBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUQ7QUFBQSxRQUNqRTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsSUFBRztBQUFBLFlBQ0gsTUFBSztBQUFBLFlBQ0wsT0FBT2pCO0FBQUFBLFlBQ1AsVUFBVSxDQUFDa0IsTUFBTVgsaUJBQWlCVyxFQUFFQyxPQUFPQyxLQUFLO0FBQUEsWUFDaEQsZ0JBQWNSO0FBQUFBLFlBQ2QsV0FBV0EsY0FBYyw4Q0FBOEM7QUFBQSxZQUN2RSxhQUFZO0FBQUE7QUFBQSxVQVBkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU9xQjtBQUFBLFFBRXBCSCxPQUFPVCxRQUFRLHVCQUFDLE9BQUUsV0FBVSx3QkFBd0JTLGlCQUFPVCxRQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWlEO0FBQUEsV0FabkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWFBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLCtCQUFDLFNBQU0sU0FBUSxTQUFRLHFCQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTRCO0FBQUEsUUFDNUI7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLElBQUc7QUFBQSxZQUNILE1BQUs7QUFBQSxZQUNMLE9BQU9DO0FBQUFBLFlBQ1AsVUFBVSxDQUFDaUIsTUFBTWIsa0JBQWtCYSxFQUFFQyxPQUFPQyxLQUFLO0FBQUEsWUFDakQsZ0JBQWNOO0FBQUFBLFlBQ2QsV0FBV0EsZUFBZSw4Q0FBOEM7QUFBQSxZQUN4RSxhQUFZO0FBQUE7QUFBQSxVQVBkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU8wQjtBQUFBLFFBRXpCTCxPQUFPUixTQUFTLHVCQUFDLE9BQUUsV0FBVSx3QkFBd0JRLGlCQUFPUixTQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtEO0FBQUEsV0FYckU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVlBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLCtCQUFDLFNBQU0sU0FBUSxZQUFXLHdCQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtDO0FBQUEsUUFDbEM7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLElBQUc7QUFBQSxZQUNILE1BQUs7QUFBQSxZQUNMLE9BQU9DO0FBQUFBLFlBQ1AsVUFBVSxDQUFDZ0IsTUFBTVoscUJBQXFCWSxFQUFFQyxPQUFPQyxLQUFLO0FBQUEsWUFDcEQsZ0JBQWNMO0FBQUFBLFlBQ2QsV0FBV0Esa0JBQWtCLDhDQUE4QztBQUFBLFlBQzNFLGFBQVk7QUFBQTtBQUFBLFVBUGQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBT3dCO0FBQUEsUUFFdkJOLE9BQU9QLFlBQVksdUJBQUMsT0FBRSxXQUFVLHdCQUF3Qk8saUJBQU9QLFlBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBcUQ7QUFBQSxXQVgzRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBWUE7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEsK0JBQUMsU0FBTSxTQUFRLHlCQUF3QiwwQkFBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpRDtBQUFBLFFBQ2pEO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxJQUFHO0FBQUEsWUFDSCxNQUFLO0FBQUEsWUFDTCxPQUFPQztBQUFBQSxZQUNQLFVBQVUsQ0FBQ2UsTUFBTVYsaUNBQWlDVSxFQUFFQyxPQUFPQyxLQUFLO0FBQUEsWUFDaEUsZ0JBQWNKO0FBQUFBLFlBQ2QsV0FDRUEsOEJBQThCLDhDQUE4QztBQUFBLFlBRTlFLGFBQVk7QUFBQTtBQUFBLFVBVGQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBU3lCO0FBQUEsUUFFeEJQLE9BQU9OLHlCQUNOLHVCQUFDLE9BQUUsV0FBVSx3QkFBd0JNLGlCQUFPTix5QkFBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFrRTtBQUFBLFdBZHRFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFnQkE7QUFBQSxNQUNBLHVCQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLCtCQUFDLFVBQU8sTUFBSyxVQUFTLFdBQVUsVUFBUyxVQUFVLENBQUNRLGdCQUFnQkQsY0FDakVBLHlCQUFlLGdCQUFnQixhQURsQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxJQUFHO0FBQUEsWUFDSCxXQUFVO0FBQUEsWUFBNEQ7QUFBQTtBQUFBLFVBRnhFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUtBO0FBQUEsV0FURjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBVUE7QUFBQSxTQXBFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBcUVBLEtBdEVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F1RUE7QUFBQSxPQTlFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBK0VBO0FBRUo7QUFBQ1gsR0F4R3VCRCxZQUFVO0FBQUEsVUFDaENGLGNBZUlELFNBQVM7QUFBQTtBQUFBMEIsS0FoQlN2QjtBQUFVLElBQUF1QjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiQnV0dG9uIiwiQ2FyZCIsIkNhcmRDb250ZW50IiwiQ2FyZERlc2NyaXB0aW9uIiwiQ2FyZFRpdGxlIiwiQ2FyZEhlYWRlciIsIklucHV0IiwiTGFiZWwiLCJ1c2VTaWduVXAiLCJ1c2VBdXRoVG9hc3QiLCJMaW5rIiwiU2lnblVwQ2FyZCIsIl9zIiwibmFtZSIsImVtYWlsIiwicGFzc3dvcmQiLCJwYXNzd29yZF9jb25maXJtYXRpb24iLCJoYW5kbGVTaWduVXAiLCJoYW5kbGVDaGFuZ2VFbWFpbCIsImhhbmRsZUNoYW5nZVBhc3N3b3JkIiwiaGFuZGxlQ2hhbmdlTmFtZSIsImhhbmRsZUNoYW5nZVBhc3N3b3JkQ29uZmlybWF0aW9uIiwiZXJyb3JzIiwiaXNTdWJtaXR0aW5nIiwiaGFuZGxlU3VibWl0IiwibmFtZUludmFsaWQiLCJCb29sZWFuIiwiZW1haWxJbnZhbGlkIiwicGFzc3dvcmRJbnZhbGlkIiwicGFzc3dvcmRDb25maXJtYXRpb25JbnZhbGlkIiwiZm9ybSIsImUiLCJ0YXJnZXQiLCJ2YWx1ZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbInNpZ25VcENhcmQudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEJ1dHRvbiB9IGZyb20gJ0AvY29tcG9uZW50cy91aS9idXR0b24nO1xuaW1wb3J0IHsgQ2FyZCwgQ2FyZENvbnRlbnQsIENhcmREZXNjcmlwdGlvbiwgQ2FyZFRpdGxlLCBDYXJkSGVhZGVyIH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL2NhcmQnO1xuaW1wb3J0IHsgSW5wdXQgfSBmcm9tICdAL2NvbXBvbmVudHMvdWkvaW5wdXQnO1xuaW1wb3J0IHsgTGFiZWwgfSBmcm9tICdAL2NvbXBvbmVudHMvdWkvbGFiZWwnO1xuaW1wb3J0IHsgdXNlU2lnblVwIH0gZnJvbSAnQC9hcHAvZmVhdHVyZXMvYXV0aC9ob29rcy91c2VTaWduVXAnO1xuaW1wb3J0IHsgdXNlQXV0aFRvYXN0IH0gZnJvbSAnQC9hcHAvZmVhdHVyZXMvYXV0aC9ob29rcy91c2VBdXRoVG9hc3RzJztcbmltcG9ydCB7IExpbmsgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gU2lnblVwQ2FyZCgpIHtcbiAgdXNlQXV0aFRvYXN0KCk7XG4gIC8vIOOCq+OCueOCv+ODoOODleODg+OCr+OBi+OCieeKtuaFi+OBqOmWouaVsOOCkuWPluW+l1xuICBjb25zdCB7XG4gICAgbmFtZSxcbiAgICBlbWFpbCxcbiAgICBwYXNzd29yZCxcbiAgICBwYXNzd29yZF9jb25maXJtYXRpb24sXG4gICAgaGFuZGxlU2lnblVwLFxuICAgIGhhbmRsZUNoYW5nZUVtYWlsLFxuICAgIGhhbmRsZUNoYW5nZVBhc3N3b3JkLFxuICAgIGhhbmRsZUNoYW5nZU5hbWUsXG4gICAgaGFuZGxlQ2hhbmdlUGFzc3dvcmRDb25maXJtYXRpb24sXG4gICAgZXJyb3JzLFxuICAgIGlzU3VibWl0dGluZyxcbiAgICBoYW5kbGVTdWJtaXQsXG4gIH0gPSB1c2VTaWduVXAoKTtcbiAgLy8g44Ko44Op44O844Gu5pyJ54Sh44KS5Yik5a6a44GZ44KL44Gf44KB44Gu44Ot44O844Kr44Or5aSJ5pWw44CCbmFtZeOAgWVtYWls44CBcGFzc3dvcmTjgIFwYXNzd29yZF9jb25maXJtYXRpb27jga7lkITjg5XjgqPjg7zjg6vjg4njga7jgqjjg6njg7zjgYzjgYLjgovjgYvjganjgYbjgYvjgpLliKTlrprjgZfjgabjgIHjgZ3jgozjgZ7jgoxuYW1lSW52YWxpZOOAgWVtYWlsSW52YWxpZOOAgXBhc3N3b3JkSW52YWxpZOOAgXBhc3N3b3JkQ29uZmlybWF0aW9uSW52YWxpZOOBq+ecn+WBveWApOOCkuOCu+ODg+ODiOOBmeOCi+OAglxuICBjb25zdCBuYW1lSW52YWxpZCA9IEJvb2xlYW4oZXJyb3JzLm5hbWUpO1xuICBjb25zdCBlbWFpbEludmFsaWQgPSBCb29sZWFuKGVycm9ycy5lbWFpbCk7XG4gIGNvbnN0IHBhc3N3b3JkSW52YWxpZCA9IEJvb2xlYW4oZXJyb3JzLnBhc3N3b3JkKTtcbiAgY29uc3QgcGFzc3dvcmRDb25maXJtYXRpb25JbnZhbGlkID0gQm9vbGVhbihlcnJvcnMucGFzc3dvcmRfY29uZmlybWF0aW9uKTtcbiAgcmV0dXJuIChcbiAgICA8Q2FyZD5cbiAgICAgIDxDYXJkSGVhZGVyPlxuICAgICAgICA8Q2FyZFRpdGxlIGNsYXNzTmFtZT1cInRleHQtMnhsIHRleHQtY2VudGVyXCI+44Ki44Kr44Km44Oz44OI5L2c5oiQPC9DYXJkVGl0bGU+XG4gICAgICAgIDxDYXJkRGVzY3JpcHRpb24+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXJcIj7lkI3liY3jgIHjg6Hjg7zjg6vjgqLjg4njg6zjgrnjgpLlhaXlipvjgZfjgabnmbvpjLI8L3A+XG4gICAgICAgIDwvQ2FyZERlc2NyaXB0aW9uPlxuICAgICAgPC9DYXJkSGVhZGVyPlxuICAgICAgPENhcmRDb250ZW50PlxuICAgICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlU2lnblVwfSBjbGFzc05hbWU9XCJncmlkIGdhcC00XCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdhcC0yXCI+XG4gICAgICAgICAgICA8TGFiZWwgaHRtbEZvcj1cIm5hbWVcIj5OYW1lPC9MYWJlbD5cbiAgICAgICAgICAgIHtlcnJvcnMuZm9ybSAmJiA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtcmVkLTUwMFwiPntlcnJvcnMuZm9ybX08L3A+fVxuICAgICAgICAgICAgPElucHV0XG4gICAgICAgICAgICAgIGlkPVwibmFtZVwiXG4gICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgdmFsdWU9e25hbWV9XG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlQ2hhbmdlTmFtZShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgIGFyaWEtaW52YWxpZD17bmFtZUludmFsaWR9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT17bmFtZUludmFsaWQgPyAnYm9yZGVyLXJlZC01MDAgZm9jdXMtdmlzaWJsZTpyaW5nLXJlZC01MDAnIDogJyd9XG4gICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwi5ZCN5YmN44KS5YWl5YqbXCJcbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgICB7ZXJyb3JzLm5hbWUgJiYgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LXJlZC01MDBcIj57ZXJyb3JzLm5hbWV9PC9wPn1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ2FwLTJcIj5cbiAgICAgICAgICAgIDxMYWJlbCBodG1sRm9yPVwiZW1haWxcIj5FbWFpbDwvTGFiZWw+XG4gICAgICAgICAgICA8SW5wdXRcbiAgICAgICAgICAgICAgaWQ9XCJlbWFpbFwiXG4gICAgICAgICAgICAgIHR5cGU9XCJlbWFpbFwiXG4gICAgICAgICAgICAgIHZhbHVlPXtlbWFpbH1cbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVDaGFuZ2VFbWFpbChlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgIGFyaWEtaW52YWxpZD17ZW1haWxJbnZhbGlkfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9e2VtYWlsSW52YWxpZCA/ICdib3JkZXItcmVkLTUwMCBmb2N1cy12aXNpYmxlOnJpbmctcmVkLTUwMCcgOiAnJ31cbiAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCLjg6Hjg7zjg6vjgqLjg4njg6zjgrnjgpLlhaXliptcIlxuICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIHtlcnJvcnMuZW1haWwgJiYgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LXJlZC01MDBcIj57ZXJyb3JzLmVtYWlsfTwvcD59XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdhcC0yXCI+XG4gICAgICAgICAgICA8TGFiZWwgaHRtbEZvcj1cInBhc3N3b3JkXCI+UGFzc3dvcmQ8L0xhYmVsPlxuICAgICAgICAgICAgPElucHV0XG4gICAgICAgICAgICAgIGlkPVwicGFzc3dvcmRcIlxuICAgICAgICAgICAgICB0eXBlPVwicGFzc3dvcmRcIlxuICAgICAgICAgICAgICB2YWx1ZT17cGFzc3dvcmR9XG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlQ2hhbmdlUGFzc3dvcmQoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICBhcmlhLWludmFsaWQ9e3Bhc3N3b3JkSW52YWxpZH1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPXtwYXNzd29yZEludmFsaWQgPyAnYm9yZGVyLXJlZC01MDAgZm9jdXMtdmlzaWJsZTpyaW5nLXJlZC01MDAnIDogJyd9XG4gICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwi44OR44K544Ov44O844OJ44KS5YWl5YqbXCJcbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgICB7ZXJyb3JzLnBhc3N3b3JkICYmIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1yZWQtNTAwXCI+e2Vycm9ycy5wYXNzd29yZH08L3A+fVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBnYXAtMlwiPlxuICAgICAgICAgICAgPExhYmVsIGh0bWxGb3I9XCJwYXNzd29yZF9jb25maXJtYXRpb25cIj5QYXNzd29yZOeiuuiqjTwvTGFiZWw+XG4gICAgICAgICAgICA8SW5wdXRcbiAgICAgICAgICAgICAgaWQ9XCJwYXNzd29yZF9jb25maXJtYXRpb25cIlxuICAgICAgICAgICAgICB0eXBlPVwicGFzc3dvcmRcIlxuICAgICAgICAgICAgICB2YWx1ZT17cGFzc3dvcmRfY29uZmlybWF0aW9ufVxuICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZUNoYW5nZVBhc3N3b3JkQ29uZmlybWF0aW9uKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgYXJpYS1pbnZhbGlkPXtwYXNzd29yZENvbmZpcm1hdGlvbkludmFsaWR9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT17XG4gICAgICAgICAgICAgICAgcGFzc3dvcmRDb25maXJtYXRpb25JbnZhbGlkID8gJ2JvcmRlci1yZWQtNTAwIGZvY3VzLXZpc2libGU6cmluZy1yZWQtNTAwJyA6ICcnXG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCLjg5Hjgrnjg6/jg7zjg4njgpLlho3lhaXliptcIlxuICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIHtlcnJvcnMucGFzc3dvcmRfY29uZmlybWF0aW9uICYmIChcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LXJlZC01MDBcIj57ZXJyb3JzLnBhc3N3b3JkX2NvbmZpcm1hdGlvbn08L3A+XG4gICAgICAgICAgICApfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbFwiPlxuICAgICAgICAgICAgPEJ1dHRvbiB0eXBlPVwic3VibWl0XCIgY2xhc3NOYW1lPVwidy1mdWxsXCIgZGlzYWJsZWQ9eyFoYW5kbGVTdWJtaXQgfHwgaXNTdWJtaXR0aW5nfT5cbiAgICAgICAgICAgICAge2lzU3VibWl0dGluZyA/ICfjgqLjgqvjgqbjg7Pjg4jkvZzmiJDkuK0uLi4nIDogJ+OCouOCq+OCpuODs+ODiOS9nOaIkCd9XG4gICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgIDxMaW5rXG4gICAgICAgICAgICAgIHRvPVwiL3NpZ25JblwiXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTUwMCBtdC0yIG1sLWF1dG8gdW5kZXJsaW5lIGhvdmVyOnRleHQtc21cIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICDjgZnjgafjgavnmbvpjLLjgZXjgozjgabjgYTjgovmlrnjga/jgZPjgaHjgolcbiAgICAgICAgICAgIDwvTGluaz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9mb3JtPlxuICAgICAgPC9DYXJkQ29udGVudD5cbiAgICA8L0NhcmQ+XG4gICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9pbm91ZXl1dWppL0NvbG9yTWlycm9yX1JlL2Zyb250L0FwcF9mcm9udC9zcmMvYXBwL2ZlYXR1cmVzL2F1dGgvY29tcG9uZW50cy9zaWduVXBDYXJkLnRzeCJ9