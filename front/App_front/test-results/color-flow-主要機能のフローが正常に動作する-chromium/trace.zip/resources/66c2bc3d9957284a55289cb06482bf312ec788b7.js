import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/layout/header.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=b986c083"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import { useAuthStore } from "/src/app/store/useAuthStore.ts";
import { signOut } from "/src/app/features/auth/api/auth.ts";
export const Header = () => {
  _s();
  const user = useAuthStore((state) => state.user);
  const logout = useAuthStore((state) => state.logout);
  const authStatus = useAuthStore((state) => state.authStatus);
  const isAuthenticated = authStatus === "authenticated";
  const currentUserName = isAuthenticated ? user?.name : "Guest";
  const handleLogout = async () => {
    try {
      await signOut();
    } finally {
      logout("logged_out");
    }
  };
  return /* @__PURE__ */ jsxDEV("header", { className: "bg-gradient w-full px-6 py-4 mx-auto", children: /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col items-center justify-center sm:flex-row sm:justify-between ", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "header-text", children: /* @__PURE__ */ jsxDEV("p", { className: "text-3xl font-bold  text-gray-500", children: "Color Mirror_Re" }, void 0, false, {
      fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/components/layout/header.tsx",
      lineNumber: 26,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/components/layout/header.tsx",
      lineNumber: 25,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "header-content sm:flex sm:flex-col sm:items-center sm:gap-2 gap-4 flex flex-row-reverse items-center justify-around my-2", children: [
      isAuthenticated && /* @__PURE__ */ jsxDEV("div", { className: "", children: /* @__PURE__ */ jsxDEV(
        "button",
        {
          onClick: handleLogout,
          className: "bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded-2xl",
          children: "ログアウト"
        },
        void 0,
        false,
        {
          fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/components/layout/header.tsx",
          lineNumber: 32,
          columnNumber: 15
        },
        this
      ) }, void 0, false, {
        fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/components/layout/header.tsx",
        lineNumber: 31,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "text-red-500 text-md underline font-bold text-right", children: isAuthenticated ? `ログイン中のユーザー:  ${currentUserName} さん` : "ゲストさん ログインをお願いします." }, void 0, false, {
        fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/components/layout/header.tsx",
        lineNumber: 40,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/components/layout/header.tsx",
      lineNumber: 29,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/components/layout/header.tsx",
    lineNumber: 24,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/components/layout/header.tsx",
    lineNumber: 23,
    columnNumber: 5
  }, this);
};
_s(Header, "+gzpUsDM7u7p+lGsdsgJqvrajWI=", false, function() {
  return [useAuthStore, useAuthStore, useAuthStore];
});
_c = Header;
var _c;
$RefreshReg$(_c, "Header");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/components/layout/header.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/components/layout/header.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/components/layout/header.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBeUJVOztBQXpCVixTQUFTQSxvQkFBb0I7QUFDN0IsU0FBU0MsZUFBZTtBQUVqQixhQUFNQyxTQUFTQSxNQUFNO0FBQUFDLEtBQUE7QUFFMUIsUUFBTUMsT0FBT0osYUFBYSxDQUFDSyxVQUFVQSxNQUFNRCxJQUFJO0FBQy9DLFFBQU1FLFNBQVNOLGFBQWEsQ0FBQ0ssVUFBVUEsTUFBTUMsTUFBTTtBQUNuRCxRQUFNQyxhQUFhUCxhQUFhLENBQUNLLFVBQVVBLE1BQU1FLFVBQVU7QUFHM0QsUUFBTUMsa0JBQWtCRCxlQUFlO0FBQ3ZDLFFBQU1FLGtCQUFrQkQsa0JBQWtCSixNQUFNTSxPQUFPO0FBRXZELFFBQU1DLGVBQWUsWUFBWTtBQUMvQixRQUFJO0FBQ0YsWUFBTVYsUUFBUTtBQUFBLElBQ2hCLFVBQUM7QUFDQ0ssYUFBTyxZQUFZO0FBQUEsSUFDckI7QUFBQSxFQUNGO0FBRUEsU0FDRSx1QkFBQyxZQUFPLFdBQVUsd0NBQ2hCLGlDQUFDLFNBQUksV0FBVSw2RUFDYjtBQUFBLDJCQUFDLFNBQUksV0FBVSxlQUNiLGlDQUFDLE9BQUUsV0FBVSxxQ0FBb0MsK0JBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBZ0UsS0FEbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsSUFFQSx1QkFBQyxTQUFJLFdBQVUsNEhBQ1pFO0FBQUFBLHlCQUNDLHVCQUFDLFNBQUksV0FBVSxJQUNiO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxTQUFTRztBQUFBQSxVQUNULFdBQVU7QUFBQSxVQUF3RTtBQUFBO0FBQUEsUUFGcEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BS0EsS0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBT0E7QUFBQSxNQUVGLHVCQUFDLFNBQUksV0FBVSx1REFDWkgsNEJBQ0csZ0JBQWdCQyxlQUFlLFFBQy9CLHdCQUhOO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFJQTtBQUFBLFNBZkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWdCQTtBQUFBLE9BckJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FzQkEsS0F2QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXdCQTtBQUVKO0FBQUVOLEdBN0NXRCxRQUFNO0FBQUEsVUFFSkYsY0FDRUEsY0FDSUEsWUFBWTtBQUFBO0FBQUFZLEtBSnBCVjtBQUFNLElBQUFVO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VBdXRoU3RvcmUiLCJzaWduT3V0IiwiSGVhZGVyIiwiX3MiLCJ1c2VyIiwic3RhdGUiLCJsb2dvdXQiLCJhdXRoU3RhdHVzIiwiaXNBdXRoZW50aWNhdGVkIiwiY3VycmVudFVzZXJOYW1lIiwibmFtZSIsImhhbmRsZUxvZ291dCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbImhlYWRlci50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlQXV0aFN0b3JlIH0gZnJvbSAnQC9hcHAvc3RvcmUvdXNlQXV0aFN0b3JlJztcbmltcG9ydCB7IHNpZ25PdXQgfSBmcm9tICdAL2FwcC9mZWF0dXJlcy9hdXRoL2FwaS9hdXRoJztcblxuZXhwb3J0IGNvbnN0IEhlYWRlciA9ICgpID0+IHtcbiAgLy8g6KqN6Ki854q25oWL44Go44Om44O844K244O85oOF5aCx44KSenVzdGFuZOOBi+OCieWPluW+l1xuICBjb25zdCB1c2VyID0gdXNlQXV0aFN0b3JlKChzdGF0ZSkgPT4gc3RhdGUudXNlcik7XG4gIGNvbnN0IGxvZ291dCA9IHVzZUF1dGhTdG9yZSgoc3RhdGUpID0+IHN0YXRlLmxvZ291dCk7XG4gIGNvbnN0IGF1dGhTdGF0dXMgPSB1c2VBdXRoU3RvcmUoKHN0YXRlKSA9PiBzdGF0ZS5hdXRoU3RhdHVzKTtcblxuICAvLyDoqo3oqLznirbmhYvjgavln7rjgaXjgYTjgabooajnpLrlhoXlrrnjgpLliIfjgormm7/jgYjjgotcbiAgY29uc3QgaXNBdXRoZW50aWNhdGVkID0gYXV0aFN0YXR1cyA9PT0gJ2F1dGhlbnRpY2F0ZWQnO1xuICBjb25zdCBjdXJyZW50VXNlck5hbWUgPSBpc0F1dGhlbnRpY2F0ZWQgPyB1c2VyPy5uYW1lIDogJ0d1ZXN0JztcbiAgLy8g44Ot44Kw44Ki44Km44OI5Yem55CGXG4gIGNvbnN0IGhhbmRsZUxvZ291dCA9IGFzeW5jICgpID0+IHtcbiAgICB0cnkge1xuICAgICAgYXdhaXQgc2lnbk91dCgpOyAvLyDjgrXjg7zjg5Djg7zlgbTjga7jg63jgrDjgqLjgqbjg4hBUEnjgpLlkbzjgbPlh7rjgZlcbiAgICB9IGZpbmFsbHkge1xuICAgICAgbG9nb3V0KCdsb2dnZWRfb3V0Jyk7IC8vIFp1c3RhbmTjga7nirbmhYvjgpLmm7TmlrDjgZfjgabjg63jgrDjgqLjgqbjg4jnirbmhYvjgavjgZnjgotcbiAgICB9XG4gIH07XG5cbiAgcmV0dXJuIChcbiAgICA8aGVhZGVyIGNsYXNzTmFtZT1cImJnLWdyYWRpZW50IHctZnVsbCBweC02IHB5LTQgbXgtYXV0b1wiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBzbTpmbGV4LXJvdyBzbTpqdXN0aWZ5LWJldHdlZW4gXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaGVhZGVyLXRleHRcIj5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LTN4bCBmb250LWJvbGQgIHRleHQtZ3JheS01MDBcIj5Db2xvciBNaXJyb3JfUmU8L3A+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaGVhZGVyLWNvbnRlbnQgc206ZmxleCBzbTpmbGV4LWNvbCBzbTppdGVtcy1jZW50ZXIgc206Z2FwLTIgZ2FwLTQgZmxleCBmbGV4LXJvdy1yZXZlcnNlIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWFyb3VuZCBteS0yXCI+XG4gICAgICAgICAge2lzQXV0aGVudGljYXRlZCAmJiAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIlwiPlxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlTG9nb3V0fVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXJlZC01MDAgaG92ZXI6YmctcmVkLTcwMCB0ZXh0LXdoaXRlIGZvbnQtYm9sZCBweS0yIHB4LTQgcm91bmRlZC0yeGxcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAg44Ot44Kw44Ki44Km44OIXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKX1cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtcmVkLTUwMCB0ZXh0LW1kIHVuZGVybGluZSBmb250LWJvbGQgdGV4dC1yaWdodFwiPlxuICAgICAgICAgICAge2lzQXV0aGVudGljYXRlZFxuICAgICAgICAgICAgICA/IGDjg63jgrDjgqTjg7PkuK3jga7jg6bjg7zjgrbjg7w6ICAke2N1cnJlbnRVc2VyTmFtZX0g44GV44KTYFxuICAgICAgICAgICAgICA6ICfjgrLjgrnjg4jjgZXjgpMg44Ot44Kw44Kk44Oz44KS44GK6aGY44GE44GX44G+44GZLid9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgPC9oZWFkZXI+XG4gICk7XG59O1xuIl0sImZpbGUiOiIvVXNlcnMvaW5vdWV5dXVqaS9Db2xvck1pcnJvcl9SZS9mcm9udC9BcHBfZnJvbnQvc3JjL2NvbXBvbmVudHMvbGF5b3V0L2hlYWRlci50c3gifQ==