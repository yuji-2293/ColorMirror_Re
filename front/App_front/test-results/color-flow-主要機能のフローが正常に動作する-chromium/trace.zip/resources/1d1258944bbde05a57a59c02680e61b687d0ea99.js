import {
  AxiosHeaders
} from "/node_modules/.vite/deps/chunk-2OGMTKOI.js?v=b986c083";
import "/node_modules/.vite/deps/chunk-G3PMV62Z.js?v=b986c083";

// node_modules/.pnpm/tslib@2.8.1/node_modules/tslib/tslib.es6.mjs
var __assign = function() {
  __assign = Object.assign || function __assign2(t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
    }
    return t;
  };
  return __assign.apply(this, arguments);
};
function __values(o) {
  var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
  if (m) return m.call(o);
  if (o && typeof o.length === "number") return {
    next: function() {
      if (o && i >= o.length) o = void 0;
      return { value: o && o[i++], done: !o };
    }
  };
  throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
}
function __read(o, n) {
  var m = typeof Symbol === "function" && o[Symbol.iterator];
  if (!m) return o;
  var i = m.call(o), r, ar = [], e;
  try {
    while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
  } catch (error) {
    e = { error };
  } finally {
    try {
      if (r && !r.done && (m = i["return"])) m.call(i);
    } finally {
      if (e) throw e.error;
    }
  }
  return ar;
}
function __spreadArray(to, from, pack) {
  if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
    if (ar || !(i in from)) {
      if (!ar) ar = Array.prototype.slice.call(from, 0, i);
      ar[i] = from[i];
    }
  }
  return to.concat(ar || Array.prototype.slice.call(from));
}

// node_modules/.pnpm/lower-case@2.0.2/node_modules/lower-case/dist.es2015/index.js
function lowerCase(str) {
  return str.toLowerCase();
}

// node_modules/.pnpm/no-case@3.0.4/node_modules/no-case/dist.es2015/index.js
var DEFAULT_SPLIT_REGEXP = [/([a-z0-9])([A-Z])/g, /([A-Z])([A-Z][a-z])/g];
var DEFAULT_STRIP_REGEXP = /[^A-Z0-9]+/gi;
function noCase(input, options) {
  if (options === void 0) {
    options = {};
  }
  var _a = options.splitRegexp, splitRegexp = _a === void 0 ? DEFAULT_SPLIT_REGEXP : _a, _b = options.stripRegexp, stripRegexp = _b === void 0 ? DEFAULT_STRIP_REGEXP : _b, _c = options.transform, transform = _c === void 0 ? lowerCase : _c, _d = options.delimiter, delimiter = _d === void 0 ? " " : _d;
  var result = replace(replace(input, splitRegexp, "$1\0$2"), stripRegexp, "\0");
  var start = 0;
  var end = result.length;
  while (result.charAt(start) === "\0")
    start++;
  while (result.charAt(end - 1) === "\0")
    end--;
  return result.slice(start, end).split("\0").map(transform).join(delimiter);
}
function replace(input, re, value) {
  if (re instanceof RegExp)
    return input.replace(re, value);
  return re.reduce(function(input2, re2) {
    return input2.replace(re2, value);
  }, input);
}

// node_modules/.pnpm/pascal-case@3.1.2/node_modules/pascal-case/dist.es2015/index.js
function pascalCaseTransform(input, index) {
  var firstChar = input.charAt(0);
  var lowerChars = input.substr(1).toLowerCase();
  if (index > 0 && firstChar >= "0" && firstChar <= "9") {
    return "_" + firstChar + lowerChars;
  }
  return "" + firstChar.toUpperCase() + lowerChars;
}
function pascalCase(input, options) {
  if (options === void 0) {
    options = {};
  }
  return noCase(input, __assign({ delimiter: "", transform: pascalCaseTransform }, options));
}

// node_modules/.pnpm/camel-case@4.1.2/node_modules/camel-case/dist.es2015/index.js
function camelCaseTransform(input, index) {
  if (index === 0)
    return input.toLowerCase();
  return pascalCaseTransform(input, index);
}
function camelCase(input, options) {
  if (options === void 0) {
    options = {};
  }
  return pascalCase(input, __assign({ transform: camelCaseTransform }, options));
}

// node_modules/.pnpm/dot-case@3.0.4/node_modules/dot-case/dist.es2015/index.js
function dotCase(input, options) {
  if (options === void 0) {
    options = {};
  }
  return noCase(input, __assign({ delimiter: "." }, options));
}

// node_modules/.pnpm/snake-case@3.0.4/node_modules/snake-case/dist.es2015/index.js
function snakeCase(input, options) {
  if (options === void 0) {
    options = {};
  }
  return dotCase(input, __assign({ delimiter: "_" }, options));
}

// node_modules/.pnpm/upper-case-first@2.0.2/node_modules/upper-case-first/dist.es2015/index.js
function upperCaseFirst(input) {
  return input.charAt(0).toUpperCase() + input.substr(1);
}

// node_modules/.pnpm/capital-case@1.0.4/node_modules/capital-case/dist.es2015/index.js
function capitalCaseTransform(input) {
  return upperCaseFirst(input.toLowerCase());
}
function capitalCase(input, options) {
  if (options === void 0) {
    options = {};
  }
  return noCase(input, __assign({ delimiter: " ", transform: capitalCaseTransform }, options));
}

// node_modules/.pnpm/header-case@2.0.4/node_modules/header-case/dist.es2015/index.js
function headerCase(input, options) {
  if (options === void 0) {
    options = {};
  }
  return capitalCase(input, __assign({ delimiter: "-" }, options));
}

// node_modules/.pnpm/axios-case-converter@1.1.1_axios@1.13.2/node_modules/axios-case-converter/es/decorators.js
var applyCaseOptions = function(fn, defaultOptions) {
  return function(input, options) {
    return fn(input, __assign(__assign({}, defaultOptions), options));
  };
};
var preserveSpecificKeys = function(fn, keys) {
  var condition = typeof keys === "function" ? keys : function(input) {
    return keys.includes(input);
  };
  return function(input, options) {
    return condition(input, options) ? input : fn(input, options);
  };
};

// node_modules/.pnpm/axios-case-converter@1.1.1_axios@1.13.2/node_modules/axios-case-converter/es/util.js
var isURLSearchParams = function(value) {
  return typeof URLSearchParams !== "undefined" && value instanceof URLSearchParams;
};
var isFormData = function(value) {
  return typeof FormData !== "undefined" && value instanceof FormData;
};
var isPlainObject = function(value) {
  if (value == null) {
    return false;
  }
  var proto = Object.getPrototypeOf(value);
  return proto === null || proto === Object.prototype;
};
var isTransformable = function(value) {
  return Array.isArray(value) || isPlainObject(value) || isFormData(value) || isURLSearchParams(value);
};
var isAxiosHeaders = function(value) {
  if (value == null) {
    return false;
  }
  return value instanceof AxiosHeaders;
};

// node_modules/.pnpm/axios-case-converter@1.1.1_axios@1.13.2/node_modules/axios-case-converter/es/transformers.js
var caseFunctions = {
  snake: snakeCase,
  camel: camelCase,
  header: headerCase
};
var transformObjectUsingCallbackRecursive = function(data, fn, overwrite) {
  var e_1, _a, e_2, _b, e_3, _c;
  if (!isTransformable(data)) {
    return data;
  }
  if ((isFormData(data) || isURLSearchParams(data)) && (!data.entries || overwrite && !data.delete)) {
    var type = isFormData(data) ? "FormData" : "URLSearchParams";
    var polyfill = isFormData(data) ? "https://github.com/jimmywarting/FormData" : "https://github.com/jerrybendy/url-search-params-polyfill";
    if (typeof navigator !== "undefined" && navigator.product === "ReactNative") {
      console.warn("Be careful that ".concat(type, " cannot be transformed on React Native. If you intentionally implemented, ignore this kind of warning: https://facebook.github.io/react-native/docs/debugging.html"));
    } else {
      if (!data.entries) {
        console.warn("You must use polyfill of ".concat(type, ".prototype.entries() on Internet Explorer or Safari: ").concat(polyfill));
      }
      if (overwrite && !data.delete) {
        console.warn("You must use polyfill of ".concat(type, ".prototype.delete() on Internet Explorer or Safari: ").concat(polyfill));
      }
    }
    return data;
  }
  var prototype = Object.getPrototypeOf(data);
  var store = overwrite ? data : !prototype ? /* @__PURE__ */ Object.create(null) : new prototype.constructor();
  var series;
  if (isFormData(data) || isURLSearchParams(data)) {
    series = data.entries();
    if (overwrite) {
      series = __spreadArray([], __read(series), false);
      try {
        for (var series_1 = __values(series), series_1_1 = series_1.next(); !series_1_1.done; series_1_1 = series_1.next()) {
          var _d = __read(series_1_1.value, 1), key = _d[0];
          data.delete(key);
        }
      } catch (e_1_1) {
        e_1 = { error: e_1_1 };
      } finally {
        try {
          if (series_1_1 && !series_1_1.done && (_a = series_1.return)) _a.call(series_1);
        } finally {
          if (e_1) throw e_1.error;
        }
      }
    }
  } else {
    series = Object.entries(data);
    if (overwrite && !Array.isArray(data)) {
      try {
        for (var series_2 = __values(series), series_2_1 = series_2.next(); !series_2_1.done; series_2_1 = series_2.next()) {
          var _e = __read(series_2_1.value, 1), key = _e[0];
          delete data[key];
        }
      } catch (e_2_1) {
        e_2 = { error: e_2_1 };
      } finally {
        try {
          if (series_2_1 && !series_2_1.done && (_b = series_2.return)) _b.call(series_2);
        } finally {
          if (e_2) throw e_2.error;
        }
      }
    }
  }
  try {
    for (var series_3 = __values(series), series_3_1 = series_3.next(); !series_3_1.done; series_3_1 = series_3.next()) {
      var _f = __read(series_3_1.value, 2), key = _f[0], value = _f[1];
      if (isFormData(store) || isURLSearchParams(store)) {
        store.append(fn(key), value);
      } else if (key !== "__proto__") {
        store[Array.isArray(data) ? Number(key) : fn("".concat(key))] = transformObjectUsingCallbackRecursive(value, fn, overwrite);
      }
    }
  } catch (e_3_1) {
    e_3 = { error: e_3_1 };
  } finally {
    try {
      if (series_3_1 && !series_3_1.done && (_c = series_3.return)) _c.call(series_3);
    } finally {
      if (e_3) throw e_3.error;
    }
  }
  return store;
};
var transformObjectUsingCallback = function(data, fn, options) {
  fn = applyCaseOptions(fn, __assign({ stripRegexp: /[^A-Z0-9[\]]+/gi }, options === null || options === void 0 ? void 0 : options.caseOptions));
  if (options === null || options === void 0 ? void 0 : options.preservedKeys) {
    fn = preserveSpecificKeys(fn, options.preservedKeys);
  }
  return transformObjectUsingCallbackRecursive(data, fn, (options === null || options === void 0 ? void 0 : options.overwrite) || false);
};
var createObjectTransformer = function(fn) {
  return function(data, options) {
    return transformObjectUsingCallback(data, fn, options);
  };
};
var createObjectTransformerOf = function(functionName, options) {
  return createObjectTransformer((options === null || options === void 0 ? void 0 : options[functionName]) || caseFunctions[functionName]);
};
var createObjectTransformers = function(options) {
  var e_4, _a;
  var functionNames = Object.keys(caseFunctions);
  var objectTransformers = {};
  try {
    for (var functionNames_1 = __values(functionNames), functionNames_1_1 = functionNames_1.next(); !functionNames_1_1.done; functionNames_1_1 = functionNames_1.next()) {
      var functionName = functionNames_1_1.value;
      objectTransformers[functionName] = createObjectTransformerOf(functionName, options);
    }
  } catch (e_4_1) {
    e_4 = { error: e_4_1 };
  } finally {
    try {
      if (functionNames_1_1 && !functionNames_1_1.done && (_a = functionNames_1.return)) _a.call(functionNames_1);
    } finally {
      if (e_4) throw e_4.error;
    }
  }
  return objectTransformers;
};

// node_modules/.pnpm/axios-case-converter@1.1.1_axios@1.13.2/node_modules/axios-case-converter/es/middleware.js
var createSnakeParamsInterceptor = function(options) {
  var snake = createObjectTransformers(options === null || options === void 0 ? void 0 : options.caseFunctions).snake;
  return function(config) {
    if (!(options === null || options === void 0 ? void 0 : options.ignoreParams) && config.params) {
      config.params = snake(config.params, options);
    }
    return config;
  };
};
var createSnakeRequestTransformer = function(options) {
  var _a = createObjectTransformers(options === null || options === void 0 ? void 0 : options.caseFunctions), snake = _a.snake, header = _a.header;
  return function(data, headers) {
    overwriteHeadersOrNoop(headers, header, options, [
      "common",
      "delete",
      "get",
      "head",
      "post",
      "put",
      "patch"
    ]);
    return snake(data, options);
  };
};
var createCamelResponseTransformer = function(options) {
  var camel = createObjectTransformers(options === null || options === void 0 ? void 0 : options.caseFunctions).camel;
  return function(data, headers) {
    overwriteHeadersOrNoop(headers, camel, options);
    return camel(data, options);
  };
};
var overwriteHeadersOrNoop = function(headers, fn, options, excludedKeys) {
  var e_1, _a, _b, _c;
  if ((options === null || options === void 0 ? void 0 : options.ignoreHeaders) || !isPlainObject(headers) && !isAxiosHeaders(headers)) {
    return;
  }
  try {
    for (var _d = __values(Object.entries(headers)), _e = _d.next(); !_e.done; _e = _d.next()) {
      var _f = __read(_e.value, 2), key = _f[0], value = _f[1];
      fn(value, __assign({ overwrite: true }, options));
      if ((excludedKeys || []).includes(key)) {
        continue;
      }
      if (isAxiosHeaders(headers)) {
        headers.delete(key);
        headers.set(Object.keys(fn((_b = {}, _b[key] = null, _b), options))[0], value, true);
      } else {
        delete headers[key];
        headers[Object.keys(fn((_c = {}, _c[key] = null, _c), options))[0]] = value;
      }
    }
  } catch (e_1_1) {
    e_1 = { error: e_1_1 };
  } finally {
    try {
      if (_e && !_e.done && (_a = _d.return)) _a.call(_d);
    } finally {
      if (e_1) throw e_1.error;
    }
  }
};
var applyCaseMiddleware = function(axios, options) {
  var _a, _b, _c;
  axios.defaults.transformRequest = __spreadArray([
    ((_a = options === null || options === void 0 ? void 0 : options.caseMiddleware) === null || _a === void 0 ? void 0 : _a.requestTransformer) || createSnakeRequestTransformer(options)
  ], __read(Array.isArray(axios.defaults.transformRequest) ? axios.defaults.transformRequest : axios.defaults.transformRequest !== void 0 ? [axios.defaults.transformRequest] : []), false);
  axios.defaults.transformResponse = __spreadArray(__spreadArray([], __read(Array.isArray(axios.defaults.transformResponse) ? axios.defaults.transformResponse : axios.defaults.transformResponse !== void 0 ? [axios.defaults.transformResponse] : []), false), [
    ((_b = options === null || options === void 0 ? void 0 : options.caseMiddleware) === null || _b === void 0 ? void 0 : _b.responseTransformer) || createCamelResponseTransformer(options)
  ], false);
  axios.interceptors.request.use(((_c = options === null || options === void 0 ? void 0 : options.caseMiddleware) === null || _c === void 0 ? void 0 : _c.requestInterceptor) || createSnakeParamsInterceptor(options));
  return axios;
};

// node_modules/.pnpm/axios-case-converter@1.1.1_axios@1.13.2/node_modules/axios-case-converter/es/index.js
var es_default = applyCaseMiddleware;
export {
  es_default as default
};
//# sourceMappingURL=axios-case-converter.js.map
