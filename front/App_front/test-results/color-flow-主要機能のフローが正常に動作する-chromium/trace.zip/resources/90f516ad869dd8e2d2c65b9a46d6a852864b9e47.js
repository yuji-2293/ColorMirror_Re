import.meta.env = {"BASE_URL": "/", "DEV": true, "MODE": "development", "PROD": false, "SSR": false, "VITE_API_BASE_URL": "http://localhost:3000/api/v1"};import axios from "/node_modules/.vite/deps/axios.js?v=b986c083";
import applyCaseMiddleware from "/node_modules/.vite/deps/axios-case-converter.js?v=b986c083";
import Cookies from "/node_modules/.vite/deps/js-cookie.js?v=b986c083";
import { useAuthStore } from "/src/app/store/useAuthStore.ts";
const baseURL = import.meta.env.VITE_API_BASE_URL || "";
const headers = {
  "Content-Type": "application/json"
};
const options = {
  ignoreHeaders: true
  // レスポンスヘッダーは変換しない
};
export const ApiClient = applyCaseMiddleware(axios.create({ baseURL, headers }), options);
ApiClient.interceptors.request.use((config) => {
  const accessToken = Cookies.get("_access-token");
  const clientId = Cookies.get("_client");
  const uid = Cookies.get("_uid");
  console.log("request cookie", {
    accessToken,
    clientId,
    uid
  });
  if (accessToken && clientId && uid) {
    config.headers["access-token"] = accessToken;
    config.headers["client"] = clientId;
    config.headers["uid"] = uid;
  }
  return config;
});
ApiClient.interceptors.response.use(
  //client.interceptors.responseの場合は受信直後に割り込みたい処理が書けます
  (response) => {
    const accessToken = response.headers["access-token"];
    const clientId = response.headers["client"];
    const uid = response.headers["uid"];
    if (accessToken && clientId && uid) {
      Cookies.set("_access-token", accessToken);
      Cookies.set("_client", clientId);
      Cookies.set("_uid", uid);
    }
    return response;
  },
  (error) => {
    console.log(error);
    switch (error.response?.status) {
      case 401:
        useAuthStore.getState().logout();
        Cookies.remove(`_access-token`);
        Cookies.remove(`_client`);
        Cookies.remove(`_uid`);
        break;
      case 404:
        break;
      default:
    }
    const errorMessage = (error.response?.data?.message || "").split(",");
    throw new Error(errorMessage);
  }
);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFwaUNsaWVudC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgYXhpb3MgZnJvbSAnYXhpb3MnO1xuaW1wb3J0IGFwcGx5Q2FzZU1pZGRsZXdhcmUgZnJvbSAnYXhpb3MtY2FzZS1jb252ZXJ0ZXInOyAvLyBheGlvc+OBruODrOOCueODneODs+OCueODh+ODvOOCv+OBruOCreODvOOCkuOCreODo+ODoeODq+OCseODvOOCueOBq+WkieaPm+OBmeOCi+ODn+ODieODq+OCpuOCp+OColxuaW1wb3J0IENvb2tpZXMgZnJvbSAnanMtY29va2llJztcbmltcG9ydCB7IHVzZUF1dGhTdG9yZSB9IGZyb20gJ0AvYXBwL3N0b3JlL3VzZUF1dGhTdG9yZSc7XG5cbmNvbnN0IGJhc2VVUkwgPSBpbXBvcnQubWV0YS5lbnYuVklURV9BUElfQkFTRV9VUkwgfHwgJyc7XG5cbmNvbnN0IGhlYWRlcnMgPSB7XG4gICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicsXG59O1xuY29uc3Qgb3B0aW9ucyA9IHtcbiAgaWdub3JlSGVhZGVyczogdHJ1ZSwgLy8g44Os44K544Od44Oz44K544OY44OD44OA44O844Gv5aSJ5o+b44GX44Gq44GEXG59O1xuXG5leHBvcnQgY29uc3QgQXBpQ2xpZW50ID0gYXBwbHlDYXNlTWlkZGxld2FyZShheGlvcy5jcmVhdGUoeyBiYXNlVVJMLCBoZWFkZXJzIH0pLCBvcHRpb25zKTsgLy9zbmFrZV9jYXNlIOKHlCBjYW1lbENhc2VcblxuLy8g5LiK44Gn55Sf5oiQ44GX44GfYXhpb3PjgqTjg7Pjgrnjgr/jg7PjgrnjgasgLnVzZSjmiJDlip/mmYLplqLmlbAsIOWkseaVl+aZgumWouaVsCnjgajjgYTjgYblvaLjgafjgqTjg7Pjgr/jg7zjgrvjg5fjgr/jg7zjgZnjgovplqLmlbDvvIjlibLjgorovrzjgpPjgaflh6bnkIbjgpLmjJ/jgoDvvInjgpLnmbvpjLLjgZnjgotcbkFwaUNsaWVudC5pbnRlcmNlcHRvcnMucmVxdWVzdC51c2UoKGNvbmZpZykgPT4ge1xuICAvLyBjb25maWfjga/jg6rjgq/jgqjjgrnjg4jmg4XloLHjgYzlhaXjgaPjgabjgYTjgovjgqrjg5bjgrjjgqfjgq/jg4jvvIg9IGF4aW9z44GM5oyB44GkQXhpb3NSZXF1ZXN0Q29uZmlnIOOBqOOBhOOBhuioreWumuOCquODluOCuOOCp+OCr+ODiOOAgu+8iVxuICAvL2NsaWVudC5pbnRlcmNlcHRvcnMucmVxdWVzdOOBp+ODquOCr+OCqOOCueODiOmAgeS/oeWJjeOBq+WJsuOCiui+vOOBv+OBn+OBhOWHpueQhuOCkuabuOOBj1xuICAvLy51c2Xjgb7jgafjgaTjgZHjgovjgZPjgajjgafjgIHjg6rjgq/jgqjjgrnjg4jnm7TliY3jgavlrp/ooYzjgZfjgZ/jgYTplqLmlbDjgpLlrprnvqnjgafjgY3jgotcbiAgY29uc3QgYWNjZXNzVG9rZW4gPSBDb29raWVzLmdldCgnX2FjY2Vzcy10b2tlbicpO1xuICBjb25zdCBjbGllbnRJZCA9IENvb2tpZXMuZ2V0KCdfY2xpZW50Jyk7XG4gIGNvbnN0IHVpZCA9IENvb2tpZXMuZ2V0KCdfdWlkJyk7XG5cbiAgLy8gQ29va2ll5oOF5aCx44Gu44Ot44KwXG4gIGNvbnNvbGUubG9nKCdyZXF1ZXN0IGNvb2tpZScsIHtcbiAgICBhY2Nlc3NUb2tlbixcbiAgICBjbGllbnRJZCxcbiAgICB1aWQsXG4gIH0pO1xuXG4gIGlmIChhY2Nlc3NUb2tlbiAmJiBjbGllbnRJZCAmJiB1aWQpIHtcbiAgICBjb25maWcuaGVhZGVyc1snYWNjZXNzLXRva2VuJ10gPSBhY2Nlc3NUb2tlbjtcbiAgICBjb25maWcuaGVhZGVyc1snY2xpZW50J10gPSBjbGllbnRJZDtcbiAgICBjb25maWcuaGVhZGVyc1sndWlkJ10gPSB1aWQ7XG4gIH1cbiAgcmV0dXJuIGNvbmZpZzsgLy/oqo3oqLzmg4XloLHjgpLjg5jjg4Pjg4Djg7zjgavku5jkuI7jgZfjgabov5TjgZksY29uZmln44Gr6YGp55SoXG59KTtcblxuQXBpQ2xpZW50LmludGVyY2VwdG9ycy5yZXNwb25zZS51c2UoXG4gIC8vY2xpZW50LmludGVyY2VwdG9ycy5yZXNwb25zZeOBruWgtOWQiOOBr+WPl+S/oeebtOW+jOOBq+WJsuOCiui+vOOBv+OBn+OBhOWHpueQhuOBjOabuOOBkeOBvuOBmVxuICAocmVzcG9uc2UpID0+IHtcbiAgICAvLyDmiJDlip/mmYLjga7lh6bnkIZcbiAgICBjb25zdCBhY2Nlc3NUb2tlbiA9IHJlc3BvbnNlLmhlYWRlcnNbJ2FjY2Vzcy10b2tlbiddO1xuICAgIGNvbnN0IGNsaWVudElkID0gcmVzcG9uc2UuaGVhZGVyc1snY2xpZW50J107XG4gICAgY29uc3QgdWlkID0gcmVzcG9uc2UuaGVhZGVyc1sndWlkJ107XG5cbiAgICBpZiAoYWNjZXNzVG9rZW4gJiYgY2xpZW50SWQgJiYgdWlkKSB7XG4gICAgICBDb29raWVzLnNldCgnX2FjY2Vzcy10b2tlbicsIGFjY2Vzc1Rva2VuKTtcbiAgICAgIENvb2tpZXMuc2V0KCdfY2xpZW50JywgY2xpZW50SWQpO1xuICAgICAgQ29va2llcy5zZXQoJ191aWQnLCB1aWQpO1xuICAgIH1cbiAgICByZXR1cm4gcmVzcG9uc2U7IC8vIHJldHVybiByZXNwb25zZeOBp+iqjeiovOaDheWgseOCkuabtOaWsOOBl+OBpui/lOOBmVxuICB9LFxuICAoZXJyb3IpID0+IHtcbiAgICBjb25zb2xlLmxvZyhlcnJvcik7XG4gICAgc3dpdGNoIChlcnJvci5yZXNwb25zZT8uc3RhdHVzKSB7XG4gICAgICBjYXNlIDQwMTpcbiAgICAgICAgdXNlQXV0aFN0b3JlLmdldFN0YXRlKCkubG9nb3V0KCk7XG5cbiAgICAgICAgQ29va2llcy5yZW1vdmUoYF9hY2Nlc3MtdG9rZW5gKTtcbiAgICAgICAgQ29va2llcy5yZW1vdmUoYF9jbGllbnRgKTtcbiAgICAgICAgQ29va2llcy5yZW1vdmUoYF91aWRgKTtcbiAgICAgICAgYnJlYWs7XG4gICAgICBjYXNlIDQwNDpcbiAgICAgICAgYnJlYWs7XG4gICAgICBkZWZhdWx0OlxuICAgIH1cbiAgICBjb25zdCBlcnJvck1lc3NhZ2UgPSAoZXJyb3IucmVzcG9uc2U/LmRhdGE/Lm1lc3NhZ2UgfHwgJycpLnNwbGl0KCcsJyk7XG4gICAgdGhyb3cgbmV3IEVycm9yKGVycm9yTWVzc2FnZSk7XG4gIH1cbik7XG4iXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sV0FBVztBQUNsQixPQUFPLHlCQUF5QjtBQUNoQyxPQUFPLGFBQWE7QUFDcEIsU0FBUyxvQkFBb0I7QUFFN0IsTUFBTSxVQUFVLFlBQVksSUFBSSxxQkFBcUI7QUFFckQsTUFBTSxVQUFVO0FBQUEsRUFDZCxnQkFBZ0I7QUFDbEI7QUFDQSxNQUFNLFVBQVU7QUFBQSxFQUNkLGVBQWU7QUFBQTtBQUNqQjtBQUVPLGFBQU0sWUFBWSxvQkFBb0IsTUFBTSxPQUFPLEVBQUUsU0FBUyxRQUFRLENBQUMsR0FBRyxPQUFPO0FBR3hGLFVBQVUsYUFBYSxRQUFRLElBQUksQ0FBQyxXQUFXO0FBSTdDLFFBQU0sY0FBYyxRQUFRLElBQUksZUFBZTtBQUMvQyxRQUFNLFdBQVcsUUFBUSxJQUFJLFNBQVM7QUFDdEMsUUFBTSxNQUFNLFFBQVEsSUFBSSxNQUFNO0FBRzlCLFVBQVEsSUFBSSxrQkFBa0I7QUFBQSxJQUM1QjtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsRUFDRixDQUFDO0FBRUQsTUFBSSxlQUFlLFlBQVksS0FBSztBQUNsQyxXQUFPLFFBQVEsY0FBYyxJQUFJO0FBQ2pDLFdBQU8sUUFBUSxRQUFRLElBQUk7QUFDM0IsV0FBTyxRQUFRLEtBQUssSUFBSTtBQUFBLEVBQzFCO0FBQ0EsU0FBTztBQUNULENBQUM7QUFFRCxVQUFVLGFBQWEsU0FBUztBQUFBO0FBQUEsRUFFOUIsQ0FBQyxhQUFhO0FBRVosVUFBTSxjQUFjLFNBQVMsUUFBUSxjQUFjO0FBQ25ELFVBQU0sV0FBVyxTQUFTLFFBQVEsUUFBUTtBQUMxQyxVQUFNLE1BQU0sU0FBUyxRQUFRLEtBQUs7QUFFbEMsUUFBSSxlQUFlLFlBQVksS0FBSztBQUNsQyxjQUFRLElBQUksaUJBQWlCLFdBQVc7QUFDeEMsY0FBUSxJQUFJLFdBQVcsUUFBUTtBQUMvQixjQUFRLElBQUksUUFBUSxHQUFHO0FBQUEsSUFDekI7QUFDQSxXQUFPO0FBQUEsRUFDVDtBQUFBLEVBQ0EsQ0FBQyxVQUFVO0FBQ1QsWUFBUSxJQUFJLEtBQUs7QUFDakIsWUFBUSxNQUFNLFVBQVUsUUFBUTtBQUFBLE1BQzlCLEtBQUs7QUFDSCxxQkFBYSxTQUFTLEVBQUUsT0FBTztBQUUvQixnQkFBUSxPQUFPLGVBQWU7QUFDOUIsZ0JBQVEsT0FBTyxTQUFTO0FBQ3hCLGdCQUFRLE9BQU8sTUFBTTtBQUNyQjtBQUFBLE1BQ0YsS0FBSztBQUNIO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFDQSxVQUFNLGdCQUFnQixNQUFNLFVBQVUsTUFBTSxXQUFXLElBQUksTUFBTSxHQUFHO0FBQ3BFLFVBQU0sSUFBSSxNQUFNLFlBQVk7QUFBQSxFQUM5QjtBQUNGOyIsIm5hbWVzIjpbXX0=