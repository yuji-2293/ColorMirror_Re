import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/app/features/colors/components/colorsForm.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=b986c083"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import {} from "/src/app/features/colors/types/Color.ts";
import {} from "/src/app/features/colors/types/Color.ts";
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=b986c083"; const useEffect = __vite__cjsImport3_react["useEffect"];
import { toast } from "/node_modules/.vite/deps/sonner.js?v=b986c083";
import { Spinner } from "/src/components/ui/spinner.tsx";
export const ColorsForm = ({
  mood,
  setMood,
  selectedColorName,
  setSelectedColorName,
  generateColor,
  generatedColor,
  resetColors,
  isPending,
  isSuccess
}) => {
  _s();
  const handleGenerateColor = () => {
    if (isPending) return;
    const generateMood = {
      mood
    };
    generateColor(generateMood);
  };
  const handleMoodSelect = (newMood) => {
    setMood(newMood);
    setSelectedColorName("");
    resetColors();
  };
  useEffect(() => {
    if (isSuccess) {
      toast.success("色の生成に成功しました！ 好きな色を選択して、次のSTEPに進みましょう!");
      setSelectedColorName("");
    }
  }, [isSuccess, setSelectedColorName]);
  return /* @__PURE__ */ jsxDEV("div", { className: "STEP1 bg-pink-200/90 w-full m-2 p-2 rounded-2xl shadow-2xl border border-white/60 relative", children: [
    isPending && /* @__PURE__ */ jsxDEV("div", { className: "absolute inset-0 bg-white/60 backdrop-blur-sm flex items-center justify-center z-10", children: /* @__PURE__ */ jsxDEV(Spinner, {}, void 0, false, {
      fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsForm.tsx",
      lineNumber: 48,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsForm.tsx",
      lineNumber: 47,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "FormHeader", children: /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col text-center", children: [
      /* @__PURE__ */ jsxDEV("p", { children: "~STEP1~" }, void 0, false, {
        fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsForm.tsx",
        lineNumber: 54,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("p", { children: "気分を入力してcolorを作成" }, void 0, false, {
        fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsForm.tsx",
        lineNumber: 55,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsForm.tsx",
      lineNumber: 53,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsForm.tsx",
      lineNumber: 52,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "FormContent flex flex-col items-center justify-center", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "sm:flex sm:justify-around sm:items-center grid grid-cols-2", children: [
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => handleMoodSelect("ワクワク"),
            className: "flex items-center justify-center rounded-xl bg-amber-300 w-30 h-10 m-5 p-5 shadow-2xl cursor-pointer border-2 border-white focus:border-gray-300 focus:border-4 active:shadow-2xl focus:scale-120 focus-rounded-2xl transition-transform hover:bg-accent",
            children: "ワクワク"
          },
          void 0,
          false,
          {
            fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsForm.tsx",
            lineNumber: 61,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => handleMoodSelect("ムカムカ"),
            className: "flex items-center justify-center rounded-xl bg-rose-500 w-30 h-10 m-5 p-5 shadow-2xl cursor-pointer border-2 border-white focus:border-gray-300 focus:border-4 active:shadow-2xl focus:scale-120 focus-rounded-2xl transition-transform hover:bg-accent",
            children: "ムカムカ"
          },
          void 0,
          false,
          {
            fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsForm.tsx",
            lineNumber: 67,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => handleMoodSelect("モヤモヤ"),
            className: "flex items-center justify-center rounded-xl bg-indigo-600 w-30 h-10 m-5 p-5 shadow-2xl cursor-pointer border-2 border-white focus:border-gray-300 focus:border-4 active:shadow-2xl focus:scale-120 focus-rounded-2xl transition-transform hover:bg-accent",
            children: "モヤモヤ"
          },
          void 0,
          false,
          {
            fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsForm.tsx",
            lineNumber: 73,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => handleMoodSelect("ホカホカ"),
            className: "flex items-center justify-center rounded-xl bg-pink-300 w-30 h-10 m-5 p-5 shadow-2xl cursor-pointer border-2 border-white focus:border-gray-300 focus:border-4 active:shadow-2xl focus:scale-120 focus-rounded-2xl transition-transform hover:bg-accent",
            children: "ホカホカ"
          },
          void 0,
          false,
          {
            fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsForm.tsx",
            lineNumber: 79,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsForm.tsx",
        lineNumber: 60,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-around", children: /* @__PURE__ */ jsxDEV(
        "button",
        {
          className: "w-full px-12 py-3 bg-cyan-300 text-white rounded-2xl shadow-2xl border-2 border-white font-bold text-xl disabled:bg-gray-300 hover:scale-110 hover:bg-pink-300 disabled:opacity-50 disabled:cursor-not-allowed",
          onClick: handleGenerateColor,
          disabled: !mood || isPending,
          children: generatedColor.length > 0 ? "再生成" : "生成開始"
        },
        void 0,
        false,
        {
          fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsForm.tsx",
          lineNumber: 88,
          columnNumber: 11
        },
        this
      ) }, void 0, false, {
        fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsForm.tsx",
        lineNumber: 86,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsForm.tsx",
      lineNumber: 59,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center sm:justify-around justify-center flex-col text-sm leading-relaxed border-2 border-accent rounded-xl p-4 shadow-sm space-y-2 my-4", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "w-full sm:max-w-1/3 max-w-3xl m-2 p-2 text-center text-sm border-2 border-accent rounded-2xl shadow-2xl", children: [
        /* @__PURE__ */ jsxDEV("p", { children: [
          "選択中の気分:",
          mood
        ] }, void 0, true, {
          fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsForm.tsx",
          lineNumber: 102,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { children: [
          "選択中のcolor:",
          selectedColorName
        ] }, void 0, true, {
          fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsForm.tsx",
          lineNumber: 106,
          columnNumber: 11
        }, this),
        selectedColorName ? /* @__PURE__ */ jsxDEV(
          "div",
          {
            className: "rounded-full sm:w-20 sm:h-20 w-10 h-10 mx-auto border-2 border-white shadow-sm",
            style: { backgroundColor: selectedColorName }
          },
          void 0,
          false,
          {
            fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsForm.tsx",
            lineNumber: 112,
            columnNumber: 11
          },
          this
        ) : /* @__PURE__ */ jsxDEV("p", { children: "`colorが未選択です`" }, void 0, false, {
          fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsForm.tsx",
          lineNumber: 117,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsForm.tsx",
        lineNumber: 101,
        columnNumber: 9
      }, this),
      isSuccess && /* @__PURE__ */ jsxDEV("div", { className: "bg-white w-full rounded-2xl shadow-2xl opacity-90 mt-4 p-2 flex flex-col sm:flex-row gap-2 justify-around items-center", children: [
        /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV("p", { className: "text-xs block sm:hidden", children: "colorを選択してください" }, void 0, false, {
          fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsForm.tsx",
          lineNumber: 125,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsForm.tsx",
          lineNumber: 124,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-around gap-2", children: generatedColor.map(
          (c) => /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col items-center gap-2", children: [
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                "aria-label": ` ${c.name}を選択`,
                onClick: () => setSelectedColorName(c.hex),
                className: "rounded-full border border-gray-300 sm:w-30 w-10  sm:h-30 h-10 hover:scale-110 hover:shadow-2xl transition-transform",
                style: { backgroundColor: c.hex }
              },
              void 0,
              false,
              {
                fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsForm.tsx",
                lineNumber: 131,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("p", { className: "text-sm hidden sm:block wrap-break-word", children: c.name }, void 0, false, {
              fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsForm.tsx",
              lineNumber: 137,
              columnNumber: 19
            }, this)
          ] }, c.hex, true, {
            fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsForm.tsx",
            lineNumber: 130,
            columnNumber: 13
          }, this)
        ) }, void 0, false, {
          fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsForm.tsx",
          lineNumber: 128,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsForm.tsx",
        lineNumber: 123,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsForm.tsx",
      lineNumber: 100,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsForm.tsx",
    lineNumber: 44,
    columnNumber: 5
  }, this);
};
_s(ColorsForm, "OD7bBpZva5O2jO+Puf00hKivP7c=");
_c = ColorsForm;
var _c;
$RefreshReg$(_c, "ColorsForm");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsForm.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsForm.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsForm.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBK0NVOztBQS9DVixlQUF3QztBQUN4QyxlQUFxQztBQUNyQyxTQUFTQSxpQkFBaUI7QUFDMUIsU0FBU0MsYUFBYTtBQUN0QixTQUFTQyxlQUFlO0FBQ2pCLGFBQU1DLGFBQWFBLENBQUM7QUFBQSxFQUN6QkM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFDZSxNQUFNO0FBQUFDLEtBQUE7QUFDckIsUUFBTUMsc0JBQXNCQSxNQUFNO0FBRWhDLFFBQUlILFVBQVc7QUFFZixVQUFNSSxlQUFtQztBQUFBLE1BQ3ZDWDtBQUFBQSxJQUNGO0FBRUFJLGtCQUFjTyxZQUFZO0FBQUEsRUFDNUI7QUFHQSxRQUFNQyxtQkFBbUJBLENBQUNDLFlBQW9CO0FBQzVDWixZQUFRWSxPQUFPO0FBQ2ZWLHlCQUFxQixFQUFFO0FBQ3ZCRyxnQkFBWTtBQUFBLEVBQ2Q7QUFHQVYsWUFBVSxNQUFNO0FBQ2QsUUFBSVksV0FBVztBQUNiWCxZQUFNaUIsUUFBUSx1Q0FBdUM7QUFDckRYLDJCQUFxQixFQUFFO0FBQUEsSUFDekI7QUFBQSxFQUNGLEdBQUcsQ0FBQ0ssV0FBV0wsb0JBQW9CLENBQUM7QUFFcEMsU0FDRSx1QkFBQyxTQUFJLFdBQVUsOEZBRVpJO0FBQUFBLGlCQUNDLHVCQUFDLFNBQUksV0FBVSx1RkFDYixpQ0FBQyxhQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBUSxLQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLElBR0YsdUJBQUMsU0FBSSxXQUFVLGNBQ2IsaUNBQUMsU0FBSSxXQUFVLDZCQUNiO0FBQUEsNkJBQUMsT0FBRSx1QkFBSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQVU7QUFBQSxNQUNWLHVCQUFDLE9BQUUsK0JBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFrQjtBQUFBLFNBRnBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQSxLQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FLQTtBQUFBLElBRUEsdUJBQUMsU0FBSSxXQUFVLHlEQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLDhEQUNiO0FBQUE7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFNBQVMsTUFBTUssaUJBQWlCLE1BQU07QUFBQSxZQUN0QyxXQUFVO0FBQUEsWUFBMFA7QUFBQTtBQUFBLFVBRnRRO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUtBO0FBQUEsUUFDQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsU0FBUyxNQUFNQSxpQkFBaUIsTUFBTTtBQUFBLFlBQ3RDLFdBQVU7QUFBQSxZQUF5UDtBQUFBO0FBQUEsVUFGclE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBS0E7QUFBQSxRQUNBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxTQUFTLE1BQU1BLGlCQUFpQixNQUFNO0FBQUEsWUFDdEMsV0FBVTtBQUFBLFlBQTJQO0FBQUE7QUFBQSxVQUZ2UTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFLQTtBQUFBLFFBQ0E7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFNBQVMsTUFBTUEsaUJBQWlCLE1BQU07QUFBQSxZQUN0QyxXQUFVO0FBQUEsWUFBeVA7QUFBQTtBQUFBLFVBRnJRO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUtBO0FBQUEsV0F4QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXlCQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLG9DQUViO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxXQUFVO0FBQUEsVUFDVixTQUFTRjtBQUFBQSxVQUNULFVBQVUsQ0FBQ1YsUUFBUU87QUFBQUEsVUFJbEJGLHlCQUFlVSxTQUFTLElBQUksUUFBUTtBQUFBO0FBQUEsUUFQdkM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BUUEsS0FWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBV0E7QUFBQSxTQXRDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBdUNBO0FBQUEsSUFFQSx1QkFBQyxTQUFJLFdBQVUsc0pBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsMkdBQ2I7QUFBQSwrQkFBQyxPQUFDO0FBQUE7QUFBQSxVQUVDZjtBQUFBQSxhQUZIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBQ0EsdUJBQUMsT0FBQztBQUFBO0FBQUEsVUFFQ0U7QUFBQUEsYUFGSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUVDQSxvQkFDQztBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsV0FBVTtBQUFBLFlBQ1YsT0FBTyxFQUFFYyxpQkFBaUJkLGtCQUFrQjtBQUFBO0FBQUEsVUFGOUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBR0MsSUFFRCx1QkFBQyxPQUFFLDZCQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0I7QUFBQSxXQWhCcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWtCQTtBQUFBLE1BR0NNLGFBQ0MsdUJBQUMsU0FBSSxXQUFVLDBIQUNiO0FBQUEsK0JBQUMsU0FDQyxpQ0FBQyxPQUFFLFdBQVUsMkJBQTBCLDhCQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXFELEtBRHZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLDBDQUNaSCx5QkFBZVk7QUFBQUEsVUFBSSxDQUFDQyxNQUNuQix1QkFBQyxTQUFnQixXQUFVLG9DQUN6QjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsY0FBWSxJQUFJQSxFQUFFQyxJQUFJO0FBQUEsZ0JBQ3RCLFNBQVMsTUFBTWhCLHFCQUFxQmUsRUFBRUUsR0FBRztBQUFBLGdCQUN6QyxXQUFVO0FBQUEsZ0JBQ1YsT0FBTyxFQUFFSixpQkFBaUJFLEVBQUVFLElBQUk7QUFBQTtBQUFBLGNBSmxDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUlvQztBQUFBLFlBRXBDLHVCQUFDLE9BQUUsV0FBVSwyQ0FBMkNGLFlBQUVDLFFBQTFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQStEO0FBQUEsZUFQdkRELEVBQUVFLEtBQVo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFRQTtBQUFBLFFBQ0QsS0FYSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBWUE7QUFBQSxXQWpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBa0JBO0FBQUEsU0F6Q0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTJDQTtBQUFBLE9BbkdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FvR0E7QUFFSjtBQUFFWCxHQTVJV1YsWUFBVTtBQUFBc0IsS0FBVnRCO0FBQVUsSUFBQXNCO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VFZmZlY3QiLCJ0b2FzdCIsIlNwaW5uZXIiLCJDb2xvcnNGb3JtIiwibW9vZCIsInNldE1vb2QiLCJzZWxlY3RlZENvbG9yTmFtZSIsInNldFNlbGVjdGVkQ29sb3JOYW1lIiwiZ2VuZXJhdGVDb2xvciIsImdlbmVyYXRlZENvbG9yIiwicmVzZXRDb2xvcnMiLCJpc1BlbmRpbmciLCJpc1N1Y2Nlc3MiLCJfcyIsImhhbmRsZUdlbmVyYXRlQ29sb3IiLCJnZW5lcmF0ZU1vb2QiLCJoYW5kbGVNb29kU2VsZWN0IiwibmV3TW9vZCIsInN1Y2Nlc3MiLCJsZW5ndGgiLCJiYWNrZ3JvdW5kQ29sb3IiLCJtYXAiLCJjIiwibmFtZSIsImhleCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbImNvbG9yc0Zvcm0udHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHR5cGUgR2VuZXJhdGVNb29kUGFyYW1zIH0gZnJvbSAnQC9hcHAvZmVhdHVyZXMvY29sb3JzL3R5cGVzL0NvbG9yJztcbmltcG9ydCB7IHR5cGUgQ29sb3JzRm9ybVByb3BzIH0gZnJvbSAnQC9hcHAvZmVhdHVyZXMvY29sb3JzL3R5cGVzL0NvbG9yJztcbmltcG9ydCB7IHVzZUVmZmVjdCB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHRvYXN0IH0gZnJvbSAnc29ubmVyJztcbmltcG9ydCB7IFNwaW5uZXIgfSBmcm9tICdAL2NvbXBvbmVudHMvdWkvc3Bpbm5lcic7XG5leHBvcnQgY29uc3QgQ29sb3JzRm9ybSA9ICh7XG4gIG1vb2QsXG4gIHNldE1vb2QsXG4gIHNlbGVjdGVkQ29sb3JOYW1lLFxuICBzZXRTZWxlY3RlZENvbG9yTmFtZSxcbiAgZ2VuZXJhdGVDb2xvcixcbiAgZ2VuZXJhdGVkQ29sb3IsXG4gIHJlc2V0Q29sb3JzLFxuICBpc1BlbmRpbmcsXG4gIGlzU3VjY2Vzcyxcbn06IENvbG9yc0Zvcm1Qcm9wcykgPT4ge1xuICBjb25zdCBoYW5kbGVHZW5lcmF0ZUNvbG9yID0gKCkgPT4ge1xuICAgIC8vIOeUn+aIkOS4reOBruWgtOWQiOOBr+OCr+ODquODg+OCr+OCkueEoeWKueOBq+OBmeOCi1xuICAgIGlmIChpc1BlbmRpbmcpIHJldHVybjtcbiAgICAvLyBwYXJhbXPjgpLkvZzmiJDjgZfjgaZBUEnjg6rjgq/jgqjjgrnjg4jjgpLpgIHjgotcbiAgICBjb25zdCBnZW5lcmF0ZU1vb2Q6IEdlbmVyYXRlTW9vZFBhcmFtcyA9IHtcbiAgICAgIG1vb2Q6IG1vb2QsXG4gICAgfTtcbiAgICAvLyB0YW4gU3RhY2sgUXVlcnnjga5tdXRhdGXplqLmlbDjgpLlkbzjgbPlh7rjgZfjgaZBUEnjg6rjgq/jgqjjgrnjg4jjgpLpgIHjgotcbiAgICBnZW5lcmF0ZUNvbG9yKGdlbmVyYXRlTW9vZCk7XG4gIH07XG5cbiAgLy8gbW9vZOOCkuabtOaWsOOBl+OBn+OCieOAgeS+neWtmOmWouS/guOBq+OBguOCi0FQSemAmuS/oeOBp+eUn+aIkOOBleOCjOOBn+iJsuOBruODh+ODvOOCv+OCkuODquOCu+ODg+ODiOOBmeOCi1xuICBjb25zdCBoYW5kbGVNb29kU2VsZWN0ID0gKG5ld01vb2Q6IHN0cmluZykgPT4ge1xuICAgIHNldE1vb2QobmV3TW9vZCk7XG4gICAgc2V0U2VsZWN0ZWRDb2xvck5hbWUoJycpO1xuICAgIHJlc2V0Q29sb3JzKCk7XG4gIH07XG5cbiAgLy8g55Sf5oiQ44Gr5oiQ5Yqf44GX44Gf44KJ44CB44OI44O844K544OI6YCa55+l44KS6KGo56S644GX44Gm44CB6YG45oqe44GV44KM44Gf6Imy44Gu5ZCN5YmN44KS44Oq44K744OD44OI44GZ44KLXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKGlzU3VjY2Vzcykge1xuICAgICAgdG9hc3Quc3VjY2Vzcygn6Imy44Gu55Sf5oiQ44Gr5oiQ5Yqf44GX44G+44GX44Gf77yBIOWlveOBjeOBquiJsuOCkumBuOaKnuOBl+OBpuOAgeasoeOBrlNURVDjgavpgLLjgb/jgb7jgZfjgofjgYYhJyk7XG4gICAgICBzZXRTZWxlY3RlZENvbG9yTmFtZSgnJyk7XG4gICAgfVxuICB9LCBbaXNTdWNjZXNzLCBzZXRTZWxlY3RlZENvbG9yTmFtZV0pO1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJTVEVQMSBiZy1waW5rLTIwMC85MCB3LWZ1bGwgbS0yIHAtMiByb3VuZGVkLTJ4bCBzaGFkb3ctMnhsIGJvcmRlciBib3JkZXItd2hpdGUvNjAgcmVsYXRpdmVcIj5cbiAgICAgIHsvKiDpgJrkv6HkuK3jgavooajnpLrjgZnjgotsb2FkaW5n44Ki44OL44Oh44O844K344On44OzKi99XG4gICAgICB7aXNQZW5kaW5nICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBpbnNldC0wIGJnLXdoaXRlLzYwIGJhY2tkcm9wLWJsdXItc20gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgei0xMFwiPlxuICAgICAgICAgIDxTcGlubmVyIC8+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cblxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJGb3JtSGVhZGVyXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCB0ZXh0LWNlbnRlclwiPlxuICAgICAgICAgIDxwPn5TVEVQMX48L3A+XG4gICAgICAgICAgPHA+5rCX5YiG44KS5YWl5Yqb44GX44GmY29sb3LjgpLkvZzmiJA8L3A+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiRm9ybUNvbnRlbnQgZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzbTpmbGV4IHNtOmp1c3RpZnktYXJvdW5kIHNtOml0ZW1zLWNlbnRlciBncmlkIGdyaWQtY29scy0yXCI+XG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlTW9vZFNlbGVjdCgn44Ov44Kv44Ov44KvJyl9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciByb3VuZGVkLXhsIGJnLWFtYmVyLTMwMCB3LTMwIGgtMTAgbS01IHAtNSBzaGFkb3ctMnhsIGN1cnNvci1wb2ludGVyIGJvcmRlci0yIGJvcmRlci13aGl0ZSBmb2N1czpib3JkZXItZ3JheS0zMDAgZm9jdXM6Ym9yZGVyLTQgYWN0aXZlOnNoYWRvdy0yeGwgZm9jdXM6c2NhbGUtMTIwIGZvY3VzLXJvdW5kZWQtMnhsIHRyYW5zaXRpb24tdHJhbnNmb3JtIGhvdmVyOmJnLWFjY2VudFwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAg44Ov44Kv44Ov44KvXG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlTW9vZFNlbGVjdCgn44Og44Kr44Og44KrJyl9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciByb3VuZGVkLXhsIGJnLXJvc2UtNTAwIHctMzAgaC0xMCBtLTUgcC01IHNoYWRvdy0yeGwgY3Vyc29yLXBvaW50ZXIgYm9yZGVyLTIgYm9yZGVyLXdoaXRlIGZvY3VzOmJvcmRlci1ncmF5LTMwMCBmb2N1czpib3JkZXItNCBhY3RpdmU6c2hhZG93LTJ4bCBmb2N1czpzY2FsZS0xMjAgZm9jdXMtcm91bmRlZC0yeGwgdHJhbnNpdGlvbi10cmFuc2Zvcm0gaG92ZXI6YmctYWNjZW50XCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICDjg6Djgqvjg6DjgqtcbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVNb29kU2VsZWN0KCfjg6Ljg6Tjg6Ljg6QnKX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHJvdW5kZWQteGwgYmctaW5kaWdvLTYwMCB3LTMwIGgtMTAgbS01IHAtNSBzaGFkb3ctMnhsIGN1cnNvci1wb2ludGVyIGJvcmRlci0yIGJvcmRlci13aGl0ZSBmb2N1czpib3JkZXItZ3JheS0zMDAgZm9jdXM6Ym9yZGVyLTQgYWN0aXZlOnNoYWRvdy0yeGwgZm9jdXM6c2NhbGUtMTIwIGZvY3VzLXJvdW5kZWQtMnhsIHRyYW5zaXRpb24tdHJhbnNmb3JtIGhvdmVyOmJnLWFjY2VudFwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAg44Oi44Ok44Oi44OkXG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlTW9vZFNlbGVjdCgn44Ob44Kr44Ob44KrJyl9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciByb3VuZGVkLXhsIGJnLXBpbmstMzAwIHctMzAgaC0xMCBtLTUgcC01IHNoYWRvdy0yeGwgY3Vyc29yLXBvaW50ZXIgYm9yZGVyLTIgYm9yZGVyLXdoaXRlIGZvY3VzOmJvcmRlci1ncmF5LTMwMCBmb2N1czpib3JkZXItNCBhY3RpdmU6c2hhZG93LTJ4bCBmb2N1czpzY2FsZS0xMjAgZm9jdXMtcm91bmRlZC0yeGwgdHJhbnNpdGlvbi10cmFuc2Zvcm0gaG92ZXI6YmctYWNjZW50XCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICDjg5vjgqvjg5vjgqtcbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1hcm91bmRcIj5cbiAgICAgICAgICB7Lyog5rCX5YiG44KS5YWD44GrY29sb3LjgpLnlJ/miJDjgZnjgovplqLmlbDjgpLlrp/ooYzjgZnjgotidXR0b24gKi99XG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB4LTEyIHB5LTMgYmctY3lhbi0zMDAgdGV4dC13aGl0ZSByb3VuZGVkLTJ4bCBzaGFkb3ctMnhsIGJvcmRlci0yIGJvcmRlci13aGl0ZSBmb250LWJvbGQgdGV4dC14bCBkaXNhYmxlZDpiZy1ncmF5LTMwMCBob3ZlcjpzY2FsZS0xMTAgaG92ZXI6YmctcGluay0zMDAgZGlzYWJsZWQ6b3BhY2l0eS01MCBkaXNhYmxlZDpjdXJzb3Itbm90LWFsbG93ZWRcIlxuICAgICAgICAgICAgb25DbGljaz17aGFuZGxlR2VuZXJhdGVDb2xvcn1cbiAgICAgICAgICAgIGRpc2FibGVkPXshbW9vZCB8fCBpc1BlbmRpbmd9XG4gICAgICAgICAgPlxuICAgICAgICAgICAgey8qIGdlbmVyYXRlZENvbG9y44GvQVBJ6YCa5L+h44Gn6L+U44Gj44Gm44GP44KL44OH44O844K/44Gu5ZCN5YmNICovfVxuICAgICAgICAgICAgey8qIGdlbmVyYXRlZENvbG9y44GM44OH44O844K/44Go44GX44Gm6L+U44Gj44Gm44GN44Gm44GK44KK44CB6YWN5YiX44Gu6KaB57Sg5pWw44GM77yR44Gk5Lul5LiK77yI5a2Y5Zyo44GZ44KL44GL44Gp44GG44GL77yJ44Gn44GC44KL44GL44Gp44GG44GL44KS6KmV5L6h44GX44Gm6KGo6KiY44KS5YiG5bKQ44GZ44KLICovfVxuICAgICAgICAgICAge2dlbmVyYXRlZENvbG9yLmxlbmd0aCA+IDAgPyAn5YaN55Sf5oiQJyA6ICfnlJ/miJDplovlp4snfVxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIHNtOmp1c3RpZnktYXJvdW5kIGp1c3RpZnktY2VudGVyIGZsZXgtY29sIHRleHQtc20gbGVhZGluZy1yZWxheGVkIGJvcmRlci0yIGJvcmRlci1hY2NlbnQgcm91bmRlZC14bCBwLTQgc2hhZG93LXNtIHNwYWNlLXktMiBteS00XCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy1mdWxsIHNtOm1heC13LTEvMyBtYXgtdy0zeGwgbS0yIHAtMiB0ZXh0LWNlbnRlciB0ZXh0LXNtIGJvcmRlci0yIGJvcmRlci1hY2NlbnQgcm91bmRlZC0yeGwgc2hhZG93LTJ4bFwiPlxuICAgICAgICAgIDxwPlxuICAgICAgICAgICAg6YG45oqe5Lit44Gu5rCX5YiGOlxuICAgICAgICAgICAge21vb2R9XG4gICAgICAgICAgPC9wPlxuICAgICAgICAgIDxwPlxuICAgICAgICAgICAg6YG45oqe5Lit44GuY29sb3I6XG4gICAgICAgICAgICB7c2VsZWN0ZWRDb2xvck5hbWV9XG4gICAgICAgICAgPC9wPlxuXG4gICAgICAgICAge3NlbGVjdGVkQ29sb3JOYW1lID8gKFxuICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkLWZ1bGwgc206dy0yMCBzbTpoLTIwIHctMTAgaC0xMCBteC1hdXRvIGJvcmRlci0yIGJvcmRlci13aGl0ZSBzaGFkb3ctc21cIlxuICAgICAgICAgICAgICBzdHlsZT17eyBiYWNrZ3JvdW5kQ29sb3I6IHNlbGVjdGVkQ29sb3JOYW1lIH19XG4gICAgICAgICAgICA+PC9kaXY+XG4gICAgICAgICAgKSA6IChcbiAgICAgICAgICAgIDxwPmBjb2xvcuOBjOacqumBuOaKnuOBp+OBmWA8L3A+XG4gICAgICAgICAgKX1cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIOmAmuS/oeW+jOeUn+aIkOOBq+aIkOWKn+OBl+OBn+OCieihqOekuuOBleOCjOOCiyAqL31cbiAgICAgICAge2lzU3VjY2VzcyAmJiAoXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy13aGl0ZSB3LWZ1bGwgcm91bmRlZC0yeGwgc2hhZG93LTJ4bCBvcGFjaXR5LTkwIG10LTQgcC0yIGZsZXggZmxleC1jb2wgc206ZmxleC1yb3cgZ2FwLTIganVzdGlmeS1hcm91bmQgaXRlbXMtY2VudGVyXCI+XG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGJsb2NrIHNtOmhpZGRlblwiPmNvbG9y44KS6YG45oqe44GX44Gm44GP44Gg44GV44GEPC9wPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1hcm91bmQgZ2FwLTJcIj5cbiAgICAgICAgICAgICAge2dlbmVyYXRlZENvbG9yLm1hcCgoYykgPT4gKFxuICAgICAgICAgICAgICAgIDxkaXYga2V5PXtjLmhleH0gY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgYXJpYS1sYWJlbD17YCAke2MubmFtZX3jgpLpgbjmip5gfVxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTZWxlY3RlZENvbG9yTmFtZShjLmhleCl9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQtZnVsbCBib3JkZXIgYm9yZGVyLWdyYXktMzAwIHNtOnctMzAgdy0xMCAgc206aC0zMCBoLTEwIGhvdmVyOnNjYWxlLTExMCBob3ZlcjpzaGFkb3ctMnhsIHRyYW5zaXRpb24tdHJhbnNmb3JtXCJcbiAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgYmFja2dyb3VuZENvbG9yOiBjLmhleCB9fVxuICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gaGlkZGVuIHNtOmJsb2NrIHdyYXAtYnJlYWstd29yZFwiPntjLm5hbWV9PC9wPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICApfVxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICk7XG59O1xuIl0sImZpbGUiOiIvVXNlcnMvaW5vdWV5dXVqaS9Db2xvck1pcnJvcl9SZS9mcm9udC9BcHBfZnJvbnQvc3JjL2FwcC9mZWF0dXJlcy9jb2xvcnMvY29tcG9uZW50cy9jb2xvcnNGb3JtLnRzeCJ9