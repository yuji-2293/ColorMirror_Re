import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/app/features/colors/components/colorsFormCard.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=b986c083"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import { Card, CardContent, CardTitle, CardHeader } from "/src/components/ui/card.tsx";
import {} from "/src/app/features/colors/types/Color.ts";
export const ColorsFormCard = ({ children }) => {
  return /* @__PURE__ */ jsxDEV("div", { className: "FormUI sm-w-full sm:max-w-7xl w-full", children: /* @__PURE__ */ jsxDEV(Card, { className: "bg-white/50 backdrop-blur-md", children: [
    /* @__PURE__ */ jsxDEV(CardHeader, { children: /* @__PURE__ */ jsxDEV(CardTitle, { className: "text-2xl text-center", children: "生成Form" }, void 0, false, {
      fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsFormCard.tsx",
      lineNumber: 9,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsFormCard.tsx",
      lineNumber: 8,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(CardContent, { children }, void 0, false, {
      fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsFormCard.tsx",
      lineNumber: 11,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsFormCard.tsx",
    lineNumber: 7,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsFormCard.tsx",
    lineNumber: 6,
    columnNumber: 5
  }, this);
};
_c = ColorsFormCard;
var _c;
$RefreshReg$(_c, "ColorsFormCard");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsFormCard.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsFormCard.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsFormCard.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBUVU7QUFSVixTQUFTQSxNQUFNQyxhQUFhQyxXQUFXQyxrQkFBa0I7QUFDekQsZUFBeUM7QUFFbEMsYUFBTUMsaUJBQWlCQSxDQUFDLEVBQUVDLFNBQThCLE1BQU07QUFDbkUsU0FDRSx1QkFBQyxTQUFJLFdBQVUsd0NBQ2IsaUNBQUMsUUFBSyxXQUFVLGdDQUNkO0FBQUEsMkJBQUMsY0FDQyxpQ0FBQyxhQUFVLFdBQVUsd0JBQXVCLHNCQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWtELEtBRHBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLElBQ0EsdUJBQUMsZUFFRUEsWUFGSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR0E7QUFBQSxPQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FRQSxLQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FVQTtBQUVKO0FBQUVDLEtBZFdGO0FBQWMsSUFBQUU7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIkNhcmQiLCJDYXJkQ29udGVudCIsIkNhcmRUaXRsZSIsIkNhcmRIZWFkZXIiLCJDb2xvcnNGb3JtQ2FyZCIsImNoaWxkcmVuIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiY29sb3JzRm9ybUNhcmQudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENhcmQsIENhcmRDb250ZW50LCBDYXJkVGl0bGUsIENhcmRIZWFkZXIgfSBmcm9tICdAL2NvbXBvbmVudHMvdWkvY2FyZCc7XG5pbXBvcnQgeyB0eXBlIENvbG9yc0Zvcm1DYXJkUHJvcHMgfSBmcm9tICdAL2FwcC9mZWF0dXJlcy9jb2xvcnMvdHlwZXMvQ29sb3InO1xuXG5leHBvcnQgY29uc3QgQ29sb3JzRm9ybUNhcmQgPSAoeyBjaGlsZHJlbiB9OiBDb2xvcnNGb3JtQ2FyZFByb3BzKSA9PiB7XG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJGb3JtVUkgc20tdy1mdWxsIHNtOm1heC13LTd4bCB3LWZ1bGxcIj5cbiAgICAgIDxDYXJkIGNsYXNzTmFtZT1cImJnLXdoaXRlLzUwIGJhY2tkcm9wLWJsdXItbWRcIj5cbiAgICAgICAgPENhcmRIZWFkZXI+XG4gICAgICAgICAgPENhcmRUaXRsZSBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCB0ZXh0LWNlbnRlclwiPueUn+aIkEZvcm08L0NhcmRUaXRsZT5cbiAgICAgICAgPC9DYXJkSGVhZGVyPlxuICAgICAgICA8Q2FyZENvbnRlbnQ+XG4gICAgICAgICAgey8qIOOCq+ODqeODvOOBruaWsOimj+S9nOaIkOODleOCqeODvOODoOOCkuOBk+OBk+OBq+Wun+ijhSAqL31cbiAgICAgICAgICB7Y2hpbGRyZW59XG4gICAgICAgIDwvQ2FyZENvbnRlbnQ+XG4gICAgICA8L0NhcmQ+XG4gICAgPC9kaXY+XG4gICk7XG59O1xuIl0sImZpbGUiOiIvVXNlcnMvaW5vdWV5dXVqaS9Db2xvck1pcnJvcl9SZS9mcm9udC9BcHBfZnJvbnQvc3JjL2FwcC9mZWF0dXJlcy9jb2xvcnMvY29tcG9uZW50cy9jb2xvcnNGb3JtQ2FyZC50c3gifQ==