import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/layout/footer.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=b986c083"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
export const Footer = () => {
  return /* @__PURE__ */ jsxDEV("footer", { className: "w-full space-y-6 p-4 m-8 flex flex-col mx-auto overflow-y-auto", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "grid grid-flow-col text-center", children: [
      /* @__PURE__ */ jsxDEV("p", { children: "プライバシーポリシー" }, void 0, false, {
        fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/components/layout/footer.tsx",
        lineNumber: 5,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("p", { children: "利用規約" }, void 0, false, {
        fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/components/layout/footer.tsx",
        lineNumber: 6,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("p", { children: "お問い合わせ" }, void 0, false, {
        fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/components/layout/footer.tsx",
        lineNumber: 7,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/components/layout/footer.tsx",
      lineNumber: 4,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "text-center", children: /* @__PURE__ */ jsxDEV("p", { className: "", children: "copyright ©︎ 2025 - ColorMirror_Re" }, void 0, false, {
      fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/components/layout/footer.tsx",
      lineNumber: 10,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/components/layout/footer.tsx",
      lineNumber: 9,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/components/layout/footer.tsx",
    lineNumber: 3,
    columnNumber: 5
  }, this);
};
_c = Footer;
var _c;
$RefreshReg$(_c, "Footer");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/components/layout/footer.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/components/layout/footer.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/components/layout/footer.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBSVE7QUFKRCxhQUFNQSxTQUFTQSxNQUFNO0FBQzFCLFNBQ0UsdUJBQUMsWUFBTyxXQUFVLGtFQUNoQjtBQUFBLDJCQUFDLFNBQUksV0FBVSxrQ0FDYjtBQUFBLDZCQUFDLE9BQUUsMEJBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFhO0FBQUEsTUFDYix1QkFBQyxPQUFFLG9CQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBTztBQUFBLE1BQ1AsdUJBQUMsT0FBRSxzQkFBSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQVM7QUFBQSxTQUhYO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FJQTtBQUFBLElBQ0EsdUJBQUMsU0FBSSxXQUFVLGVBQ2IsaUNBQUMsT0FBRSxXQUFVLElBQUcsa0RBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBa0QsS0FEcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsT0FSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBU0E7QUFFSjtBQUFFQyxLQWJXRDtBQUFNLElBQUFDO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJGb290ZXIiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJmb290ZXIudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBjb25zdCBGb290ZXIgPSAoKSA9PiB7XG4gIHJldHVybiAoXG4gICAgPGZvb3RlciBjbGFzc05hbWU9XCJ3LWZ1bGwgc3BhY2UteS02IHAtNCBtLTggZmxleCBmbGV4LWNvbCBteC1hdXRvIG92ZXJmbG93LXktYXV0b1wiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtZmxvdy1jb2wgdGV4dC1jZW50ZXJcIj5cbiAgICAgICAgPHA+44OX44Op44Kk44OQ44K344O844Od44Oq44K344O8PC9wPlxuICAgICAgICA8cD7liKnnlKjopo/ntIQ8L3A+XG4gICAgICAgIDxwPuOBiuWVj+OBhOWQiOOCj+OBmzwvcD5cbiAgICAgIDwvZGl2PlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlclwiPlxuICAgICAgICA8cCBjbGFzc05hbWU9XCJcIj5jb3B5cmlnaHQgwqnvuI4gMjAyNSAtIENvbG9yTWlycm9yX1JlPC9wPlxuICAgICAgPC9kaXY+XG4gICAgPC9mb290ZXI+XG4gICk7XG59O1xuIl0sImZpbGUiOiIvVXNlcnMvaW5vdWV5dXVqaS9Db2xvck1pcnJvcl9SZS9mcm9udC9BcHBfZnJvbnQvc3JjL2NvbXBvbmVudHMvbGF5b3V0L2Zvb3Rlci50c3gifQ==