import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/app/features/auth/components/signInCard.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=b986c083"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import { Button } from "/src/components/ui/button.tsx";
import { Card, CardContent, CardDescription, CardTitle, CardHeader } from "/src/components/ui/card.tsx";
import { Input } from "/src/components/ui/input.tsx";
import { Label } from "/src/components/ui/label.tsx";
import { useSignIn } from "/src/app/features/auth/hooks/useSignIn.tsx";
import { useAuthToast } from "/src/app/features/auth/hooks/useAuthToasts.tsx";
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=b986c083";
export default function SignInCard() {
  _s();
  useAuthToast();
  const {
    email,
    password,
    handleLogin,
    handleChangeEmail,
    handleChangePassword,
    handleSubmit,
    isSubmitting,
    errors
  } = useSignIn();
  const emailInvalid = Boolean(errors.email);
  const passwordInvalid = Boolean(errors.password);
  return /* @__PURE__ */ jsxDEV("div", { className: "FormUI", children: /* @__PURE__ */ jsxDEV(Card, { children: [
    /* @__PURE__ */ jsxDEV(CardHeader, { children: [
      /* @__PURE__ */ jsxDEV(CardTitle, { className: "text-2xl text-center", children: "ログイン画面" }, void 0, false, {
        fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/auth/components/signInCard.tsx",
        lineNumber: 30,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(CardDescription, { children: /* @__PURE__ */ jsxDEV("p", { className: "text-center", children: "メールアドレスとパスワードを入力してサインイン" }, void 0, false, {
        fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/auth/components/signInCard.tsx",
        lineNumber: 32,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/auth/components/signInCard.tsx",
        lineNumber: 31,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/auth/components/signInCard.tsx",
      lineNumber: 29,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(CardContent, { children: /* @__PURE__ */ jsxDEV("form", { onSubmit: handleLogin, className: "grid gap-4", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "grid gap-2", children: [
        /* @__PURE__ */ jsxDEV(Label, { htmlFor: "email", children: "Email" }, void 0, false, {
          fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/auth/components/signInCard.tsx",
          lineNumber: 38,
          columnNumber: 15
        }, this),
        errors.form && /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-red-500", children: errors.form }, void 0, false, {
          fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/auth/components/signInCard.tsx",
          lineNumber: 39,
          columnNumber: 31
        }, this),
        /* @__PURE__ */ jsxDEV(
          Input,
          {
            id: "email",
            type: "email",
            value: email,
            onChange: (e) => handleChangeEmail(e.target.value),
            "aria-invalid": emailInvalid,
            placeholder: "メールアドレスを入力",
            className: emailInvalid ? "border-red-500 focus-visible:ring-red-500" : ""
          },
          void 0,
          false,
          {
            fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/auth/components/signInCard.tsx",
            lineNumber: 40,
            columnNumber: 15
          },
          this
        ),
        errors.email && /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-red-500", children: errors.email }, void 0, false, {
          fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/auth/components/signInCard.tsx",
          lineNumber: 49,
          columnNumber: 32
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/auth/components/signInCard.tsx",
        lineNumber: 37,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "grid gap-2", children: [
        /* @__PURE__ */ jsxDEV(Label, { htmlFor: "password", children: "Password" }, void 0, false, {
          fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/auth/components/signInCard.tsx",
          lineNumber: 52,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(
          Input,
          {
            id: "password",
            type: "password",
            value: password,
            onChange: (e) => handleChangePassword(e.target.value),
            "aria-invalid": passwordInvalid,
            className: passwordInvalid ? "border-red-500 focus-visible:ring-red-500" : "",
            placeholder: "パスワードを入力"
          },
          void 0,
          false,
          {
            fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/auth/components/signInCard.tsx",
            lineNumber: 53,
            columnNumber: 15
          },
          this
        ),
        errors.password && /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-red-500", children: errors.password }, void 0, false, {
          fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/auth/components/signInCard.tsx",
          lineNumber: 62,
          columnNumber: 35
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/auth/components/signInCard.tsx",
        lineNumber: 51,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
        /* @__PURE__ */ jsxDEV(Button, { type: "submit", disabled: !handleSubmit || isSubmitting, className: "w-full", children: isSubmitting ? "ログイン中..." : "ログイン" }, void 0, false, {
          fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/auth/components/signInCard.tsx",
          lineNumber: 65,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(
          Link,
          {
            to: "/signUp",
            className: "text-xs text-gray-500 mt-2 ml-auto underline hover:text-sm",
            children: "ユーザー登録されてない方はこちら"
          },
          void 0,
          false,
          {
            fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/auth/components/signInCard.tsx",
            lineNumber: 68,
            columnNumber: 15
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/auth/components/signInCard.tsx",
        lineNumber: 64,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/auth/components/signInCard.tsx",
      lineNumber: 36,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/auth/components/signInCard.tsx",
      lineNumber: 35,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/auth/components/signInCard.tsx",
    lineNumber: 28,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/auth/components/signInCard.tsx",
    lineNumber: 27,
    columnNumber: 5
  }, this);
}
_s(SignInCard, "jCisYZk+7hTqWBG7m1HAM8BJG5c=", false, function() {
  return [useAuthToast, useSignIn];
});
_c = SignInCard;
var _c;
$RefreshReg$(_c, "SignInCard");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/auth/components/signInCard.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/auth/components/signInCard.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/auth/components/signInCard.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNkJVOztBQTdCVixTQUFTQSxjQUFjO0FBQ3ZCLFNBQVNDLE1BQU1DLGFBQWFDLGlCQUFpQkMsV0FBV0Msa0JBQWtCO0FBQzFFLFNBQVNDLGFBQWE7QUFDdEIsU0FBU0MsYUFBYTtBQUN0QixTQUFTQyxpQkFBaUI7QUFDMUIsU0FBU0Msb0JBQW9CO0FBQzdCLFNBQVNDLFlBQVk7QUFDckIsd0JBQXdCQyxhQUFhO0FBQUFDLEtBQUE7QUFDbkNILGVBQWE7QUFFYixRQUFNO0FBQUEsSUFDSkk7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsRUFDRixJQUFJWixVQUFVO0FBR2QsUUFBTWEsZUFBZUMsUUFBUUYsT0FBT1AsS0FBSztBQUN6QyxRQUFNVSxrQkFBa0JELFFBQVFGLE9BQU9OLFFBQVE7QUFFL0MsU0FDRSx1QkFBQyxTQUFJLFdBQVUsVUFDYixpQ0FBQyxRQUNDO0FBQUEsMkJBQUMsY0FDQztBQUFBLDZCQUFDLGFBQVUsV0FBVSx3QkFBdUIsc0JBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBa0Q7QUFBQSxNQUNsRCx1QkFBQyxtQkFDQyxpQ0FBQyxPQUFFLFdBQVUsZUFBYyx1Q0FBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFrRCxLQURwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxTQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FLQTtBQUFBLElBQ0EsdUJBQUMsZUFDQyxpQ0FBQyxVQUFLLFVBQVVDLGFBQWEsV0FBVSxjQUNyQztBQUFBLDZCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEsK0JBQUMsU0FBTSxTQUFRLFNBQVEscUJBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNEI7QUFBQSxRQUMzQkssT0FBT0ksUUFBUSx1QkFBQyxPQUFFLFdBQVUsd0JBQXdCSixpQkFBT0ksUUFBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpRDtBQUFBLFFBQ2pFO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxJQUFHO0FBQUEsWUFDSCxNQUFLO0FBQUEsWUFDTCxPQUFPWDtBQUFBQSxZQUNQLFVBQVUsQ0FBQ1ksTUFBTVQsa0JBQWtCUyxFQUFFQyxPQUFPQyxLQUFLO0FBQUEsWUFDakQsZ0JBQWNOO0FBQUFBLFlBQ2QsYUFBWTtBQUFBLFlBQ1osV0FBV0EsZUFBZSw4Q0FBOEM7QUFBQTtBQUFBLFVBUDFFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU82RTtBQUFBLFFBRTVFRCxPQUFPUCxTQUFTLHVCQUFDLE9BQUUsV0FBVSx3QkFBd0JPLGlCQUFPUCxTQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtEO0FBQUEsV0FackU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWFBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsY0FDYjtBQUFBLCtCQUFDLFNBQU0sU0FBUSxZQUFXLHdCQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtDO0FBQUEsUUFDbEM7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLElBQUc7QUFBQSxZQUNILE1BQUs7QUFBQSxZQUNMLE9BQU9DO0FBQUFBLFlBQ1AsVUFBVSxDQUFDVyxNQUFNUixxQkFBcUJRLEVBQUVDLE9BQU9DLEtBQUs7QUFBQSxZQUNwRCxnQkFBY0o7QUFBQUEsWUFDZCxXQUFXQSxrQkFBa0IsOENBQThDO0FBQUEsWUFDM0UsYUFBWTtBQUFBO0FBQUEsVUFQZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFPd0I7QUFBQSxRQUV2QkgsT0FBT04sWUFBWSx1QkFBQyxPQUFFLFdBQVUsd0JBQXdCTSxpQkFBT04sWUFBNUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFxRDtBQUFBLFdBWDNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFZQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsK0JBQUMsVUFBTyxNQUFLLFVBQVMsVUFBVSxDQUFDSSxnQkFBZ0JDLGNBQWMsV0FBVSxVQUN0RUEseUJBQWUsYUFBYSxVQUQvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxJQUFHO0FBQUEsWUFDSCxXQUFVO0FBQUEsWUFBNEQ7QUFBQTtBQUFBLFVBRnhFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUtBO0FBQUEsV0FURjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBVUE7QUFBQSxTQXRDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBdUNBLEtBeENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F5Q0E7QUFBQSxPQWhERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBaURBLEtBbERGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FtREE7QUFFSjtBQUFDUCxHQXhFdUJELFlBQVU7QUFBQSxVQUNoQ0YsY0FXSUQsU0FBUztBQUFBO0FBQUFvQixLQVpTakI7QUFBVSxJQUFBaUI7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIkJ1dHRvbiIsIkNhcmQiLCJDYXJkQ29udGVudCIsIkNhcmREZXNjcmlwdGlvbiIsIkNhcmRUaXRsZSIsIkNhcmRIZWFkZXIiLCJJbnB1dCIsIkxhYmVsIiwidXNlU2lnbkluIiwidXNlQXV0aFRvYXN0IiwiTGluayIsIlNpZ25JbkNhcmQiLCJfcyIsImVtYWlsIiwicGFzc3dvcmQiLCJoYW5kbGVMb2dpbiIsImhhbmRsZUNoYW5nZUVtYWlsIiwiaGFuZGxlQ2hhbmdlUGFzc3dvcmQiLCJoYW5kbGVTdWJtaXQiLCJpc1N1Ym1pdHRpbmciLCJlcnJvcnMiLCJlbWFpbEludmFsaWQiLCJCb29sZWFuIiwicGFzc3dvcmRJbnZhbGlkIiwiZm9ybSIsImUiLCJ0YXJnZXQiLCJ2YWx1ZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbInNpZ25JbkNhcmQudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEJ1dHRvbiB9IGZyb20gJ0AvY29tcG9uZW50cy91aS9idXR0b24nO1xuaW1wb3J0IHsgQ2FyZCwgQ2FyZENvbnRlbnQsIENhcmREZXNjcmlwdGlvbiwgQ2FyZFRpdGxlLCBDYXJkSGVhZGVyIH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL2NhcmQnO1xuaW1wb3J0IHsgSW5wdXQgfSBmcm9tICdAL2NvbXBvbmVudHMvdWkvaW5wdXQnO1xuaW1wb3J0IHsgTGFiZWwgfSBmcm9tICdAL2NvbXBvbmVudHMvdWkvbGFiZWwnO1xuaW1wb3J0IHsgdXNlU2lnbkluIH0gZnJvbSAnQC9hcHAvZmVhdHVyZXMvYXV0aC9ob29rcy91c2VTaWduSW4nO1xuaW1wb3J0IHsgdXNlQXV0aFRvYXN0IH0gZnJvbSAnQC9hcHAvZmVhdHVyZXMvYXV0aC9ob29rcy91c2VBdXRoVG9hc3RzJztcbmltcG9ydCB7IExpbmsgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFNpZ25JbkNhcmQoKSB7XG4gIHVzZUF1dGhUb2FzdCgpO1xuICAvLyDjgqvjgrnjgr/jg6Djg5Xjg4Pjgq/jgYvjgonnirbmhYvjgajplqLmlbDjgpLlj5blvpdcbiAgY29uc3Qge1xuICAgIGVtYWlsLFxuICAgIHBhc3N3b3JkLFxuICAgIGhhbmRsZUxvZ2luLFxuICAgIGhhbmRsZUNoYW5nZUVtYWlsLFxuICAgIGhhbmRsZUNoYW5nZVBhc3N3b3JkLFxuICAgIGhhbmRsZVN1Ym1pdCxcbiAgICBpc1N1Ym1pdHRpbmcsXG4gICAgZXJyb3JzLFxuICB9ID0gdXNlU2lnbkluKCk7XG5cbiAgLy8g44Ko44Op44O844Gu5pyJ54Sh44KS5Yik5a6a44GZ44KL44Gf44KB44Gu44Ot44O844Kr44Or5aSJ5pWw44CCZW1haWzjgahwYXNzd29yZOOBruS4oeaWueOBruOCqOODqeODvOOBjOOBguOCi+OBi+OBqeOBhuOBi+OCkuWIpOWumuOBl+OBpuOAgWVtYWlsSW52YWxpZOOBqHBhc3N3b3JkSW52YWxpZOOBq+OBneOCjOOBnuOCjOecn+WBveWApOOCkuOCu+ODg+ODiOOBmeOCi+OAglxuICBjb25zdCBlbWFpbEludmFsaWQgPSBCb29sZWFuKGVycm9ycy5lbWFpbCk7XG4gIGNvbnN0IHBhc3N3b3JkSW52YWxpZCA9IEJvb2xlYW4oZXJyb3JzLnBhc3N3b3JkKTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiRm9ybVVJXCI+XG4gICAgICA8Q2FyZD5cbiAgICAgICAgPENhcmRIZWFkZXI+XG4gICAgICAgICAgPENhcmRUaXRsZSBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCB0ZXh0LWNlbnRlclwiPuODreOCsOOCpOODs+eUu+mdojwvQ2FyZFRpdGxlPlxuICAgICAgICAgIDxDYXJkRGVzY3JpcHRpb24+XG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlclwiPuODoeODvOODq+OCouODieODrOOCueOBqOODkeOCueODr+ODvOODieOCkuWFpeWKm+OBl+OBpuOCteOCpOODs+OCpOODszwvcD5cbiAgICAgICAgICA8L0NhcmREZXNjcmlwdGlvbj5cbiAgICAgICAgPC9DYXJkSGVhZGVyPlxuICAgICAgICA8Q2FyZENvbnRlbnQ+XG4gICAgICAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZUxvZ2lufSBjbGFzc05hbWU9XCJncmlkIGdhcC00XCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgPExhYmVsIGh0bWxGb3I9XCJlbWFpbFwiPkVtYWlsPC9MYWJlbD5cbiAgICAgICAgICAgICAge2Vycm9ycy5mb3JtICYmIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1yZWQtNTAwXCI+e2Vycm9ycy5mb3JtfTwvcD59XG4gICAgICAgICAgICAgIDxJbnB1dFxuICAgICAgICAgICAgICAgIGlkPVwiZW1haWxcIlxuICAgICAgICAgICAgICAgIHR5cGU9XCJlbWFpbFwiXG4gICAgICAgICAgICAgICAgdmFsdWU9e2VtYWlsfVxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlQ2hhbmdlRW1haWwoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgIGFyaWEtaW52YWxpZD17ZW1haWxJbnZhbGlkfVxuICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwi44Oh44O844Or44Ki44OJ44Os44K544KS5YWl5YqbXCJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2VtYWlsSW52YWxpZCA/ICdib3JkZXItcmVkLTUwMCBmb2N1cy12aXNpYmxlOnJpbmctcmVkLTUwMCcgOiAnJ31cbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAge2Vycm9ycy5lbWFpbCAmJiA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtcmVkLTUwMFwiPntlcnJvcnMuZW1haWx9PC9wPn1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdhcC0yXCI+XG4gICAgICAgICAgICAgIDxMYWJlbCBodG1sRm9yPVwicGFzc3dvcmRcIj5QYXNzd29yZDwvTGFiZWw+XG4gICAgICAgICAgICAgIDxJbnB1dFxuICAgICAgICAgICAgICAgIGlkPVwicGFzc3dvcmRcIlxuICAgICAgICAgICAgICAgIHR5cGU9XCJwYXNzd29yZFwiXG4gICAgICAgICAgICAgICAgdmFsdWU9e3Bhc3N3b3JkfVxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlQ2hhbmdlUGFzc3dvcmQoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgIGFyaWEtaW52YWxpZD17cGFzc3dvcmRJbnZhbGlkfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17cGFzc3dvcmRJbnZhbGlkID8gJ2JvcmRlci1yZWQtNTAwIGZvY3VzLXZpc2libGU6cmluZy1yZWQtNTAwJyA6ICcnfVxuICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwi44OR44K544Ov44O844OJ44KS5YWl5YqbXCJcbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAge2Vycm9ycy5wYXNzd29yZCAmJiA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtcmVkLTUwMFwiPntlcnJvcnMucGFzc3dvcmR9PC9wPn1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sXCI+XG4gICAgICAgICAgICAgIDxCdXR0b24gdHlwZT1cInN1Ym1pdFwiIGRpc2FibGVkPXshaGFuZGxlU3VibWl0IHx8IGlzU3VibWl0dGluZ30gY2xhc3NOYW1lPVwidy1mdWxsXCI+XG4gICAgICAgICAgICAgICAge2lzU3VibWl0dGluZyA/ICfjg63jgrDjgqTjg7PkuK0uLi4nIDogJ+ODreOCsOOCpOODsyd9XG4gICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgICA8TGlua1xuICAgICAgICAgICAgICAgIHRvPVwiL3NpZ25VcFwiXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwIG10LTIgbWwtYXV0byB1bmRlcmxpbmUgaG92ZXI6dGV4dC1zbVwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICDjg6bjg7zjgrbjg7znmbvpjLLjgZXjgozjgabjgarjgYTmlrnjga/jgZPjgaHjgolcbiAgICAgICAgICAgICAgPC9MaW5rPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9mb3JtPlxuICAgICAgICA8L0NhcmRDb250ZW50PlxuICAgICAgPC9DYXJkPlxuICAgIDwvZGl2PlxuICApO1xufVxuIl0sImZpbGUiOiIvVXNlcnMvaW5vdWV5dXVqaS9Db2xvck1pcnJvcl9SZS9mcm9udC9BcHBfZnJvbnQvc3JjL2FwcC9mZWF0dXJlcy9hdXRoL2NvbXBvbmVudHMvc2lnbkluQ2FyZC50c3gifQ==