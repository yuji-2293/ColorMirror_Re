import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/app/features/responses/components/createForm.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=b986c083"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import {
} from "/src/app/features/responses/types/Response.ts";
import { useCreateResponse } from "/src/app/features/responses/hooks/useCreateResponse.ts";
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=b986c083"; const useEffect = __vite__cjsImport3_react["useEffect"];
import { toast } from "/node_modules/.vite/deps/sonner.js?v=b986c083";
import { Spinner } from "/src/components/ui/spinner.tsx";
export const CreateForm = ({
  mood,
  selectedColorName,
  aiResponse,
  resetAll,
  resetAiResponseData,
  resetColors
}) => {
  _s();
  const { createResponse, isPending, isSuccess } = useCreateResponse();
  const handleCreateResponse = () => {
    if (isPending) return;
    const params = {
      color: {
        mood,
        color_name: selectedColorName
      },
      response: {
        ai_response: aiResponse
      }
    };
    createResponse(params);
  };
  useEffect(() => {
    if (isSuccess) {
      if (!isSuccess) return;
      resetAll();
      resetAiResponseData();
      resetColors();
      toast.success("保存が成功しました！");
    }
  }, [isSuccess, resetAll, resetAiResponseData, resetColors]);
  return /* @__PURE__ */ jsxDEV("div", { className: "STEP3 flex flex-col items-center justify-center gap-4 bg-emerald-200/90 w-full m-2 p-2 rounded-2xl shadow-2xl border border-white/60 relative", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "FormHeader", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col  text-center", children: [
        /* @__PURE__ */ jsxDEV("p", { children: "~STEP3~" }, void 0, false, {
          fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/responses/components/createForm.tsx",
          lineNumber: 50,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { children: "生成されたレスポンスをサーバーに保存する" }, void 0, false, {
          fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/responses/components/createForm.tsx",
          lineNumber: 51,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/responses/components/createForm.tsx",
        lineNumber: 49,
        columnNumber: 9
      }, this),
      isPending && /* @__PURE__ */ jsxDEV("div", { className: "absolute inset-0 bg-white/60 backdrop-blur-sm flex items-center justify-center z-10", children: /* @__PURE__ */ jsxDEV(Spinner, {}, void 0, false, {
        fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/responses/components/createForm.tsx",
        lineNumber: 56,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/responses/components/createForm.tsx",
        lineNumber: 55,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/responses/components/createForm.tsx",
      lineNumber: 48,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "my-4", children: /* @__PURE__ */ jsxDEV(
      "button",
      {
        onClick: handleCreateResponse,
        className: "w-full  px-12 py-3 bg-emerald-300 text-white rounded-2xl shadow-2xl border-2 border-white font-bold text-xl disabled:bg-gray-300 hover:scale-110 hover:bg-emerald-700 hover:text-white",
        disabled: !mood || !selectedColorName || !aiResponse || isPending,
        children: "保存する"
      },
      void 0,
      false,
      {
        fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/responses/components/createForm.tsx",
        lineNumber: 62,
        columnNumber: 9
      },
      this
    ) }, void 0, false, {
      fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/responses/components/createForm.tsx",
      lineNumber: 61,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/responses/components/createForm.tsx",
    lineNumber: 47,
    columnNumber: 5
  }, this);
};
_s(CreateForm, "TQppD7taJTykXDGnR3Hh8s2HDf4=", false, function() {
  return [useCreateResponse];
});
_c = CreateForm;
var _c;
$RefreshReg$(_c, "CreateForm");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/responses/components/createForm.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/responses/components/createForm.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/responses/components/createForm.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaURVOztBQWpEVjtBQUFBLE9BR087QUFDUCxTQUFTQSx5QkFBeUI7QUFDbEMsU0FBU0MsaUJBQWlCO0FBQzFCLFNBQVNDLGFBQWE7QUFDdEIsU0FBU0MsZUFBZTtBQUVqQixhQUFNQyxhQUFhQSxDQUFDO0FBQUEsRUFDekJDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQ2UsTUFBTTtBQUFBQyxLQUFBO0FBQ3JCLFFBQU0sRUFBRUMsZ0JBQWdCQyxXQUFXQyxVQUFVLElBQUlkLGtCQUFrQjtBQUNuRSxRQUFNZSx1QkFBdUJBLE1BQU07QUFDakMsUUFBSUYsVUFBVztBQUVmLFVBQU1HLFNBQW1DO0FBQUEsTUFDdkNDLE9BQU87QUFBQSxRQUNMWjtBQUFBQSxRQUNBYSxZQUFZWjtBQUFBQSxNQUNkO0FBQUEsTUFDQWEsVUFBVTtBQUFBLFFBQ1JDLGFBQWFiO0FBQUFBLE1BQ2Y7QUFBQSxJQUNGO0FBQ0FLLG1CQUFlSSxNQUFNO0FBQUEsRUFDdkI7QUFFQWYsWUFBVSxNQUFNO0FBQ2QsUUFBSWEsV0FBVztBQUNiLFVBQUksQ0FBQ0EsVUFBVztBQUVoQk4sZUFBUztBQUNUQywwQkFBb0I7QUFDcEJDLGtCQUFZO0FBR1pSLFlBQU1tQixRQUFRLFlBQVk7QUFBQSxJQUM1QjtBQUFBLEVBQ0YsR0FBRyxDQUFDUCxXQUFXTixVQUFVQyxxQkFBcUJDLFdBQVcsQ0FBQztBQUMxRCxTQUNFLHVCQUFDLFNBQUksV0FBVSxpSkFDYjtBQUFBLDJCQUFDLFNBQUksV0FBVSxjQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLDhCQUNiO0FBQUEsK0JBQUMsT0FBRSx1QkFBSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQVU7QUFBQSxRQUNWLHVCQUFDLE9BQUUsb0NBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1QjtBQUFBLFdBRnpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BRUNHLGFBQ0MsdUJBQUMsU0FBSSxXQUFVLHVGQUNiLGlDQUFDLGFBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFRLEtBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FUSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBV0E7QUFBQSxJQUVBLHVCQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxTQUFTRTtBQUFBQSxRQUNULFdBQVU7QUFBQSxRQUNWLFVBQVUsQ0FBQ1YsUUFBUSxDQUFDQyxxQkFBcUIsQ0FBQ0MsY0FBY007QUFBQUEsUUFBVTtBQUFBO0FBQUEsTUFIcEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBTUEsS0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBUUE7QUFBQSxPQXRCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBdUJBO0FBRUo7QUFBRUYsR0E5RFdQLFlBQVU7QUFBQSxVQVE0QkosaUJBQWlCO0FBQUE7QUFBQXNCLEtBUnZEbEI7QUFBVSxJQUFBa0I7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZUNyZWF0ZVJlc3BvbnNlIiwidXNlRWZmZWN0IiwidG9hc3QiLCJTcGlubmVyIiwiQ3JlYXRlRm9ybSIsIm1vb2QiLCJzZWxlY3RlZENvbG9yTmFtZSIsImFpUmVzcG9uc2UiLCJyZXNldEFsbCIsInJlc2V0QWlSZXNwb25zZURhdGEiLCJyZXNldENvbG9ycyIsIl9zIiwiY3JlYXRlUmVzcG9uc2UiLCJpc1BlbmRpbmciLCJpc1N1Y2Nlc3MiLCJoYW5kbGVDcmVhdGVSZXNwb25zZSIsInBhcmFtcyIsImNvbG9yIiwiY29sb3JfbmFtZSIsInJlc3BvbnNlIiwiYWlfcmVzcG9uc2UiLCJzdWNjZXNzIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiY3JlYXRlRm9ybS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcbiAgdHlwZSBDcmVhdGVGb3JtUHJvcHMsXG4gIHR5cGUgQ3JlYXRlUmVzcG9uc2VEYXRhUGFyYW1zLFxufSBmcm9tICdAL2FwcC9mZWF0dXJlcy9yZXNwb25zZXMvdHlwZXMvUmVzcG9uc2UnO1xuaW1wb3J0IHsgdXNlQ3JlYXRlUmVzcG9uc2UgfSBmcm9tICdAL2FwcC9mZWF0dXJlcy9yZXNwb25zZXMvaG9va3MvdXNlQ3JlYXRlUmVzcG9uc2UnO1xuaW1wb3J0IHsgdXNlRWZmZWN0IH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdG9hc3QgfSBmcm9tICdzb25uZXInO1xuaW1wb3J0IHsgU3Bpbm5lciB9IGZyb20gJ0AvY29tcG9uZW50cy91aS9zcGlubmVyJztcblxuZXhwb3J0IGNvbnN0IENyZWF0ZUZvcm0gPSAoe1xuICBtb29kLFxuICBzZWxlY3RlZENvbG9yTmFtZSxcbiAgYWlSZXNwb25zZSxcbiAgcmVzZXRBbGwsXG4gIHJlc2V0QWlSZXNwb25zZURhdGEsXG4gIHJlc2V0Q29sb3JzLFxufTogQ3JlYXRlRm9ybVByb3BzKSA9PiB7XG4gIGNvbnN0IHsgY3JlYXRlUmVzcG9uc2UsIGlzUGVuZGluZywgaXNTdWNjZXNzIH0gPSB1c2VDcmVhdGVSZXNwb25zZSgpO1xuICBjb25zdCBoYW5kbGVDcmVhdGVSZXNwb25zZSA9ICgpID0+IHtcbiAgICBpZiAoaXNQZW5kaW5nKSByZXR1cm47XG4gICAgLy8gcGFyYW1z44KS5L2c5oiQ44GX44GmQVBJ44Oq44Kv44Ko44K544OI44KS6YCB44KLXG4gICAgY29uc3QgcGFyYW1zOiBDcmVhdGVSZXNwb25zZURhdGFQYXJhbXMgPSB7XG4gICAgICBjb2xvcjoge1xuICAgICAgICBtb29kOiBtb29kLFxuICAgICAgICBjb2xvcl9uYW1lOiBzZWxlY3RlZENvbG9yTmFtZSxcbiAgICAgIH0sXG4gICAgICByZXNwb25zZToge1xuICAgICAgICBhaV9yZXNwb25zZTogYWlSZXNwb25zZSxcbiAgICAgIH0sXG4gICAgfTtcbiAgICBjcmVhdGVSZXNwb25zZShwYXJhbXMpO1xuICB9O1xuICAvLyDjg6zjgrnjg53jg7Pjgrnjga7kv53lrZjjgavmiJDlip/jgZfjgZ/jgonjgIHjg5Xjgqnjg7zjg6Djga7nirbmhYvjgpLjg6rjgrvjg4Pjg4jjgZfjgabjgIHjg4jjg7zjgrnjg4jpgJrnn6XjgpLooajnpLrjgZnjgotcbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoaXNTdWNjZXNzKSB7XG4gICAgICBpZiAoIWlzU3VjY2VzcykgcmV0dXJuO1xuICAgICAgLy8g5oiQ5Yqf44GX44Gf44KJ44CB44OV44Kp44O844Og44Gu54q25oWL44KS44Oq44K744OD44OI44GZ44KLXG4gICAgICByZXNldEFsbCgpO1xuICAgICAgcmVzZXRBaVJlc3BvbnNlRGF0YSgpO1xuICAgICAgcmVzZXRDb2xvcnMoKTtcblxuICAgICAgLy8g44OI44O844K544OI6YCa55+l44KS6KGo56S644GZ44KLXG4gICAgICB0b2FzdC5zdWNjZXNzKCfkv53lrZjjgYzmiJDlip/jgZfjgb7jgZfjgZ/vvIEnKTtcbiAgICB9XG4gIH0sIFtpc1N1Y2Nlc3MsIHJlc2V0QWxsLCByZXNldEFpUmVzcG9uc2VEYXRhLCByZXNldENvbG9yc10pO1xuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiU1RFUDMgZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTQgYmctZW1lcmFsZC0yMDAvOTAgdy1mdWxsIG0tMiBwLTIgcm91bmRlZC0yeGwgc2hhZG93LTJ4bCBib3JkZXIgYm9yZGVyLXdoaXRlLzYwIHJlbGF0aXZlXCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIkZvcm1IZWFkZXJcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sICB0ZXh0LWNlbnRlclwiPlxuICAgICAgICAgIDxwPn5TVEVQM348L3A+XG4gICAgICAgICAgPHA+55Sf5oiQ44GV44KM44Gf44Os44K544Od44Oz44K544KS44K144O844OQ44O844Gr5L+d5a2Y44GZ44KLPC9wPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7aXNQZW5kaW5nICYmIChcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIGluc2V0LTAgYmctd2hpdGUvNjAgYmFja2Ryb3AtYmx1ci1zbSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB6LTEwXCI+XG4gICAgICAgICAgICA8U3Bpbm5lciAvPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICApfVxuICAgICAgPC9kaXY+XG5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXktNFwiPlxuICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgb25DbGljaz17aGFuZGxlQ3JlYXRlUmVzcG9uc2V9XG4gICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsICBweC0xMiBweS0zIGJnLWVtZXJhbGQtMzAwIHRleHQtd2hpdGUgcm91bmRlZC0yeGwgc2hhZG93LTJ4bCBib3JkZXItMiBib3JkZXItd2hpdGUgZm9udC1ib2xkIHRleHQteGwgZGlzYWJsZWQ6YmctZ3JheS0zMDAgaG92ZXI6c2NhbGUtMTEwIGhvdmVyOmJnLWVtZXJhbGQtNzAwIGhvdmVyOnRleHQtd2hpdGVcIlxuICAgICAgICAgIGRpc2FibGVkPXshbW9vZCB8fCAhc2VsZWN0ZWRDb2xvck5hbWUgfHwgIWFpUmVzcG9uc2UgfHwgaXNQZW5kaW5nfVxuICAgICAgICA+XG4gICAgICAgICAg5L+d5a2Y44GZ44KLXG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICk7XG59O1xuIl0sImZpbGUiOiIvVXNlcnMvaW5vdWV5dXVqaS9Db2xvck1pcnJvcl9SZS9mcm9udC9BcHBfZnJvbnQvc3JjL2FwcC9mZWF0dXJlcy9yZXNwb25zZXMvY29tcG9uZW50cy9jcmVhdGVGb3JtLnRzeCJ9