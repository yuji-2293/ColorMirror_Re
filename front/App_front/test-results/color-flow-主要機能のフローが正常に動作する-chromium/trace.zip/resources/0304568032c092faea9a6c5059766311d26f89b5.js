import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/public/components/SignUp.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=b986c083"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import SignUpCard from "/src/app/features/auth/components/signUpCard.tsx";
export const SignUp = () => {
  return /* @__PURE__ */ jsxDEV(SignUpCard, {}, void 0, false, {
    fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/pages/public/components/SignUp.tsx",
    lineNumber: 3,
    columnNumber: 10
  }, this);
};
_c = SignUp;
var _c;
$RefreshReg$(_c, "SignUp");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/pages/public/components/SignUp.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/pages/public/components/SignUp.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/pages/public/components/SignUp.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBRVM7QUFGVCxPQUFPQSxnQkFBZ0I7QUFDaEIsYUFBTUMsU0FBU0EsTUFBTTtBQUMxQixTQUFPLHVCQUFDLGdCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBVztBQUNwQjtBQUFFQyxLQUZXRDtBQUFNLElBQUFDO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJTaWduVXBDYXJkIiwiU2lnblVwIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiU2lnblVwLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgU2lnblVwQ2FyZCBmcm9tICdAL2FwcC9mZWF0dXJlcy9hdXRoL2NvbXBvbmVudHMvc2lnblVwQ2FyZCc7XG5leHBvcnQgY29uc3QgU2lnblVwID0gKCkgPT4ge1xuICByZXR1cm4gPFNpZ25VcENhcmQgLz47XG59O1xuIl0sImZpbGUiOiIvVXNlcnMvaW5vdWV5dXVqaS9Db2xvck1pcnJvcl9SZS9mcm9udC9BcHBfZnJvbnQvc3JjL3BhZ2VzL3B1YmxpYy9jb21wb25lbnRzL1NpZ25VcC50c3gifQ==