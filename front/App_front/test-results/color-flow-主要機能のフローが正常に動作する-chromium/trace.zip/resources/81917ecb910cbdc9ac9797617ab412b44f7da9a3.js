import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/public/PublicLayout.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=b986c083"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import { Header } from "/src/components/layout/header.tsx";
import { Footer } from "/src/components/layout/footer.tsx";
import { Outlet, Navigate } from "/node_modules/.vite/deps/react-router-dom.js?v=b986c083";
import { useAuthStore } from "/src/app/store/useAuthStore.ts";
import { Loading } from "/src/pages/public/components/Loading.tsx";
export default function PublicLayout() {
  _s();
  const { authStatus } = useAuthStore();
  if (authStatus === "unknown") {
    return /* @__PURE__ */ jsxDEV(Loading, {}, void 0, false, {
      fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/pages/public/PublicLayout.tsx",
      lineNumber: 10,
      columnNumber: 12
    }, this);
  }
  if (authStatus === "authenticated") {
    return /* @__PURE__ */ jsxDEV(Navigate, { to: "/", replace: true }, void 0, false, {
      fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/pages/public/PublicLayout.tsx",
      lineNumber: 14,
      columnNumber: 12
    }, this);
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "min-h-screen overflow-auto", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "min-h-screen  bg-[url('/assets/topImage.png')] bg-cover bg-center", children: /* @__PURE__ */ jsxDEV("div", { className: "min-h-screen bg-white/30", children: /* @__PURE__ */ jsxDEV("div", { className: "min-h-screen flex flex-col", children: [
      /* @__PURE__ */ jsxDEV(Header, {}, void 0, false, {
        fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/pages/public/PublicLayout.tsx",
        lineNumber: 21,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("main", { className: "flex-1 max-w-7xl w-full px-6 py-8 mx-auto", children: /* @__PURE__ */ jsxDEV(Outlet, {}, void 0, false, {
        fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/pages/public/PublicLayout.tsx",
        lineNumber: 23,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/pages/public/PublicLayout.tsx",
        lineNumber: 22,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/pages/public/PublicLayout.tsx",
      lineNumber: 20,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/pages/public/PublicLayout.tsx",
      lineNumber: 19,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/pages/public/PublicLayout.tsx",
      lineNumber: 18,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Footer, {}, void 0, false, {
      fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/pages/public/PublicLayout.tsx",
      lineNumber: 28,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/pages/public/PublicLayout.tsx",
    lineNumber: 17,
    columnNumber: 5
  }, this);
}
_s(PublicLayout, "EzIMPR6Xhk+6hxfARgp5FTrB4cI=", false, function() {
  return [useAuthStore];
});
_c = PublicLayout;
var _c;
$RefreshReg$(_c, "PublicLayout");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/pages/public/PublicLayout.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/pages/public/PublicLayout.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/pages/public/PublicLayout.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBU1c7O0FBVFgsU0FBU0EsY0FBYztBQUN2QixTQUFTQyxjQUFjO0FBRXZCLFNBQVNDLFFBQVFDLGdCQUFnQjtBQUNqQyxTQUFTQyxvQkFBb0I7QUFDN0IsU0FBU0MsZUFBZTtBQUN4Qix3QkFBd0JDLGVBQWU7QUFBQUMsS0FBQTtBQUNyQyxRQUFNLEVBQUVDLFdBQVcsSUFBSUosYUFBYTtBQUNwQyxNQUFJSSxlQUFlLFdBQVc7QUFDNUIsV0FBTyx1QkFBQyxhQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBUTtBQUFBLEVBQ2pCO0FBQ0EsTUFBSUEsZUFBZSxpQkFBaUI7QUFFbEMsV0FBTyx1QkFBQyxZQUFTLElBQUcsS0FBSSxTQUFPLFFBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBd0I7QUFBQSxFQUNqQztBQUNBLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLDhCQUNiO0FBQUEsMkJBQUMsU0FBSSxXQUFVLHFFQUNiLGlDQUFDLFNBQUksV0FBVSw0QkFDYixpQ0FBQyxTQUFJLFdBQVUsOEJBQ2I7QUFBQSw2QkFBQyxZQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBTztBQUFBLE1BQ1AsdUJBQUMsVUFBSyxXQUFVLDZDQUNkLGlDQUFDLFlBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFPLEtBRFQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBS0EsS0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBT0EsS0FSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBU0E7QUFBQSxJQUNBLHVCQUFDLFlBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFPO0FBQUEsT0FYVDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBWUE7QUFFSjtBQUFDRCxHQXhCdUJELGNBQVk7QUFBQSxVQUNYRixZQUFZO0FBQUE7QUFBQUssS0FEYkg7QUFBWSxJQUFBRztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiSGVhZGVyIiwiRm9vdGVyIiwiT3V0bGV0IiwiTmF2aWdhdGUiLCJ1c2VBdXRoU3RvcmUiLCJMb2FkaW5nIiwiUHVibGljTGF5b3V0IiwiX3MiLCJhdXRoU3RhdHVzIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiUHVibGljTGF5b3V0LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBIZWFkZXIgfSBmcm9tICdAL2NvbXBvbmVudHMvbGF5b3V0L2hlYWRlcic7XG5pbXBvcnQgeyBGb290ZXIgfSBmcm9tICdAL2NvbXBvbmVudHMvbGF5b3V0L2Zvb3Rlcic7XG5cbmltcG9ydCB7IE91dGxldCwgTmF2aWdhdGUgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcbmltcG9ydCB7IHVzZUF1dGhTdG9yZSB9IGZyb20gJ0AvYXBwL3N0b3JlL3VzZUF1dGhTdG9yZSc7XG5pbXBvcnQgeyBMb2FkaW5nIH0gZnJvbSAnQC9wYWdlcy9wdWJsaWMvY29tcG9uZW50cy9Mb2FkaW5nJztcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFB1YmxpY0xheW91dCgpIHtcbiAgY29uc3QgeyBhdXRoU3RhdHVzIH0gPSB1c2VBdXRoU3RvcmUoKTtcbiAgaWYgKGF1dGhTdGF0dXMgPT09ICd1bmtub3duJykge1xuICAgIHJldHVybiA8TG9hZGluZyAvPjtcbiAgfVxuICBpZiAoYXV0aFN0YXR1cyA9PT0gJ2F1dGhlbnRpY2F0ZWQnKSB7XG4gICAgLy8g6KqN6Ki844GV44KM44Gm44GE44KL5aC05ZCI44CB44Ob44O844Og44Oa44O844K444Gr44Oq44OA44Kk44Os44Kv44OIXG4gICAgcmV0dXJuIDxOYXZpZ2F0ZSB0bz1cIi9cIiByZXBsYWNlIC8+O1xuICB9XG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJtaW4taC1zY3JlZW4gb3ZlcmZsb3ctYXV0b1wiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJtaW4taC1zY3JlZW4gIGJnLVt1cmwoJy9hc3NldHMvdG9wSW1hZ2UucG5nJyldIGJnLWNvdmVyIGJnLWNlbnRlclwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi1oLXNjcmVlbiBiZy13aGl0ZS8zMFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLWgtc2NyZWVuIGZsZXggZmxleC1jb2xcIj5cbiAgICAgICAgICAgIDxIZWFkZXIgLz5cbiAgICAgICAgICAgIDxtYWluIGNsYXNzTmFtZT1cImZsZXgtMSBtYXgtdy03eGwgdy1mdWxsIHB4LTYgcHktOCBteC1hdXRvXCI+XG4gICAgICAgICAgICAgIDxPdXRsZXQgLz5cbiAgICAgICAgICAgIDwvbWFpbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICAgIDxGb290ZXIgLz5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2lub3VleXV1amkvQ29sb3JNaXJyb3JfUmUvZnJvbnQvQXBwX2Zyb250L3NyYy9wYWdlcy9wdWJsaWMvUHVibGljTGF5b3V0LnRzeCJ9