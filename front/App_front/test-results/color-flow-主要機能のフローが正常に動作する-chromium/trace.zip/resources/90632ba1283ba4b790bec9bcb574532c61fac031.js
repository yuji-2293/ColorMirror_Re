import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/app/features/responses/components/responsesForm.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=b986c083"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import {} from "/src/app/features/responses/types/Response.ts";
import __vite__cjsImport2_react from "/node_modules/.vite/deps/react.js?v=b986c083"; const useEffect = __vite__cjsImport2_react["useEffect"];
import { toast } from "/node_modules/.vite/deps/sonner.js?v=b986c083";
import { Spinner } from "/src/components/ui/spinner.tsx";
import {} from "/src/app/features/responses/types/Response.ts";
export const ResponsesForm = ({
  mood,
  selectedColorName,
  setAiResponse,
  aiResponseData,
  generateResponse,
  isPending,
  isSuccess
}) => {
  _s();
  const handleGenerateResponse = () => {
    if (isPending) return;
    const params = {
      response: {
        mood,
        color_name: selectedColorName
      }
    };
    generateResponse(params);
  };
  useEffect(() => {
    if (aiResponseData) {
      setAiResponse(aiResponseData);
    }
  }, [aiResponseData, setAiResponse]);
  useEffect(() => {
    if (isSuccess) {
      if (!isSuccess) return;
      toast.success("AIからのレスポンスの生成に成功しました！");
    }
  }, [isSuccess]);
  return /* @__PURE__ */ jsxDEV("div", { className: "STEP2 flex flex-col items-center justify-center bg-sky-200/90 w-full m-2 p-2 rounded-2xl shadow-2xl border border-white/60 relative", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "FormHeader", children: /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col  text-center", children: [
      /* @__PURE__ */ jsxDEV("p", { children: "~STEP2~" }, void 0, false, {
        fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/responses/components/responsesForm.tsx",
        lineNumber: 45,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("p", { children: "選択したColorを基にAIにコメントを生成を依頼" }, void 0, false, {
        fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/responses/components/responsesForm.tsx",
        lineNumber: 46,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/responses/components/responsesForm.tsx",
      lineNumber: 44,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/responses/components/responsesForm.tsx",
      lineNumber: 43,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-center p-4 m-4", children: [
      /* @__PURE__ */ jsxDEV(
        "button",
        {
          onClick: handleGenerateResponse,
          disabled: !mood || !selectedColorName || isPending,
          className: "w-full px-10 py-4 bg-cyan-300 text-white rounded-2xl shadow-2xl border-2 border-white font-bold text-xl disabled:bg-gray-300 hover:scale-110 hover:bg-pink-300",
          children: aiResponseData ? "AIコメント再生成" : "AI生成開始"
        },
        void 0,
        false,
        {
          fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/responses/components/responsesForm.tsx",
          lineNumber: 50,
          columnNumber: 9
        },
        this
      ),
      isPending && /* @__PURE__ */ jsxDEV("div", { className: "absolute inset-0 bg-white/60 backdrop-blur-sm flex items-center justify-center z-10", children: /* @__PURE__ */ jsxDEV(Spinner, {}, void 0, false, {
        fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/responses/components/responsesForm.tsx",
        lineNumber: 60,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/responses/components/responsesForm.tsx",
        lineNumber: 59,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/responses/components/responsesForm.tsx",
      lineNumber: 49,
      columnNumber: 7
    }, this),
    isSuccess && /* @__PURE__ */ jsxDEV("div", { className: " sm:max-w-1/2 w-full bg-white/80 border border-gray-200 rounded-2xl shadow-2xl m-4 py-4 px-8 flex flex-col gap-2 justify-center items-center", children: [
      /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 mb-2", children: "あなたへのAIからのコメント" }, void 0, false, {
        fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/responses/components/responsesForm.tsx",
        lineNumber: 67,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "whitespace-pre-line text-sm leading-relaxed", children: aiResponseData }, void 0, false, {
        fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/responses/components/responsesForm.tsx",
        lineNumber: 68,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/responses/components/responsesForm.tsx",
      lineNumber: 66,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/responses/components/responsesForm.tsx",
    lineNumber: 42,
    columnNumber: 5
  }, this);
};
_s(ResponsesForm, "3ubReDTFssvu4DHeldAg55cW/CI=");
_c = ResponsesForm;
var _c;
$RefreshReg$(_c, "ResponsesForm");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/responses/components/responsesForm.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/responses/components/responsesForm.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/responses/components/responsesForm.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNENVOztBQTVDVixlQUFnRDtBQUNoRCxTQUFTQSxpQkFBaUI7QUFDMUIsU0FBU0MsYUFBYTtBQUN0QixTQUFTQyxlQUFlO0FBQ3hCLGVBQXVDO0FBQ2hDLGFBQU1DLGdCQUFnQkEsQ0FBQztBQUFBLEVBQzVCQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUNpQixNQUFNO0FBQUFDLEtBQUE7QUFDdkIsUUFBTUMseUJBQXlCQSxNQUFNO0FBQ25DLFFBQUlILFVBQVc7QUFDZixVQUFNSSxTQUFxQztBQUFBLE1BQ3pDQyxVQUFVO0FBQUEsUUFDUlY7QUFBQUEsUUFDQVcsWUFBWVY7QUFBQUEsTUFDZDtBQUFBLElBQ0Y7QUFFQUcscUJBQWlCSyxNQUFNO0FBQUEsRUFDekI7QUFHQWIsWUFBVSxNQUFNO0FBQ2QsUUFBSU8sZ0JBQWdCO0FBQ2xCRCxvQkFBY0MsY0FBYztBQUFBLElBQzlCO0FBQUEsRUFDRixHQUFHLENBQUNBLGdCQUFnQkQsYUFBYSxDQUFDO0FBRWxDTixZQUFVLE1BQU07QUFDZCxRQUFJVSxXQUFXO0FBQ2IsVUFBSSxDQUFDQSxVQUFXO0FBQ2hCVCxZQUFNZSxRQUFRLHVCQUF1QjtBQUFBLElBQ3ZDO0FBQUEsRUFDRixHQUFHLENBQUNOLFNBQVMsQ0FBQztBQUVkLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLHVJQUNiO0FBQUEsMkJBQUMsU0FBSSxXQUFVLGNBQ2IsaUNBQUMsU0FBSSxXQUFVLDhCQUNiO0FBQUEsNkJBQUMsT0FBRSx1QkFBSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQVU7QUFBQSxNQUNWLHVCQUFDLE9BQUUseUNBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE0QjtBQUFBLFNBRjlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQSxLQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FLQTtBQUFBLElBQ0EsdUJBQUMsU0FBSSxXQUFVLDRDQUNiO0FBQUE7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLFNBQVNFO0FBQUFBLFVBQ1QsVUFBVSxDQUFDUixRQUFRLENBQUNDLHFCQUFxQkk7QUFBQUEsVUFDekMsV0FBVTtBQUFBLFVBRVRGLDJCQUFpQixjQUFjO0FBQUE7QUFBQSxRQUxsQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFNQTtBQUFBLE1BRUNFLGFBQ0MsdUJBQUMsU0FBSSxXQUFVLHVGQUNiLGlDQUFDLGFBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFRLEtBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FaSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBY0E7QUFBQSxJQUVDQyxhQUNDLHVCQUFDLFNBQUksV0FBVSxnSkFDYjtBQUFBLDZCQUFDLE9BQUUsV0FBVSw4QkFBNkIsOEJBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBd0Q7QUFBQSxNQUN4RCx1QkFBQyxPQUFFLFdBQVUsK0NBQStDSCw0QkFBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUEyRTtBQUFBLFNBRjdFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQTtBQUFBLE9BM0JKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E2QkE7QUFFSjtBQUFFSSxHQW5FV1IsZUFBYTtBQUFBYyxLQUFiZDtBQUFhLElBQUFjO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VFZmZlY3QiLCJ0b2FzdCIsIlNwaW5uZXIiLCJSZXNwb25zZXNGb3JtIiwibW9vZCIsInNlbGVjdGVkQ29sb3JOYW1lIiwic2V0QWlSZXNwb25zZSIsImFpUmVzcG9uc2VEYXRhIiwiZ2VuZXJhdGVSZXNwb25zZSIsImlzUGVuZGluZyIsImlzU3VjY2VzcyIsIl9zIiwiaGFuZGxlR2VuZXJhdGVSZXNwb25zZSIsInBhcmFtcyIsInJlc3BvbnNlIiwiY29sb3JfbmFtZSIsInN1Y2Nlc3MiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJyZXNwb25zZXNGb3JtLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB0eXBlIEdlbmVyYXRlUmVzcG9uc2VEYXRhUGFyYW1zIH0gZnJvbSAnQC9hcHAvZmVhdHVyZXMvcmVzcG9uc2VzL3R5cGVzL1Jlc3BvbnNlJztcbmltcG9ydCB7IHVzZUVmZmVjdCB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHRvYXN0IH0gZnJvbSAnc29ubmVyJztcbmltcG9ydCB7IFNwaW5uZXIgfSBmcm9tICdAL2NvbXBvbmVudHMvdWkvc3Bpbm5lcic7XG5pbXBvcnQgeyB0eXBlIFJlc3BvbnNlRm9ybVByb3BzIH0gZnJvbSAnQC9hcHAvZmVhdHVyZXMvcmVzcG9uc2VzL3R5cGVzL1Jlc3BvbnNlJztcbmV4cG9ydCBjb25zdCBSZXNwb25zZXNGb3JtID0gKHtcbiAgbW9vZCxcbiAgc2VsZWN0ZWRDb2xvck5hbWUsXG4gIHNldEFpUmVzcG9uc2UsXG4gIGFpUmVzcG9uc2VEYXRhLFxuICBnZW5lcmF0ZVJlc3BvbnNlLFxuICBpc1BlbmRpbmcsXG4gIGlzU3VjY2Vzcyxcbn06IFJlc3BvbnNlRm9ybVByb3BzKSA9PiB7XG4gIGNvbnN0IGhhbmRsZUdlbmVyYXRlUmVzcG9uc2UgPSAoKSA9PiB7XG4gICAgaWYgKGlzUGVuZGluZykgcmV0dXJuO1xuICAgIGNvbnN0IHBhcmFtczogR2VuZXJhdGVSZXNwb25zZURhdGFQYXJhbXMgPSB7XG4gICAgICByZXNwb25zZToge1xuICAgICAgICBtb29kOiBtb29kLFxuICAgICAgICBjb2xvcl9uYW1lOiBzZWxlY3RlZENvbG9yTmFtZSxcbiAgICAgIH0sXG4gICAgfTtcbiAgICAvL1xuICAgIGdlbmVyYXRlUmVzcG9uc2UocGFyYW1zKTtcbiAgfTtcbiAgLy8gQUnjgYvjgonjga7jg6zjgrnjg53jg7Pjgrnjg4fjg7zjgr/jgYzmm7TmlrDjgZXjgozjgZ/jgajjgY3jgavjgIHopqrjgrPjg7Pjg53jg7zjg43jg7Pjg4jjga7nirbmhYvjgpLmm7TmlrDjgZnjgotcbiAgLy8gSG9tZeOCs+ODs+ODneODvOODjeODs+ODiOOBp3NldEFpUmVzcG9uc2XjgpLmuKHjgZfjgabjgYTjgovjgZ/jgoHjgIHjgZPjgZPjgadBSeOBi+OCieOBruODrOOCueODneODs+OCueODh+ODvOOCv+OCkuabtOaWsOOBmeOCi+OBk+OBqOOBp+OAgUhvbWXjgrPjg7Pjg53jg7zjg43jg7Pjg4jjga7nirbmhYvjgoLmm7TmlrDjgZXjgozjgotcbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoYWlSZXNwb25zZURhdGEpIHtcbiAgICAgIHNldEFpUmVzcG9uc2UoYWlSZXNwb25zZURhdGEpO1xuICAgIH1cbiAgfSwgW2FpUmVzcG9uc2VEYXRhLCBzZXRBaVJlc3BvbnNlXSk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoaXNTdWNjZXNzKSB7XG4gICAgICBpZiAoIWlzU3VjY2VzcykgcmV0dXJuO1xuICAgICAgdG9hc3Quc3VjY2VzcygnQUnjgYvjgonjga7jg6zjgrnjg53jg7Pjgrnjga7nlJ/miJDjgavmiJDlip/jgZfjgb7jgZfjgZ/vvIEnKTtcbiAgICB9XG4gIH0sIFtpc1N1Y2Nlc3NdKTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiU1RFUDIgZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgYmctc2t5LTIwMC85MCB3LWZ1bGwgbS0yIHAtMiByb3VuZGVkLTJ4bCBzaGFkb3ctMnhsIGJvcmRlciBib3JkZXItd2hpdGUvNjAgcmVsYXRpdmVcIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiRm9ybUhlYWRlclwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgIHRleHQtY2VudGVyXCI+XG4gICAgICAgICAgPHA+flNURVAyfjwvcD5cbiAgICAgICAgICA8cD7pgbjmip7jgZfjgZ9Db2xvcuOCkuWfuuOBq0FJ44Gr44Kz44Oh44Oz44OI44KS55Sf5oiQ44KS5L6d6aC8PC9wPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBwLTQgbS00XCI+XG4gICAgICAgIDxidXR0b25cbiAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVHZW5lcmF0ZVJlc3BvbnNlfVxuICAgICAgICAgIGRpc2FibGVkPXshbW9vZCB8fCAhc2VsZWN0ZWRDb2xvck5hbWUgfHwgaXNQZW5kaW5nfVxuICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0xMCBweS00IGJnLWN5YW4tMzAwIHRleHQtd2hpdGUgcm91bmRlZC0yeGwgc2hhZG93LTJ4bCBib3JkZXItMiBib3JkZXItd2hpdGUgZm9udC1ib2xkIHRleHQteGwgZGlzYWJsZWQ6YmctZ3JheS0zMDAgaG92ZXI6c2NhbGUtMTEwIGhvdmVyOmJnLXBpbmstMzAwXCJcbiAgICAgICAgPlxuICAgICAgICAgIHthaVJlc3BvbnNlRGF0YSA/ICdBSeOCs+ODoeODs+ODiOWGjeeUn+aIkCcgOiAnQUnnlJ/miJDplovlp4snfVxuICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICB7aXNQZW5kaW5nICYmIChcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIGluc2V0LTAgYmctd2hpdGUvNjAgYmFja2Ryb3AtYmx1ci1zbSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB6LTEwXCI+XG4gICAgICAgICAgICA8U3Bpbm5lciAvPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICApfVxuICAgICAgPC9kaXY+XG5cbiAgICAgIHtpc1N1Y2Nlc3MgJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIiBzbTptYXgtdy0xLzIgdy1mdWxsIGJnLXdoaXRlLzgwIGJvcmRlciBib3JkZXItZ3JheS0yMDAgcm91bmRlZC0yeGwgc2hhZG93LTJ4bCBtLTQgcHktNCBweC04IGZsZXggZmxleC1jb2wgZ2FwLTIganVzdGlmeS1jZW50ZXIgaXRlbXMtY2VudGVyXCI+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWdyYXktNTAwIG1iLTJcIj7jgYLjgarjgZ/jgbjjga5BSeOBi+OCieOBruOCs+ODoeODs+ODiDwvcD5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ3aGl0ZXNwYWNlLXByZS1saW5lIHRleHQtc20gbGVhZGluZy1yZWxheGVkXCI+e2FpUmVzcG9uc2VEYXRhfTwvcD5cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuICAgIDwvZGl2PlxuICApO1xufTtcbiJdLCJmaWxlIjoiL1VzZXJzL2lub3VleXV1amkvQ29sb3JNaXJyb3JfUmUvZnJvbnQvQXBwX2Zyb250L3NyYy9hcHAvZmVhdHVyZXMvcmVzcG9uc2VzL2NvbXBvbmVudHMvcmVzcG9uc2VzRm9ybS50c3gifQ==