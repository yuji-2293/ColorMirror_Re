import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/app/features/colors/components/colorsIndex.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=b986c083"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import { useColors } from "/src/app/features/colors/hooks/useColors.ts";
import { useDeleteColor } from "/src/app/features/colors/hooks/useDeleteColor.ts";
import { Button } from "/src/components/ui/button.tsx";
import { toast } from "/node_modules/.vite/deps/sonner.js?v=b986c083";
export const ColorsIndex = () => {
  _s();
  const { deleteColor } = useDeleteColor();
  const handleDelete = (id) => {
    deleteColor(id);
    toast.success("履歴を削除しました！");
  };
  const { isLoading, isError, data } = useColors();
  if (isLoading) {
    return /* @__PURE__ */ jsxDEV("div", { children: "Loading..." }, void 0, false, {
      fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsIndex.tsx",
      lineNumber: 17,
      columnNumber: 12
    }, this);
  }
  if (isError) {
    return /* @__PURE__ */ jsxDEV("div", { children: "エラー、ファイル、データの確認をしてください" }, void 0, false, {
      fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsIndex.tsx",
      lineNumber: 20,
      columnNumber: 12
    }, this);
  }
  const colorsIndex = data || [];
  return /* @__PURE__ */ jsxDEV("div", { className: "bg-white/50 backdrop-blur-md px-6 py-3 rounded-2xl shadow-2xl", children: /* @__PURE__ */ jsxDEV("ul", { className: "bg-gradient rounded-2xl shadow-2xl border border-white/60 px-6 py-3", children: [
    colorsIndex.length === 0 && /* @__PURE__ */ jsxDEV("p", { className: "text-center text-gray-500", children: "まだ、あなたのデータが作られていません。気分とcolorを登録してみましょう!!" }, void 0, false, {
      fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsIndex.tsx",
      lineNumber: 32,
      columnNumber: 9
    }, this),
    colorsIndex.map(
      (color) => /* @__PURE__ */ jsxDEV(
        "li",
        {
          className: "bg-white/50 rounded-xl p-4 shadow-sm space-y-2 my-4 border border-gray-200",
          children: [
            /* @__PURE__ */ jsxDEV("div", { className: "p-2", children: /* @__PURE__ */ jsxDEV("p", { className: "text-right leading-3", children: [
              "作成日時:",
              new Date(color.createdAt).toLocaleString("ja-JP")
            ] }, void 0, true, {
              fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsIndex.tsx",
              lineNumber: 44,
              columnNumber: 15
            }, this) }, void 0, false, {
              fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsIndex.tsx",
              lineNumber: 43,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "sm:grid sm:grid-cols-2 grid-cols-1 items-center sm:px-6 sm:py-4 px-2 py-2 gap-6 border-2 border-gray-200/80 rounded-2xl shadow-2xl", children: [
              /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col items-center justify-end gap-4", children: [
                /* @__PURE__ */ jsxDEV(
                  "div",
                  {
                    className: "sm:w-30 sm:h-30 w-20 h-20 rounded-full border-2 border-white shadow-md hover:scale-110 transition-transform",
                    style: { backgroundColor: color.colorName }
                  },
                  void 0,
                  false,
                  {
                    fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsIndex.tsx",
                    lineNumber: 52,
                    columnNumber: 17
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV("div", { children: "登録したcolor" }, void 0, false, {
                  fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsIndex.tsx",
                  lineNumber: 56,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("p", { children: [
                  '登録した気分 : "',
                  color.mood,
                  '" '
                ] }, void 0, true, {
                  fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsIndex.tsx",
                  lineNumber: 57,
                  columnNumber: 17
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsIndex.tsx",
                lineNumber: 51,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "bg-white/80 p-4 rounded-xl border border-gray-200", children: [
                /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-gray-500 mb-2", children: "あなたへのAIからのコメント" }, void 0, false, {
                  fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsIndex.tsx",
                  lineNumber: 61,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV("p", { className: "text-sm leading-relaxed", children: color.response?.aiResponse ?? "AIコメントはまだ生成されていません。" }, void 0, false, {
                  fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsIndex.tsx",
                  lineNumber: 62,
                  columnNumber: 17
                }, this)
              ] }, void 0, true, {
                fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsIndex.tsx",
                lineNumber: 60,
                columnNumber: 15
              }, this)
            ] }, void 0, true, {
              fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsIndex.tsx",
              lineNumber: 50,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end", children: /* @__PURE__ */ jsxDEV(
              Button,
              {
                onClick: () => handleDelete(color.id),
                className: "font-bold text-md leading-tight  px-4 py-2 rounded-2xl border-2 border-white/50 hover:scale-110 hover:shadow-2xl transition-transform",
                style: { backgroundColor: color.colorName },
                children: "この履歴を削除"
              },
              void 0,
              false,
              {
                fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsIndex.tsx",
                lineNumber: 68,
                columnNumber: 15
              },
              this
            ) }, void 0, false, {
              fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsIndex.tsx",
              lineNumber: 67,
              columnNumber: 13
            }, this)
          ]
        },
        color.id,
        true,
        {
          fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsIndex.tsx",
          lineNumber: 39,
          columnNumber: 9
        },
        this
      )
    )
  ] }, void 0, true, {
    fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsIndex.tsx",
    lineNumber: 29,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsIndex.tsx",
    lineNumber: 26,
    columnNumber: 5
  }, this);
};
_s(ColorsIndex, "DGOIapCKu5SdBW3/IBUpNYFKUAU=", false, function() {
  return [useDeleteColor, useColors];
});
_c = ColorsIndex;
var _c;
$RefreshReg$(_c, "ColorsIndex");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsIndex.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsIndex.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsIndex.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0JXOztBQWhCWCxTQUFTQSxpQkFBaUI7QUFDMUIsU0FBU0Msc0JBQXNCO0FBQy9CLFNBQVNDLGNBQWM7QUFDdkIsU0FBU0MsYUFBYTtBQUNmLGFBQU1DLGNBQWNBLE1BQU07QUFBQUMsS0FBQTtBQUUvQixRQUFNLEVBQUVDLFlBQVksSUFBSUwsZUFBZTtBQUV2QyxRQUFNTSxlQUFlQSxDQUFDQyxPQUFlO0FBQ25DRixnQkFBWUUsRUFBRTtBQUNkTCxVQUFNTSxRQUFRLFlBQVk7QUFBQSxFQUM1QjtBQUdBLFFBQU0sRUFBRUMsV0FBV0MsU0FBU0MsS0FBSyxJQUFJWixVQUFVO0FBQy9DLE1BQUlVLFdBQVc7QUFDYixXQUFPLHVCQUFDLFNBQUksMEJBQUw7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFlO0FBQUEsRUFDeEI7QUFDQSxNQUFJQyxTQUFTO0FBQ1gsV0FBTyx1QkFBQyxTQUFJLHNDQUFMO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBMkI7QUFBQSxFQUNwQztBQUVBLFFBQU1FLGNBQWNELFFBQVE7QUFFNUIsU0FDRSx1QkFBQyxTQUFJLFdBQVUsaUVBR2IsaUNBQUMsUUFBRyxXQUFVLHVFQUVYQztBQUFBQSxnQkFBWUMsV0FBVyxLQUN0Qix1QkFBQyxPQUFFLFdBQVUsNkJBQTJCLHdEQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUlERCxZQUFZRTtBQUFBQSxNQUFJLENBQUNDLFVBQ2hCO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFFQyxXQUFVO0FBQUEsVUFFVjtBQUFBLG1DQUFDLFNBQUksV0FBVSxPQUNiLGlDQUFDLE9BQUUsV0FBVSx3QkFBc0I7QUFBQTtBQUFBLGNBRWhDLElBQUlDLEtBQUtELE1BQU1FLFNBQVMsRUFBRUMsZUFBZSxPQUFPO0FBQUEsaUJBRm5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR0EsS0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUtBO0FBQUEsWUFFQSx1QkFBQyxTQUFJLFdBQVUsc0lBQ2I7QUFBQSxxQ0FBQyxTQUFJLFdBQVUsZ0RBQ2I7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxXQUFVO0FBQUEsb0JBQ1YsT0FBTyxFQUFFQyxpQkFBaUJKLE1BQU1LLFVBQVU7QUFBQTtBQUFBLGtCQUY1QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBR0M7QUFBQSxnQkFDRCx1QkFBQyxTQUFJLHlCQUFMO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWM7QUFBQSxnQkFDZCx1QkFBQyxPQUFFO0FBQUE7QUFBQSxrQkFBV0wsTUFBTU07QUFBQUEsa0JBQUs7QUFBQSxxQkFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBMkI7QUFBQSxtQkFON0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFPQTtBQUFBLGNBRUEsdUJBQUMsU0FBSSxXQUFVLHFEQUNiO0FBQUEsdUNBQUMsT0FBRSxXQUFVLDhCQUE2Qiw4QkFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBd0Q7QUFBQSxnQkFDeEQsdUJBQUMsT0FBRSxXQUFVLDJCQUNWTixnQkFBTU8sVUFBVUMsY0FBYyx5QkFEakM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBS0E7QUFBQSxpQkFmRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWdCQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLG9CQUNiO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsU0FBUyxNQUFNakIsYUFBYVMsTUFBTVIsRUFBRTtBQUFBLGdCQUNwQyxXQUFVO0FBQUEsZ0JBQ1YsT0FBTyxFQUFFWSxpQkFBaUJKLE1BQU1LLFVBQVU7QUFBQSxnQkFBRTtBQUFBO0FBQUEsY0FIOUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBTUEsS0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVFBO0FBQUE7QUFBQTtBQUFBLFFBbkNLTCxNQUFNUjtBQUFBQSxRQURiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFxQ0E7QUFBQSxJQUNEO0FBQUEsT0FoREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWlEQSxLQXBERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBcURBO0FBRUo7QUFBRUgsR0E1RVdELGFBQVc7QUFBQSxVQUVFSCxnQkFRYUQsU0FBUztBQUFBO0FBQUF5QixLQVZuQ3JCO0FBQVcsSUFBQXFCO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VDb2xvcnMiLCJ1c2VEZWxldGVDb2xvciIsIkJ1dHRvbiIsInRvYXN0IiwiQ29sb3JzSW5kZXgiLCJfcyIsImRlbGV0ZUNvbG9yIiwiaGFuZGxlRGVsZXRlIiwiaWQiLCJzdWNjZXNzIiwiaXNMb2FkaW5nIiwiaXNFcnJvciIsImRhdGEiLCJjb2xvcnNJbmRleCIsImxlbmd0aCIsIm1hcCIsImNvbG9yIiwiRGF0ZSIsImNyZWF0ZWRBdCIsInRvTG9jYWxlU3RyaW5nIiwiYmFja2dyb3VuZENvbG9yIiwiY29sb3JOYW1lIiwibW9vZCIsInJlc3BvbnNlIiwiYWlSZXNwb25zZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbImNvbG9yc0luZGV4LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VDb2xvcnMgfSBmcm9tICdAL2FwcC9mZWF0dXJlcy9jb2xvcnMvaG9va3MvdXNlQ29sb3JzJztcbmltcG9ydCB7IHVzZURlbGV0ZUNvbG9yIH0gZnJvbSAnQC9hcHAvZmVhdHVyZXMvY29sb3JzL2hvb2tzL3VzZURlbGV0ZUNvbG9yJztcbmltcG9ydCB7IEJ1dHRvbiB9IGZyb20gJ0AvY29tcG9uZW50cy91aS9idXR0b24nO1xuaW1wb3J0IHsgdG9hc3QgfSBmcm9tICdzb25uZXInO1xuZXhwb3J0IGNvbnN0IENvbG9yc0luZGV4ID0gKCkgPT4ge1xuICAvLyDliYrpmaTjg5zjgr/jg7PjgYzjgq/jg6rjg4Pjgq/jgZXjgozjgZ/jgajjgY3jga7lh6bnkIZcbiAgY29uc3QgeyBkZWxldGVDb2xvciB9ID0gdXNlRGVsZXRlQ29sb3IoKTtcblxuICBjb25zdCBoYW5kbGVEZWxldGUgPSAoaWQ6IG51bWJlcikgPT4ge1xuICAgIGRlbGV0ZUNvbG9yKGlkKTtcbiAgICB0b2FzdC5zdWNjZXNzKCflsaXmrbTjgpLliYrpmaTjgZfjgb7jgZfjgZ/vvIEnKTtcbiAgfTtcblxuICAvLyDjg4fjg7zjgr/jga7oqq3jgb/ovrzjgb/kuK3jgoTjgqjjg6njg7zjgYznmbrnlJ/jgZfjgZ/loLTlkIjjga7ooajnpLpcbiAgY29uc3QgeyBpc0xvYWRpbmcsIGlzRXJyb3IsIGRhdGEgfSA9IHVzZUNvbG9ycygpO1xuICBpZiAoaXNMb2FkaW5nKSB7XG4gICAgcmV0dXJuIDxkaXY+TG9hZGluZy4uLjwvZGl2PjtcbiAgfVxuICBpZiAoaXNFcnJvcikge1xuICAgIHJldHVybiA8ZGl2PuOCqOODqeODvOOAgeODleOCoeOCpOODq+OAgeODh+ODvOOCv+OBrueiuuiqjeOCkuOBl+OBpuOBj+OBoOOBleOBhDwvZGl2PjtcbiAgfVxuXG4gIGNvbnN0IGNvbG9yc0luZGV4ID0gZGF0YSB8fCBbXTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUvNTAgYmFja2Ryb3AtYmx1ci1tZCBweC02IHB5LTMgcm91bmRlZC0yeGwgc2hhZG93LTJ4bFwiPlxuICAgICAgey8qIGNvbG9y44Gu5qmf6IO944KS5a6f6KOF44GZ44KL44Gf44KB44Gu44Kz44Oz44Od44O844ON44Oz44OIICovfVxuICAgICAgey8qIOWPluW+l+OBl+OBn+iJsuOBruODh+ODvOOCv+OCkuihqOekuuOBmeOCi+S+iyAqL31cbiAgICAgIDx1bCBjbGFzc05hbWU9XCJiZy1ncmFkaWVudCByb3VuZGVkLTJ4bCBzaGFkb3ctMnhsIGJvcmRlciBib3JkZXItd2hpdGUvNjAgcHgtNiBweS0zXCI+XG4gICAgICAgIHsvKiAg44OH44O844K/44GM56m644Gu54q25oWL44Gn6KGo56S644GZ44KLICovfVxuICAgICAgICB7Y29sb3JzSW5kZXgubGVuZ3RoID09PSAwICYmIChcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciB0ZXh0LWdyYXktNTAwXCI+XG4gICAgICAgICAgICDjgb7jgaDjgIHjgYLjgarjgZ/jga7jg4fjg7zjgr/jgYzkvZzjgonjgozjgabjgYTjgb7jgZvjgpPjgILmsJfliIbjgahjb2xvcuOCkueZu+mMsuOBl+OBpuOBv+OBvuOBl+OCh+OBhiEhXG4gICAgICAgICAgPC9wPlxuICAgICAgICApfVxuXG4gICAgICAgIHsvKiDjg4fjg7zjgr/jgYzlrZjlnKjjgZnjgovjgajjgY3jga9tYXDjgZfjgabooajnpLogKi99XG4gICAgICAgIHtjb2xvcnNJbmRleC5tYXAoKGNvbG9yKSA9PiAoXG4gICAgICAgICAgPGxpXG4gICAgICAgICAgICBrZXk9e2NvbG9yLmlkfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctd2hpdGUvNTAgcm91bmRlZC14bCBwLTQgc2hhZG93LXNtIHNwYWNlLXktMiBteS00IGJvcmRlciBib3JkZXItZ3JheS0yMDBcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0yXCI+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtcmlnaHQgbGVhZGluZy0zXCI+XG4gICAgICAgICAgICAgICAg5L2c5oiQ5pel5pmCOlxuICAgICAgICAgICAgICAgIHtuZXcgRGF0ZShjb2xvci5jcmVhdGVkQXQpLnRvTG9jYWxlU3RyaW5nKCdqYS1KUCcpfVxuICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzbTpncmlkIHNtOmdyaWQtY29scy0yIGdyaWQtY29scy0xIGl0ZW1zLWNlbnRlciBzbTpweC02IHNtOnB5LTQgcHgtMiBweS0yIGdhcC02IGJvcmRlci0yIGJvcmRlci1ncmF5LTIwMC84MCByb3VuZGVkLTJ4bCBzaGFkb3ctMnhsXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIganVzdGlmeS1lbmQgZ2FwLTRcIj5cbiAgICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzbTp3LTMwIHNtOmgtMzAgdy0yMCBoLTIwIHJvdW5kZWQtZnVsbCBib3JkZXItMiBib3JkZXItd2hpdGUgc2hhZG93LW1kIGhvdmVyOnNjYWxlLTExMCB0cmFuc2l0aW9uLXRyYW5zZm9ybVwiXG4gICAgICAgICAgICAgICAgICBzdHlsZT17eyBiYWNrZ3JvdW5kQ29sb3I6IGNvbG9yLmNvbG9yTmFtZSB9fVxuICAgICAgICAgICAgICAgID48L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2PueZu+mMsuOBl+OBn2NvbG9yPC9kaXY+XG4gICAgICAgICAgICAgICAgPHA+55m76Yyy44GX44Gf5rCX5YiGIDogXCJ7Y29sb3IubW9vZH1cIiA8L3A+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUvODAgcC00IHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1ncmF5LTIwMFwiPlxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1ncmF5LTUwMCBtYi0yXCI+44GC44Gq44Gf44G444GuQUnjgYvjgonjga7jgrPjg6Hjg7Pjg4g8L3A+XG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBsZWFkaW5nLXJlbGF4ZWRcIj5cbiAgICAgICAgICAgICAgICAgIHtjb2xvci5yZXNwb25zZT8uYWlSZXNwb25zZSA/PyAnQUnjgrPjg6Hjg7Pjg4jjga/jgb7jgaDnlJ/miJDjgZXjgozjgabjgYTjgb7jgZvjgpPjgIInfVxuICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWVuZFwiPlxuICAgICAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlRGVsZXRlKGNvbG9yLmlkKX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1tZCBsZWFkaW5nLXRpZ2h0ICBweC00IHB5LTIgcm91bmRlZC0yeGwgYm9yZGVyLTIgYm9yZGVyLXdoaXRlLzUwIGhvdmVyOnNjYWxlLTExMCBob3ZlcjpzaGFkb3ctMnhsIHRyYW5zaXRpb24tdHJhbnNmb3JtXCJcbiAgICAgICAgICAgICAgICBzdHlsZT17eyBiYWNrZ3JvdW5kQ29sb3I6IGNvbG9yLmNvbG9yTmFtZSB9fVxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAg44GT44Gu5bGl5q2044KS5YmK6ZmkXG4gICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9saT5cbiAgICAgICAgKSl9XG4gICAgICA8L3VsPlxuICAgIDwvZGl2PlxuICApO1xufTtcbiJdLCJmaWxlIjoiL1VzZXJzL2lub3VleXV1amkvQ29sb3JNaXJyb3JfUmUvZnJvbnQvQXBwX2Zyb250L3NyYy9hcHAvZmVhdHVyZXMvY29sb3JzL2NvbXBvbmVudHMvY29sb3JzSW5kZXgudHN4In0=