import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/private/PrivateLayout.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=b986c083"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import { Header } from "/src/components/layout/header.tsx";
import { Footer } from "/src/components/layout/footer.tsx";
import { useAuthStore } from "/src/app/store/useAuthStore.ts";
import { Outlet, Navigate, useLocation } from "/node_modules/.vite/deps/react-router-dom.js?v=b986c083";
import { Loading } from "/src/pages/public/components/Loading.tsx";
export default function PrivateLayout() {
  _s();
  const { authStatus } = useAuthStore();
  const redirectReason = useAuthStore((state) => state.redirectedReason);
  const location = useLocation();
  if (authStatus === "unknown") {
    return /* @__PURE__ */ jsxDEV(Loading, {}, void 0, false, {
      fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/pages/private/PrivateLayout.tsx",
      lineNumber: 12,
      columnNumber: 12
    }, this);
  }
  if (authStatus === "unauthenticated") {
    const toast = redirectReason ?? "login_require";
    return /* @__PURE__ */ jsxDEV(Navigate, { to: "/signIn", replace: true, state: { toast, from: location.pathname } }, void 0, false, {
      fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/pages/private/PrivateLayout.tsx",
      lineNumber: 18,
      columnNumber: 12
    }, this);
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "min-h-screen overflow-auto", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "min-h-screen  bg-[url('/assets/topImage.png')] bg-cover bg-center", children: /* @__PURE__ */ jsxDEV("div", { className: "min-h-screen bg-white/30", children: /* @__PURE__ */ jsxDEV("div", { className: "min-h-screen flex flex-col", children: [
      /* @__PURE__ */ jsxDEV(Header, {}, void 0, false, {
        fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/pages/private/PrivateLayout.tsx",
        lineNumber: 25,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("main", { className: "flex-1 max-w-7xl w-full px-6 py-8 mx-auto overflow-auto", children: /* @__PURE__ */ jsxDEV(Outlet, {}, void 0, false, {
        fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/pages/private/PrivateLayout.tsx",
        lineNumber: 27,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/pages/private/PrivateLayout.tsx",
        lineNumber: 26,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/pages/private/PrivateLayout.tsx",
      lineNumber: 24,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/pages/private/PrivateLayout.tsx",
      lineNumber: 23,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/pages/private/PrivateLayout.tsx",
      lineNumber: 22,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Footer, {}, void 0, false, {
      fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/pages/private/PrivateLayout.tsx",
      lineNumber: 32,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/pages/private/PrivateLayout.tsx",
    lineNumber: 21,
    columnNumber: 5
  }, this);
}
_s(PrivateLayout, "B3N55a2KG1eFKrSQVhEiqjMRNh8=", false, function() {
  return [useAuthStore, useAuthStore, useLocation];
});
_c = PrivateLayout;
var _c;
$RefreshReg$(_c, "PrivateLayout");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/pages/private/PrivateLayout.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/pages/private/PrivateLayout.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/pages/private/PrivateLayout.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBV1c7O0FBWFgsU0FBU0EsY0FBYztBQUN2QixTQUFTQyxjQUFjO0FBQ3ZCLFNBQVNDLG9CQUFvQjtBQUM3QixTQUFTQyxRQUFRQyxVQUFVQyxtQkFBbUI7QUFDOUMsU0FBU0MsZUFBZTtBQUV4Qix3QkFBd0JDLGdCQUFnQjtBQUFBQyxLQUFBO0FBQ3RDLFFBQU0sRUFBRUMsV0FBVyxJQUFJUCxhQUFhO0FBQ3BDLFFBQU1RLGlCQUFpQlIsYUFBYSxDQUFDUyxVQUFVQSxNQUFNQyxnQkFBZ0I7QUFDckUsUUFBTUMsV0FBV1IsWUFBWTtBQUM3QixNQUFJSSxlQUFlLFdBQVc7QUFDNUIsV0FBTyx1QkFBQyxhQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBUTtBQUFBLEVBQ2pCO0FBQ0EsTUFBSUEsZUFBZSxtQkFBbUI7QUFFcEMsVUFBTUssUUFBUUosa0JBQWtCO0FBRWhDLFdBQU8sdUJBQUMsWUFBUyxJQUFHLFdBQVUsU0FBTyxNQUFDLE9BQU8sRUFBRUksT0FBT0MsTUFBTUYsU0FBU0csU0FBUyxLQUF2RTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXlFO0FBQUEsRUFDbEY7QUFDQSxTQUNFLHVCQUFDLFNBQUksV0FBVSw4QkFDYjtBQUFBLDJCQUFDLFNBQUksV0FBVSxxRUFDYixpQ0FBQyxTQUFJLFdBQVUsNEJBQ2IsaUNBQUMsU0FBSSxXQUFVLDhCQUNiO0FBQUEsNkJBQUMsWUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQU87QUFBQSxNQUNQLHVCQUFDLFVBQUssV0FBVSwyREFDZCxpQ0FBQyxZQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBTyxLQURUO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUtBLEtBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU9BLEtBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVNBO0FBQUEsSUFDQSx1QkFBQyxZQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBTztBQUFBLE9BWFQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVlBO0FBRUo7QUFBQ1IsR0E1QnVCRCxlQUFhO0FBQUEsVUFDWkwsY0FDQUEsY0FDTkcsV0FBVztBQUFBO0FBQUFZLEtBSE5WO0FBQWEsSUFBQVU7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIkhlYWRlciIsIkZvb3RlciIsInVzZUF1dGhTdG9yZSIsIk91dGxldCIsIk5hdmlnYXRlIiwidXNlTG9jYXRpb24iLCJMb2FkaW5nIiwiUHJpdmF0ZUxheW91dCIsIl9zIiwiYXV0aFN0YXR1cyIsInJlZGlyZWN0UmVhc29uIiwic3RhdGUiLCJyZWRpcmVjdGVkUmVhc29uIiwibG9jYXRpb24iLCJ0b2FzdCIsImZyb20iLCJwYXRobmFtZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlByaXZhdGVMYXlvdXQudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEhlYWRlciB9IGZyb20gJ0AvY29tcG9uZW50cy9sYXlvdXQvaGVhZGVyJztcbmltcG9ydCB7IEZvb3RlciB9IGZyb20gJ0AvY29tcG9uZW50cy9sYXlvdXQvZm9vdGVyJztcbmltcG9ydCB7IHVzZUF1dGhTdG9yZSB9IGZyb20gJ0AvYXBwL3N0b3JlL3VzZUF1dGhTdG9yZSc7XG5pbXBvcnQgeyBPdXRsZXQsIE5hdmlnYXRlLCB1c2VMb2NhdGlvbiB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xuaW1wb3J0IHsgTG9hZGluZyB9IGZyb20gJ0AvcGFnZXMvcHVibGljL2NvbXBvbmVudHMvTG9hZGluZyc7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFByaXZhdGVMYXlvdXQoKSB7XG4gIGNvbnN0IHsgYXV0aFN0YXR1cyB9ID0gdXNlQXV0aFN0b3JlKCk7XG4gIGNvbnN0IHJlZGlyZWN0UmVhc29uID0gdXNlQXV0aFN0b3JlKChzdGF0ZSkgPT4gc3RhdGUucmVkaXJlY3RlZFJlYXNvbik7XG4gIGNvbnN0IGxvY2F0aW9uID0gdXNlTG9jYXRpb24oKTtcbiAgaWYgKGF1dGhTdGF0dXMgPT09ICd1bmtub3duJykge1xuICAgIHJldHVybiA8TG9hZGluZyAvPjtcbiAgfVxuICBpZiAoYXV0aFN0YXR1cyA9PT0gJ3VuYXV0aGVudGljYXRlZCcpIHtcbiAgICAvLyDjg6rjg4DjgqTjg6zjgq/jg4jnkIbnlLHjgavlv5zjgZjjgZ/jg4jjg7zjgrnjg4jooajnpLrjga7jgZ/jgoHjga7lpInmlbBcbiAgICBjb25zdCB0b2FzdCA9IHJlZGlyZWN0UmVhc29uID8/ICdsb2dpbl9yZXF1aXJlJztcbiAgICAvLyDoqo3oqLzjgZXjgozjgabjgYTjgarjgYTloLTlkIjjgIHjgrXjgqTjg7PjgqTjg7Pjg5rjg7zjgrjjgavjg6rjg4DjgqTjg6zjgq/jg4hcbiAgICByZXR1cm4gPE5hdmlnYXRlIHRvPVwiL3NpZ25JblwiIHJlcGxhY2Ugc3RhdGU9e3sgdG9hc3QsIGZyb206IGxvY2F0aW9uLnBhdGhuYW1lIH19IC8+O1xuICB9XG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJtaW4taC1zY3JlZW4gb3ZlcmZsb3ctYXV0b1wiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJtaW4taC1zY3JlZW4gIGJnLVt1cmwoJy9hc3NldHMvdG9wSW1hZ2UucG5nJyldIGJnLWNvdmVyIGJnLWNlbnRlclwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1pbi1oLXNjcmVlbiBiZy13aGl0ZS8zMFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLWgtc2NyZWVuIGZsZXggZmxleC1jb2xcIj5cbiAgICAgICAgICAgIDxIZWFkZXIgLz5cbiAgICAgICAgICAgIDxtYWluIGNsYXNzTmFtZT1cImZsZXgtMSBtYXgtdy03eGwgdy1mdWxsIHB4LTYgcHktOCBteC1hdXRvIG92ZXJmbG93LWF1dG9cIj5cbiAgICAgICAgICAgICAgPE91dGxldCAvPlxuICAgICAgICAgICAgPC9tYWluPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgICAgPEZvb3RlciAvPlxuICAgIDwvZGl2PlxuICApO1xufVxuIl0sImZpbGUiOiIvVXNlcnMvaW5vdWV5dXVqaS9Db2xvck1pcnJvcl9SZS9mcm9udC9BcHBfZnJvbnQvc3JjL3BhZ2VzL3ByaXZhdGUvUHJpdmF0ZUxheW91dC50c3gifQ==