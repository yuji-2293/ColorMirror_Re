import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/public/components/SignIn.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=b986c083"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import SignInCard from "/src/app/features/auth/components/signInCard.tsx";
export const SignIn = () => {
  return /* @__PURE__ */ jsxDEV(SignInCard, {}, void 0, false, {
    fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/pages/public/components/SignIn.tsx",
    lineNumber: 4,
    columnNumber: 10
  }, this);
};
_c = SignIn;
var _c;
$RefreshReg$(_c, "SignIn");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/pages/public/components/SignIn.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/pages/public/components/SignIn.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/pages/public/components/SignIn.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBR1M7QUFIVCxPQUFPQSxnQkFBZ0I7QUFFaEIsYUFBTUMsU0FBU0EsTUFBTTtBQUMxQixTQUFPLHVCQUFDLGdCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBVztBQUNwQjtBQUFFQyxLQUZXRDtBQUFNLElBQUFDO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJTaWduSW5DYXJkIiwiU2lnbkluIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiU2lnbkluLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgU2lnbkluQ2FyZCBmcm9tICdAL2FwcC9mZWF0dXJlcy9hdXRoL2NvbXBvbmVudHMvc2lnbkluQ2FyZCc7XG5cbmV4cG9ydCBjb25zdCBTaWduSW4gPSAoKSA9PiB7XG4gIHJldHVybiA8U2lnbkluQ2FyZCAvPjtcbn07XG4iXSwiZmlsZSI6Ii9Vc2Vycy9pbm91ZXl1dWppL0NvbG9yTWlycm9yX1JlL2Zyb250L0FwcF9mcm9udC9zcmMvcGFnZXMvcHVibGljL2NvbXBvbmVudHMvU2lnbkluLnRzeCJ9