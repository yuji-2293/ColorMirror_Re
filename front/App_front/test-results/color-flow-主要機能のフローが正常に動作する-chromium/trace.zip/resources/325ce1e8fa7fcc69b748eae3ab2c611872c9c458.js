import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/sonner.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=b986c083"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import {
  CircleCheckIcon,
  InfoIcon,
  Loader2Icon,
  OctagonXIcon,
  TriangleAlertIcon
} from "/node_modules/.vite/deps/lucide-react.js?v=b986c083";
import { useTheme } from "/node_modules/.vite/deps/next-themes.js?v=b986c083";
import { Toaster as Sonner } from "/node_modules/.vite/deps/sonner.js?v=b986c083";
const Toaster = ({ ...props }) => {
  _s();
  const { theme = "system" } = useTheme();
  return /* @__PURE__ */ jsxDEV(
    Sonner,
    {
      theme,
      className: "toaster group",
      icons: {
        success: /* @__PURE__ */ jsxDEV(CircleCheckIcon, { className: "size-4" }, void 0, false, {
          fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/components/ui/sonner.tsx",
          lineNumber: 19,
          columnNumber: 18
        }, this),
        info: /* @__PURE__ */ jsxDEV(InfoIcon, { className: "size-4" }, void 0, false, {
          fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/components/ui/sonner.tsx",
          lineNumber: 20,
          columnNumber: 15
        }, this),
        warning: /* @__PURE__ */ jsxDEV(TriangleAlertIcon, { className: "size-4" }, void 0, false, {
          fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/components/ui/sonner.tsx",
          lineNumber: 21,
          columnNumber: 18
        }, this),
        error: /* @__PURE__ */ jsxDEV(OctagonXIcon, { className: "size-4" }, void 0, false, {
          fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/components/ui/sonner.tsx",
          lineNumber: 22,
          columnNumber: 16
        }, this),
        loading: /* @__PURE__ */ jsxDEV(Loader2Icon, { className: "size-4 animate-spin" }, void 0, false, {
          fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/components/ui/sonner.tsx",
          lineNumber: 23,
          columnNumber: 18
        }, this)
      },
      style: {
        "--normal-bg": "var(--popover)",
        "--normal-text": "var(--popover-foreground)",
        "--normal-border": "var(--border)",
        "--border-radius": "var(--radius)"
      },
      ...props
    },
    void 0,
    false,
    {
      fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/components/ui/sonner.tsx",
      lineNumber: 15,
      columnNumber: 5
    },
    this
  );
};
_s(Toaster, "bbCbBsvL7+LiaR8ofHlkcwveh/Y=", false, function() {
  return [useTheme];
});
_c = Toaster;
export { Toaster };
var _c;
$RefreshReg$(_c, "Toaster");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/components/ui/sonner.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/components/ui/sonner.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/components/ui/sonner.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0JpQjs7QUFsQmpCO0FBQUEsRUFDRUE7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQUNQLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxXQUFXQyxjQUFpQztBQUVyRCxNQUFNRCxVQUFVQSxDQUFDLEVBQUUsR0FBR0UsTUFBb0IsTUFBTTtBQUFBQyxLQUFBO0FBQzlDLFFBQU0sRUFBRUMsUUFBUSxTQUFTLElBQUlMLFNBQVM7QUFFdEMsU0FDRTtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0M7QUFBQSxNQUNBLFdBQVU7QUFBQSxNQUNWLE9BQU87QUFBQSxRQUNMTSxTQUFTLHVCQUFDLG1CQUFnQixXQUFVLFlBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbUM7QUFBQSxRQUM1Q0MsTUFBTSx1QkFBQyxZQUFTLFdBQVUsWUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE0QjtBQUFBLFFBQ2xDQyxTQUFTLHVCQUFDLHFCQUFrQixXQUFVLFlBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBcUM7QUFBQSxRQUM5Q0MsT0FBTyx1QkFBQyxnQkFBYSxXQUFVLFlBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0M7QUFBQSxRQUN2Q0MsU0FBUyx1QkFBQyxlQUFZLFdBQVUseUJBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNEM7QUFBQSxNQUN2RDtBQUFBLE1BQ0EsT0FDRTtBQUFBLFFBQ0UsZUFBZTtBQUFBLFFBQ2YsaUJBQWlCO0FBQUEsUUFDakIsbUJBQW1CO0FBQUEsUUFDbkIsbUJBQW1CO0FBQUEsTUFDckI7QUFBQSxNQUVGLEdBQUlQO0FBQUFBO0FBQUFBLElBbEJOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQWtCWTtBQUdoQjtBQUFFQyxHQXpCSUgsU0FBTztBQUFBLFVBQ2tCRCxRQUFRO0FBQUE7QUFBQVcsS0FEakNWO0FBMkJOLFNBQVNBO0FBQVUsSUFBQVU7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIkNpcmNsZUNoZWNrSWNvbiIsIkluZm9JY29uIiwiTG9hZGVyMkljb24iLCJPY3RhZ29uWEljb24iLCJUcmlhbmdsZUFsZXJ0SWNvbiIsInVzZVRoZW1lIiwiVG9hc3RlciIsIlNvbm5lciIsInByb3BzIiwiX3MiLCJ0aGVtZSIsInN1Y2Nlc3MiLCJpbmZvIiwid2FybmluZyIsImVycm9yIiwibG9hZGluZyIsIl9jIiwiJFJlZnJlc2hSZWckIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbInNvbm5lci50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcbiAgQ2lyY2xlQ2hlY2tJY29uLFxuICBJbmZvSWNvbixcbiAgTG9hZGVyMkljb24sXG4gIE9jdGFnb25YSWNvbixcbiAgVHJpYW5nbGVBbGVydEljb24sXG59IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XG5pbXBvcnQgeyB1c2VUaGVtZSB9IGZyb20gJ25leHQtdGhlbWVzJztcbmltcG9ydCB7IFRvYXN0ZXIgYXMgU29ubmVyLCB0eXBlIFRvYXN0ZXJQcm9wcyB9IGZyb20gJ3Nvbm5lcic7XG5cbmNvbnN0IFRvYXN0ZXIgPSAoeyAuLi5wcm9wcyB9OiBUb2FzdGVyUHJvcHMpID0+IHtcbiAgY29uc3QgeyB0aGVtZSA9ICdzeXN0ZW0nIH0gPSB1c2VUaGVtZSgpO1xuXG4gIHJldHVybiAoXG4gICAgPFNvbm5lclxuICAgICAgdGhlbWU9e3RoZW1lIGFzIFRvYXN0ZXJQcm9wc1sndGhlbWUnXX1cbiAgICAgIGNsYXNzTmFtZT1cInRvYXN0ZXIgZ3JvdXBcIlxuICAgICAgaWNvbnM9e3tcbiAgICAgICAgc3VjY2VzczogPENpcmNsZUNoZWNrSWNvbiBjbGFzc05hbWU9XCJzaXplLTRcIiAvPixcbiAgICAgICAgaW5mbzogPEluZm9JY29uIGNsYXNzTmFtZT1cInNpemUtNFwiIC8+LFxuICAgICAgICB3YXJuaW5nOiA8VHJpYW5nbGVBbGVydEljb24gY2xhc3NOYW1lPVwic2l6ZS00XCIgLz4sXG4gICAgICAgIGVycm9yOiA8T2N0YWdvblhJY29uIGNsYXNzTmFtZT1cInNpemUtNFwiIC8+LFxuICAgICAgICBsb2FkaW5nOiA8TG9hZGVyMkljb24gY2xhc3NOYW1lPVwic2l6ZS00IGFuaW1hdGUtc3BpblwiIC8+LFxuICAgICAgfX1cbiAgICAgIHN0eWxlPXtcbiAgICAgICAge1xuICAgICAgICAgICctLW5vcm1hbC1iZyc6ICd2YXIoLS1wb3BvdmVyKScsXG4gICAgICAgICAgJy0tbm9ybWFsLXRleHQnOiAndmFyKC0tcG9wb3Zlci1mb3JlZ3JvdW5kKScsXG4gICAgICAgICAgJy0tbm9ybWFsLWJvcmRlcic6ICd2YXIoLS1ib3JkZXIpJyxcbiAgICAgICAgICAnLS1ib3JkZXItcmFkaXVzJzogJ3ZhcigtLXJhZGl1cyknLFxuICAgICAgICB9IGFzIFJlYWN0LkNTU1Byb3BlcnRpZXNcbiAgICAgIH1cbiAgICAgIHsuLi5wcm9wc31cbiAgICAvPlxuICApO1xufTtcblxuZXhwb3J0IHsgVG9hc3RlciB9O1xuIl0sImZpbGUiOiIvVXNlcnMvaW5vdWV5dXVqaS9Db2xvck1pcnJvcl9SZS9mcm9udC9BcHBfZnJvbnQvc3JjL2NvbXBvbmVudHMvdWkvc29ubmVyLnRzeCJ9