import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/private/components/Home.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=b986c083"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import { ColorsForm } from "/src/app/features/colors/components/colorsForm.tsx?t=1788535207862";
import __vite__cjsImport2_react from "/node_modules/.vite/deps/react.js?v=b986c083"; const useCallback = __vite__cjsImport2_react["useCallback"]; const useState = __vite__cjsImport2_react["useState"];
import { ResponsesForm } from "/src/app/features/responses/components/responsesForm.tsx";
import { CreateForm } from "/src/app/features/responses/components/createForm.tsx";
import { ColorsFormCard } from "/src/app/features/colors/components/colorsFormCard.tsx";
import { ColorsIndex } from "/src/app/features/colors/components/colorsIndex.tsx";
import { useGenerateResponse } from "/src/app/features/responses/hooks/useGenerateResponse.ts";
import { useGenerateColor } from "/src/app/features/colors/hooks/useGenerateColors.ts";
export const Home = () => {
  _s();
  const [mood, setMood] = useState("");
  const [selectedColorName, setSelectedColorName] = useState("");
  const [aiResponse, setAiResponse] = useState("");
  const resetAll = useCallback(() => {
    setMood("");
    setSelectedColorName("");
    setAiResponse("");
  }, []);
  const { resetAiResponseData, aiResponseData, generateResponse, isPending, isSuccess } = useGenerateResponse();
  const {
    generateColor,
    generatedColor,
    resetColors,
    isPending: colorPending,
    isSuccess: colorSuccess
  } = useGenerateColor();
  return /* @__PURE__ */ jsxDEV("div", { className: "w-full flex flex-col items-center justify-center gap-4", children: [
    /* @__PURE__ */ jsxDEV(ColorsFormCard, { children: [
      /* @__PURE__ */ jsxDEV(
        ColorsForm,
        {
          mood,
          setMood,
          selectedColorName,
          setSelectedColorName,
          generateColor,
          generatedColor,
          resetColors,
          isPending: colorPending,
          isSuccess: colorSuccess,
          isLoading: false
        },
        void 0,
        false,
        {
          fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/pages/private/components/Home.tsx",
          lineNumber: 38,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        ResponsesForm,
        {
          mood,
          selectedColorName,
          setAiResponse,
          aiResponseData,
          generateResponse,
          isPending,
          isSuccess
        },
        void 0,
        false,
        {
          fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/pages/private/components/Home.tsx",
          lineNumber: 51,
          columnNumber: 9
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(
        CreateForm,
        {
          mood,
          selectedColorName,
          aiResponse,
          setMood,
          setSelectedColorName,
          setAiResponse,
          resetAll,
          resetAiResponseData,
          resetColors,
          aiResponseData,
          generateResponse,
          isPending,
          isSuccess
        },
        void 0,
        false,
        {
          fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/pages/private/components/Home.tsx",
          lineNumber: 61,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/pages/private/components/Home.tsx",
      lineNumber: 37,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(ColorsIndex, {}, void 0, false, {
      fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/pages/private/components/Home.tsx",
      lineNumber: 77,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/pages/private/components/Home.tsx",
    lineNumber: 36,
    columnNumber: 5
  }, this);
};
_s(Home, "ss3i9b7LrOpLArM7L7bxmpEQBDg=", false, function() {
  return [useGenerateResponse, useGenerateColor];
});
_c = Home;
var _c;
$RefreshReg$(_c, "Home");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/pages/private/components/Home.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/pages/private/components/Home.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/pages/private/components/Home.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUNROztBQXJDUixTQUFTQSxrQkFBa0I7QUFDM0IsU0FBU0MsYUFBYUMsZ0JBQWdCO0FBQ3RDLFNBQVNDLHFCQUFxQjtBQUM5QixTQUFTQyxrQkFBa0I7QUFDM0IsU0FBU0Msc0JBQXNCO0FBQy9CLFNBQVNDLG1CQUFtQjtBQUM1QixTQUFTQywyQkFBMkI7QUFFcEMsU0FBU0Msd0JBQXdCO0FBQzFCLGFBQU1DLE9BQU9BLE1BQU07QUFBQUMsS0FBQTtBQUV4QixRQUFNLENBQUNDLE1BQU1DLE9BQU8sSUFBSVYsU0FBaUIsRUFBRTtBQUMzQyxRQUFNLENBQUNXLG1CQUFtQkMsb0JBQW9CLElBQUlaLFNBQWlCLEVBQUU7QUFDckUsUUFBTSxDQUFDYSxZQUFZQyxhQUFhLElBQUlkLFNBQWlCLEVBQUU7QUFHdkQsUUFBTWUsV0FBV2hCLFlBQVksTUFBTTtBQUNqQ1csWUFBUSxFQUFFO0FBQ1ZFLHlCQUFxQixFQUFFO0FBQ3ZCRSxrQkFBYyxFQUFFO0FBQUEsRUFDbEIsR0FBRyxFQUFFO0FBR0wsUUFBTSxFQUFFRSxxQkFBcUJDLGdCQUFnQkMsa0JBQWtCQyxXQUFXQyxVQUFVLElBQ2xGZixvQkFBb0I7QUFFdEIsUUFBTTtBQUFBLElBQ0pnQjtBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBSixXQUFXSztBQUFBQSxJQUNYSixXQUFXSztBQUFBQSxFQUNiLElBQUluQixpQkFBaUI7QUFFckIsU0FDRSx1QkFBQyxTQUFJLFdBQVUsMERBQ2I7QUFBQSwyQkFBQyxrQkFDQztBQUFBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQztBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFVBQ0EsV0FBV2tCO0FBQUFBLFVBQ1gsV0FBV0M7QUFBQUEsVUFDWCxXQUFXO0FBQUE7QUFBQSxRQVZiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQVVtQjtBQUFBLE1BR25CO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQztBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBO0FBQUEsUUFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFPdUI7QUFBQSxNQUd2QjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0M7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQTtBQUFBLFFBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BYXVCO0FBQUEsU0FyQ3pCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F1Q0E7QUFBQSxJQUNBLHVCQUFDLGlCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBWTtBQUFBLE9BekNkO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0EwQ0E7QUFFSjtBQUFFakIsR0F0RVdELE1BQUk7QUFBQSxVQWViRixxQkFRRUMsZ0JBQWdCO0FBQUE7QUFBQW9CLEtBdkJUbkI7QUFBSSxJQUFBbUI7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIkNvbG9yc0Zvcm0iLCJ1c2VDYWxsYmFjayIsInVzZVN0YXRlIiwiUmVzcG9uc2VzRm9ybSIsIkNyZWF0ZUZvcm0iLCJDb2xvcnNGb3JtQ2FyZCIsIkNvbG9yc0luZGV4IiwidXNlR2VuZXJhdGVSZXNwb25zZSIsInVzZUdlbmVyYXRlQ29sb3IiLCJIb21lIiwiX3MiLCJtb29kIiwic2V0TW9vZCIsInNlbGVjdGVkQ29sb3JOYW1lIiwic2V0U2VsZWN0ZWRDb2xvck5hbWUiLCJhaVJlc3BvbnNlIiwic2V0QWlSZXNwb25zZSIsInJlc2V0QWxsIiwicmVzZXRBaVJlc3BvbnNlRGF0YSIsImFpUmVzcG9uc2VEYXRhIiwiZ2VuZXJhdGVSZXNwb25zZSIsImlzUGVuZGluZyIsImlzU3VjY2VzcyIsImdlbmVyYXRlQ29sb3IiLCJnZW5lcmF0ZWRDb2xvciIsInJlc2V0Q29sb3JzIiwiY29sb3JQZW5kaW5nIiwiY29sb3JTdWNjZXNzIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiSG9tZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ29sb3JzRm9ybSB9IGZyb20gJ0AvYXBwL2ZlYXR1cmVzL2NvbG9ycy9jb21wb25lbnRzL2NvbG9yc0Zvcm0nO1xuaW1wb3J0IHsgdXNlQ2FsbGJhY2ssIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgUmVzcG9uc2VzRm9ybSB9IGZyb20gJ0AvYXBwL2ZlYXR1cmVzL3Jlc3BvbnNlcy9jb21wb25lbnRzL3Jlc3BvbnNlc0Zvcm0nO1xuaW1wb3J0IHsgQ3JlYXRlRm9ybSB9IGZyb20gJ0AvYXBwL2ZlYXR1cmVzL3Jlc3BvbnNlcy9jb21wb25lbnRzL2NyZWF0ZUZvcm0nO1xuaW1wb3J0IHsgQ29sb3JzRm9ybUNhcmQgfSBmcm9tICdAL2FwcC9mZWF0dXJlcy9jb2xvcnMvY29tcG9uZW50cy9jb2xvcnNGb3JtQ2FyZCc7XG5pbXBvcnQgeyBDb2xvcnNJbmRleCB9IGZyb20gJ0AvYXBwL2ZlYXR1cmVzL2NvbG9ycy9jb21wb25lbnRzL2NvbG9yc0luZGV4JztcbmltcG9ydCB7IHVzZUdlbmVyYXRlUmVzcG9uc2UgfSBmcm9tICdAL2FwcC9mZWF0dXJlcy9yZXNwb25zZXMvaG9va3MvdXNlR2VuZXJhdGVSZXNwb25zZSc7XG5cbmltcG9ydCB7IHVzZUdlbmVyYXRlQ29sb3IgfSBmcm9tICdAL2FwcC9mZWF0dXJlcy9jb2xvcnMvaG9va3MvdXNlR2VuZXJhdGVDb2xvcnMnO1xuZXhwb3J0IGNvbnN0IEhvbWUgPSAoKSA9PiB7XG4gIC8vIG1vb2TjgIFzZWxlY3RlZENvbG9yTmFtZeOAgWFpUmVzcG9uc2Xjga4z44Gk44Gu54q25oWL44KS566h55CG44GZ44KL44Gf44KB44GudXNlU3RhdGXjg5Xjg4Pjgq/jgpLlrprnvqnjgZnjgovjgILjgZPjgozjgonjga7nirbmhYvjga/jgIHjg6bjg7zjgrbjg7zjgYzlhaXlipvjgZfjgZ/jg6Djg7zjg4njgoTpgbjmip7jgZfjgZ/oibLjga7lkI3liY3jgIFBSeOBi+OCieOBruODrOOCueODneODs+OCueOCkuS/neWtmOOBmeOCi+OBn+OCgeOBq+S9v+eUqOOBleOCjOOCi+OAglxuICBjb25zdCBbbW9vZCwgc2V0TW9vZF0gPSB1c2VTdGF0ZTxzdHJpbmc+KCcnKTtcbiAgY29uc3QgW3NlbGVjdGVkQ29sb3JOYW1lLCBzZXRTZWxlY3RlZENvbG9yTmFtZV0gPSB1c2VTdGF0ZTxzdHJpbmc+KCcnKTtcbiAgY29uc3QgW2FpUmVzcG9uc2UsIHNldEFpUmVzcG9uc2VdID0gdXNlU3RhdGU8c3RyaW5nPignJyk7XG5cbiAgLy8gcmVzZXTplqLmlbDjgpLlrprnvqnjgZnjgovjgIJyZXNldOmWouaVsOOBr+OAgeODleOCqeODvOODoOOBrueKtuaFi+OCkuWIneacn+eKtuaFi+OBq+ODquOCu+ODg+ODiOOBmeOCi+OBn+OCgeOBrumWouaVsOOBp+OBguOCi+OAgnVzZUNhbGxiYWNr44KS5L2/55So44GX44Gm44CB44Kz44Oz44Od44O844ON44Oz44OI44GM5YaN44Os44Oz44OA44Oq44Oz44Kw44GV44KM44Gm44KC5ZCM44GY6Zai5pWw44Kk44Oz44K544K/44Oz44K544GM5L2/55So44GV44KM44KL44KI44GG44Gr44GZ44KL44CCXG4gIGNvbnN0IHJlc2V0QWxsID0gdXNlQ2FsbGJhY2soKCkgPT4ge1xuICAgIHNldE1vb2QoJycpO1xuICAgIHNldFNlbGVjdGVkQ29sb3JOYW1lKCcnKTtcbiAgICBzZXRBaVJlc3BvbnNlKCcnKTtcbiAgfSwgW10pO1xuXG4gIC8vIHJlc2V06Zai5pWw44KS5ZG844Gz5Ye644GZ44Go44CBZGF0YeOBruWApOOBjOWIneacn+eKtuaFi+OBq+ODquOCu+ODg+ODiOOBleOCjOOCi1xuICBjb25zdCB7IHJlc2V0QWlSZXNwb25zZURhdGEsIGFpUmVzcG9uc2VEYXRhLCBnZW5lcmF0ZVJlc3BvbnNlLCBpc1BlbmRpbmcsIGlzU3VjY2VzcyB9ID1cbiAgICB1c2VHZW5lcmF0ZVJlc3BvbnNlKCk7XG4gIC8vIHVzZUdlbmVyYXRlUmVzcG9uc2Xjgqvjgrnjgr/jg6Djg5Xjg4Pjgq/jgYvjgonjgIFyZXNldEFpUmVzcG9uc2VEYXRh6Zai5pWw44CBYWlSZXNwb25zZURhdGHjgIFnZW5lcmF0ZVJlc3BvbnNl6Zai5pWw44CBaXNQZW5kaW5n44OV44Op44Kw44CB44GK44KI44GzaXNTdWNjZXNz44OV44Op44Kw44KS5Y+W5b6X44GZ44KL44CC44GT44KM44KJ44Gv44CBQUnjgYvjgonjga7jg6zjgrnjg53jg7Pjgrnjga7nlJ/miJDjgajnrqHnkIbjgavkvb/nlKjjgZXjgozjgovjgIJcbiAgY29uc3Qge1xuICAgIGdlbmVyYXRlQ29sb3IsXG4gICAgZ2VuZXJhdGVkQ29sb3IsXG4gICAgcmVzZXRDb2xvcnMsXG4gICAgaXNQZW5kaW5nOiBjb2xvclBlbmRpbmcsXG4gICAgaXNTdWNjZXNzOiBjb2xvclN1Y2Nlc3MsXG4gIH0gPSB1c2VHZW5lcmF0ZUNvbG9yKCk7XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtNFwiPlxuICAgICAgPENvbG9yc0Zvcm1DYXJkPlxuICAgICAgICA8Q29sb3JzRm9ybVxuICAgICAgICAgIG1vb2Q9e21vb2R9XG4gICAgICAgICAgc2V0TW9vZD17c2V0TW9vZH1cbiAgICAgICAgICBzZWxlY3RlZENvbG9yTmFtZT17c2VsZWN0ZWRDb2xvck5hbWV9XG4gICAgICAgICAgc2V0U2VsZWN0ZWRDb2xvck5hbWU9e3NldFNlbGVjdGVkQ29sb3JOYW1lfVxuICAgICAgICAgIGdlbmVyYXRlQ29sb3I9e2dlbmVyYXRlQ29sb3J9XG4gICAgICAgICAgZ2VuZXJhdGVkQ29sb3I9e2dlbmVyYXRlZENvbG9yfVxuICAgICAgICAgIHJlc2V0Q29sb3JzPXtyZXNldENvbG9yc31cbiAgICAgICAgICBpc1BlbmRpbmc9e2NvbG9yUGVuZGluZ31cbiAgICAgICAgICBpc1N1Y2Nlc3M9e2NvbG9yU3VjY2Vzc31cbiAgICAgICAgICBpc0xvYWRpbmc9e2ZhbHNlfVxuICAgICAgICAvPlxuXG4gICAgICAgIDxSZXNwb25zZXNGb3JtXG4gICAgICAgICAgbW9vZD17bW9vZH1cbiAgICAgICAgICBzZWxlY3RlZENvbG9yTmFtZT17c2VsZWN0ZWRDb2xvck5hbWV9XG4gICAgICAgICAgc2V0QWlSZXNwb25zZT17c2V0QWlSZXNwb25zZX1cbiAgICAgICAgICBhaVJlc3BvbnNlRGF0YT17YWlSZXNwb25zZURhdGF9XG4gICAgICAgICAgZ2VuZXJhdGVSZXNwb25zZT17Z2VuZXJhdGVSZXNwb25zZX1cbiAgICAgICAgICBpc1BlbmRpbmc9e2lzUGVuZGluZ31cbiAgICAgICAgICBpc1N1Y2Nlc3M9e2lzU3VjY2Vzc31cbiAgICAgICAgLz5cblxuICAgICAgICA8Q3JlYXRlRm9ybVxuICAgICAgICAgIG1vb2Q9e21vb2R9XG4gICAgICAgICAgc2VsZWN0ZWRDb2xvck5hbWU9e3NlbGVjdGVkQ29sb3JOYW1lfVxuICAgICAgICAgIGFpUmVzcG9uc2U9e2FpUmVzcG9uc2V9XG4gICAgICAgICAgc2V0TW9vZD17c2V0TW9vZH1cbiAgICAgICAgICBzZXRTZWxlY3RlZENvbG9yTmFtZT17c2V0U2VsZWN0ZWRDb2xvck5hbWV9XG4gICAgICAgICAgc2V0QWlSZXNwb25zZT17c2V0QWlSZXNwb25zZX1cbiAgICAgICAgICByZXNldEFsbD17cmVzZXRBbGx9XG4gICAgICAgICAgcmVzZXRBaVJlc3BvbnNlRGF0YT17cmVzZXRBaVJlc3BvbnNlRGF0YX1cbiAgICAgICAgICByZXNldENvbG9ycz17cmVzZXRDb2xvcnN9XG4gICAgICAgICAgYWlSZXNwb25zZURhdGE9e2FpUmVzcG9uc2VEYXRhfVxuICAgICAgICAgIGdlbmVyYXRlUmVzcG9uc2U9e2dlbmVyYXRlUmVzcG9uc2V9XG4gICAgICAgICAgaXNQZW5kaW5nPXtpc1BlbmRpbmd9XG4gICAgICAgICAgaXNTdWNjZXNzPXtpc1N1Y2Nlc3N9XG4gICAgICAgIC8+XG4gICAgICA8L0NvbG9yc0Zvcm1DYXJkPlxuICAgICAgPENvbG9yc0luZGV4IC8+XG4gICAgPC9kaXY+XG4gICk7XG59O1xuIl0sImZpbGUiOiIvVXNlcnMvaW5vdWV5dXVqaS9Db2xvck1pcnJvcl9SZS9mcm9udC9BcHBfZnJvbnQvc3JjL3BhZ2VzL3ByaXZhdGUvY29tcG9uZW50cy9Ib21lLnRzeCJ9