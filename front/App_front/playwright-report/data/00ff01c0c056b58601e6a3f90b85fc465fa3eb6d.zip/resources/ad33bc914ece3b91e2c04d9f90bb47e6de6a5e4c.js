import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=b986c083"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=b986c083"; const useEffect = __vite__cjsImport1_react["useEffect"]; const useRef = __vite__cjsImport1_react["useRef"];
import { BrowserRouter as Router, Route, Routes } from "/node_modules/.vite/deps/react-router-dom.js?v=b986c083";
import { Home } from "/src/pages/private/components/Home.tsx";
import { SignIn } from "/src/pages/public/components/SignIn.tsx";
import { SignUp } from "/src/pages/public/components/SignUp.tsx";
import PublicLayout from "/src/pages/public/PublicLayout.tsx";
import PrivateLayout from "/src/pages/private/PrivateLayout.tsx";
import { validateToken } from "/src/app/features/auth/api/auth.ts";
import { useAuthStore } from "/src/app/store/useAuthStore.ts";
import { Toaster } from "/src/components/ui/sonner.tsx";
export default function App() {
  _s();
  const { login, logout, authStatus } = useAuthStore();
  const restoreStartedRef = useRef(false);
  useEffect(() => {
    if (restoreStartedRef.current) return;
    if (authStatus !== "unknown") return;
    restoreStartedRef.current = true;
    const restoreAuth = async () => {
      try {
        const res = await validateToken();
        const user = res.data;
        login({ id: user.id, name: user.name });
      } catch {
        logout();
      }
    };
    restoreAuth();
  }, [login, logout, authStatus]);
  return /* @__PURE__ */ jsxDEV("div", { className: "App", children: [
    /* @__PURE__ */ jsxDEV(Toaster, { position: "top-right", richColors: true }, void 0, false, {
      fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/App.tsx",
      lineNumber: 42,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Router, { children: /* @__PURE__ */ jsxDEV(Routes, { children: [
      /* @__PURE__ */ jsxDEV(Route, { element: /* @__PURE__ */ jsxDEV(PublicLayout, {}, void 0, false, {
        fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/App.tsx",
        lineNumber: 46,
        columnNumber: 27
      }, this), children: [
        /* @__PURE__ */ jsxDEV(Route, { path: "signIn", element: /* @__PURE__ */ jsxDEV(SignIn, {}, void 0, false, {
          fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/App.tsx",
          lineNumber: 47,
          columnNumber: 43
        }, this) }, void 0, false, {
          fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/App.tsx",
          lineNumber: 47,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(Route, { path: "signUp", element: /* @__PURE__ */ jsxDEV(SignUp, {}, void 0, false, {
          fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/App.tsx",
          lineNumber: 48,
          columnNumber: 43
        }, this) }, void 0, false, {
          fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/App.tsx",
          lineNumber: 48,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/App.tsx",
        lineNumber: 46,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { element: /* @__PURE__ */ jsxDEV(PrivateLayout, {}, void 0, false, {
        fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/App.tsx",
        lineNumber: 51,
        columnNumber: 27
      }, this), children: /* @__PURE__ */ jsxDEV(Route, { index: true, element: /* @__PURE__ */ jsxDEV(Home, {}, void 0, false, {
        fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/App.tsx",
        lineNumber: 52,
        columnNumber: 35
      }, this) }, void 0, false, {
        fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/App.tsx",
        lineNumber: 52,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/App.tsx",
        lineNumber: 51,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "*", element: /* @__PURE__ */ jsxDEV("h1", { children: "StatusCode-404 Not Found Page" }, void 0, false, {
        fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/App.tsx",
        lineNumber: 54,
        columnNumber: 36
      }, this) }, void 0, false, {
        fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/App.tsx",
        lineNumber: 54,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/App.tsx",
      lineNumber: 44,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/App.tsx",
      lineNumber: 43,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/App.tsx",
    lineNumber: 41,
    columnNumber: 5
  }, this);
}
_s(App, "BLyszRAvUZ1Ztg5z1W8ABwN8s1o=", false, function() {
  return [useAuthStore];
});
_c = App;
var _c;
$RefreshReg$(_c, "App");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/App.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/App.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/App.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBeUNNOztBQXpDTixTQUFTQSxXQUFXQyxjQUFjO0FBQ2xDLFNBQVNDLGlCQUFpQkMsUUFBUUMsT0FBT0MsY0FBYztBQUV2RCxTQUFTQyxZQUFZO0FBQ3JCLFNBQVNDLGNBQWM7QUFDdkIsU0FBU0MsY0FBYztBQUN2QixPQUFPQyxrQkFBa0I7QUFDekIsT0FBT0MsbUJBQW1CO0FBRTFCLFNBQVNDLHFCQUFxQjtBQUU5QixTQUFTQyxvQkFBb0I7QUFFN0IsU0FBU0MsZUFBZTtBQUV4Qix3QkFBd0JDLE1BQU07QUFBQUMsS0FBQTtBQUU1QixRQUFNLEVBQUVDLE9BQU9DLFFBQVFDLFdBQVcsSUFBSU4sYUFBYTtBQUduRCxRQUFNTyxvQkFBb0JsQixPQUFPLEtBQUs7QUFHdENELFlBQVUsTUFBTTtBQUNkLFFBQUltQixrQkFBa0JDLFFBQVM7QUFDL0IsUUFBSUYsZUFBZSxVQUFXO0FBQzlCQyxzQkFBa0JDLFVBQVU7QUFFNUIsVUFBTUMsY0FBYyxZQUFZO0FBQzlCLFVBQUk7QUFDRixjQUFNQyxNQUFNLE1BQU1YLGNBQWM7QUFDaEMsY0FBTVksT0FBT0QsSUFBSUU7QUFDakJSLGNBQU0sRUFBRVMsSUFBSUYsS0FBS0UsSUFBSUMsTUFBTUgsS0FBS0csS0FBSyxDQUFDO0FBQUEsTUFDeEMsUUFBUTtBQUNOVCxlQUFPO0FBQUEsTUFDVDtBQUFBLElBQ0Y7QUFDQUksZ0JBQVk7QUFBQSxFQUNkLEdBQUcsQ0FBQ0wsT0FBT0MsUUFBUUMsVUFBVSxDQUFDO0FBQzlCLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLE9BQ2I7QUFBQSwyQkFBQyxXQUFRLFVBQVMsYUFBWSxZQUFVLFFBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBd0M7QUFBQSxJQUN4Qyx1QkFBQyxVQUNDLGlDQUFDLFVBRUM7QUFBQSw2QkFBQyxTQUFNLFNBQVMsdUJBQUMsa0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFhLEdBQzNCO0FBQUEsK0JBQUMsU0FBTSxNQUFLLFVBQVMsU0FBUyx1QkFBQyxZQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBTyxLQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXlDO0FBQUEsUUFDekMsdUJBQUMsU0FBTSxNQUFLLFVBQVMsU0FBUyx1QkFBQyxZQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBTyxLQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXlDO0FBQUEsV0FGM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFFQSx1QkFBQyxTQUFNLFNBQVMsdUJBQUMsbUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFjLEdBQzVCLGlDQUFDLFNBQU0sT0FBSyxNQUFDLFNBQVMsdUJBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQUssS0FBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUErQixLQURqQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLFNBQU0sTUFBSyxLQUFJLFNBQVMsdUJBQUMsUUFBRyw2Q0FBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlDLEtBQTFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZ0U7QUFBQSxTQVZsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBV0EsS0FaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBYUE7QUFBQSxPQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FnQkE7QUFFSjtBQUFDSCxHQTNDdUJELEtBQUc7QUFBQSxVQUVhRixZQUFZO0FBQUE7QUFBQWUsS0FGNUJiO0FBQUcsSUFBQWE7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZUVmZmVjdCIsInVzZVJlZiIsIkJyb3dzZXJSb3V0ZXIiLCJSb3V0ZXIiLCJSb3V0ZSIsIlJvdXRlcyIsIkhvbWUiLCJTaWduSW4iLCJTaWduVXAiLCJQdWJsaWNMYXlvdXQiLCJQcml2YXRlTGF5b3V0IiwidmFsaWRhdGVUb2tlbiIsInVzZUF1dGhTdG9yZSIsIlRvYXN0ZXIiLCJBcHAiLCJfcyIsImxvZ2luIiwibG9nb3V0IiwiYXV0aFN0YXR1cyIsInJlc3RvcmVTdGFydGVkUmVmIiwiY3VycmVudCIsInJlc3RvcmVBdXRoIiwicmVzIiwidXNlciIsImRhdGEiLCJpZCIsIm5hbWUiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJBcHAudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUVmZmVjdCwgdXNlUmVmIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgQnJvd3NlclJvdXRlciBhcyBSb3V0ZXIsIFJvdXRlLCBSb3V0ZXMgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcbi8vIOODpuODvOOCtuODvOiqjeiovOapn+iDveeUqOODmuODvOOCuOOCs+ODs+ODneODvOODjeODs+ODiFxuaW1wb3J0IHsgSG9tZSB9IGZyb20gJ0AvcGFnZXMvcHJpdmF0ZS9jb21wb25lbnRzL0hvbWUnO1xuaW1wb3J0IHsgU2lnbkluIH0gZnJvbSAnQC9wYWdlcy9wdWJsaWMvY29tcG9uZW50cy9TaWduSW4nO1xuaW1wb3J0IHsgU2lnblVwIH0gZnJvbSAnQC9wYWdlcy9wdWJsaWMvY29tcG9uZW50cy9TaWduVXAnO1xuaW1wb3J0IFB1YmxpY0xheW91dCBmcm9tICdAL3BhZ2VzL3B1YmxpYy9QdWJsaWNMYXlvdXQnO1xuaW1wb3J0IFByaXZhdGVMYXlvdXQgZnJvbSAnQC9wYWdlcy9wcml2YXRlL1ByaXZhdGVMYXlvdXQnO1xuLy8g6KqN6Ki85b6p5YWD5Yem55CGXG5pbXBvcnQgeyB2YWxpZGF0ZVRva2VuIH0gZnJvbSAnQC9hcHAvZmVhdHVyZXMvYXV0aC9hcGkvYXV0aCc7XG4vLyB6dXN0YW5kIOOBrueKtuaFi+euoeeQhueUqOmWouaVsFxuaW1wb3J0IHsgdXNlQXV0aFN0b3JlIH0gZnJvbSAnQC9hcHAvc3RvcmUvdXNlQXV0aFN0b3JlJztcbi8vIHRvYXN055SoVUnjga7jgqTjg7Pjg53jg7zjg4hcbmltcG9ydCB7IFRvYXN0ZXIgfSBmcm9tICdAL2NvbXBvbmVudHMvdWkvc29ubmVyJztcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gQXBwKCkge1xuICAvLyB6dXN0YW5kIOOBrueKtuaFi+euoeeQhuOBp+S9v+eUqOOBmeOCi+OBn+OCgeOBrnN0YXRl44Go6Zai5pWwXG4gIGNvbnN0IHsgbG9naW4sIGxvZ291dCwgYXV0aFN0YXR1cyB9ID0gdXNlQXV0aFN0b3JlKCk7XG5cbiAgLy8gc3RyaWN0LW1vZGUg5a++5b+c44Gu44Gf44KB44CBMuWbnuWun+ihjOOBleOCjOOBquOBhOOCiOOBhuOBq+OCrOODvOODiVxuICBjb25zdCByZXN0b3JlU3RhcnRlZFJlZiA9IHVzZVJlZihmYWxzZSk7XG5cbiAgLy8g44Ki44OX44Oq6LW35YuV5pmC44Gr6KqN6Ki85b6p5YWD5Yem55CG44KS5a6f6KGMXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKHJlc3RvcmVTdGFydGVkUmVmLmN1cnJlbnQpIHJldHVybjtcbiAgICBpZiAoYXV0aFN0YXR1cyAhPT0gJ3Vua25vd24nKSByZXR1cm47XG4gICAgcmVzdG9yZVN0YXJ0ZWRSZWYuY3VycmVudCA9IHRydWU7XG5cbiAgICBjb25zdCByZXN0b3JlQXV0aCA9IGFzeW5jICgpID0+IHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IHZhbGlkYXRlVG9rZW4oKTtcbiAgICAgICAgY29uc3QgdXNlciA9IHJlcy5kYXRhO1xuICAgICAgICBsb2dpbih7IGlkOiB1c2VyLmlkLCBuYW1lOiB1c2VyLm5hbWUgfSk7XG4gICAgICB9IGNhdGNoIHtcbiAgICAgICAgbG9nb3V0KCk7XG4gICAgICB9XG4gICAgfTtcbiAgICByZXN0b3JlQXV0aCgpO1xuICB9LCBbbG9naW4sIGxvZ291dCwgYXV0aFN0YXR1c10pO1xuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiQXBwXCI+XG4gICAgICA8VG9hc3RlciBwb3NpdGlvbj1cInRvcC1yaWdodFwiIHJpY2hDb2xvcnMgLz5cbiAgICAgIDxSb3V0ZXI+XG4gICAgICAgIDxSb3V0ZXM+XG4gICAgICAgICAgey8qIOWFrOmWi+ODrOOCpOOCouOCpuODiCAqL31cbiAgICAgICAgICA8Um91dGUgZWxlbWVudD17PFB1YmxpY0xheW91dCAvPn0+XG4gICAgICAgICAgICA8Um91dGUgcGF0aD1cInNpZ25JblwiIGVsZW1lbnQ9ezxTaWduSW4gLz59IC8+XG4gICAgICAgICAgICA8Um91dGUgcGF0aD1cInNpZ25VcFwiIGVsZW1lbnQ9ezxTaWduVXAgLz59IC8+XG4gICAgICAgICAgPC9Sb3V0ZT5cbiAgICAgICAgICB7Lyog6KqN6Ki85b6M44Gu44Os44Kk44Ki44Km44OIICovfVxuICAgICAgICAgIDxSb3V0ZSBlbGVtZW50PXs8UHJpdmF0ZUxheW91dCAvPn0+XG4gICAgICAgICAgICA8Um91dGUgaW5kZXggZWxlbWVudD17PEhvbWUgLz59IC8+XG4gICAgICAgICAgPC9Sb3V0ZT5cbiAgICAgICAgICA8Um91dGUgcGF0aD1cIipcIiBlbGVtZW50PXs8aDE+U3RhdHVzQ29kZS00MDQgTm90IEZvdW5kIFBhZ2U8L2gxPn0gLz5cbiAgICAgICAgPC9Sb3V0ZXM+XG4gICAgICA8L1JvdXRlcj5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2lub3VleXV1amkvQ29sb3JNaXJyb3JfUmUvZnJvbnQvQXBwX2Zyb250L3NyYy9BcHAudHN4In0=