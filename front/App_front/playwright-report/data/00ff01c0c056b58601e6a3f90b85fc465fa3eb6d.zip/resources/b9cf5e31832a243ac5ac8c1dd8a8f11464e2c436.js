import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/app/features/colors/components/colorsForm.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=b986c083"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
var _s = $RefreshSig$();
import {} from "/src/app/features/colors/types/Color.ts";
import {} from "/src/app/features/colors/types/Color.ts";
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=b986c083"; const useEffect = __vite__cjsImport3_react["useEffect"];
import { toast } from "/node_modules/.vite/deps/sonner.js?v=b986c083";
import { Spinner } from "/src/components/ui/spinner.tsx";
export const ColorsForm = ({
  mood,
  setMood,
  selectedColorName,
  setSelectedColorName,
  generateColor,
  generatedColor,
  resetColors,
  isPending,
  isSuccess
}) => {
  _s();
  const handleGenerateColor = () => {
    if (isPending) return;
    const generateMood = {
      mood
    };
    generateColor(generateMood);
  };
  const handleMoodSelect = (newMood) => {
    setMood(newMood);
    setSelectedColorName("");
    resetColors();
  };
  useEffect(() => {
    if (isSuccess) {
      toast.success("色の生成に成功しました！ 好きな色を選択して、次のSTEPに進みましょう!");
      setSelectedColorName("");
    }
  }, [isSuccess, setSelectedColorName]);
  return /* @__PURE__ */ jsxDEV("div", { className: "STEP1 bg-pink-200/90 w-full m-2 p-2 rounded-2xl shadow-2xl border border-white/60 relative", children: [
    isPending && /* @__PURE__ */ jsxDEV("div", { className: "absolute inset-0 bg-white/60 backdrop-blur-sm flex items-center justify-center z-10", children: /* @__PURE__ */ jsxDEV(Spinner, {}, void 0, false, {
      fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsForm.tsx",
      lineNumber: 48,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsForm.tsx",
      lineNumber: 47,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "FormHeader", children: /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col text-center", children: [
      /* @__PURE__ */ jsxDEV("p", { children: "~STEP1~" }, void 0, false, {
        fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsForm.tsx",
        lineNumber: 54,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("p", { children: "気分を入力してcolorを作成" }, void 0, false, {
        fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsForm.tsx",
        lineNumber: 55,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsForm.tsx",
      lineNumber: 53,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsForm.tsx",
      lineNumber: 52,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "FormContent flex flex-col items-center justify-center", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "sm:flex sm:justify-around sm:items-center grid grid-cols-2", children: [
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => handleMoodSelect("ワクワク"),
            className: "flex items-center justify-center rounded-xl bg-amber-300 w-30 h-10 m-5 p-5 shadow-2xl cursor-pointer border-2 border-white focus:border-gray-300 focus:border-4 active:shadow-2xl focus:scale-120 focus-rounded-2xl transition-transform hover:bg-accent",
            children: "ワクワク"
          },
          void 0,
          false,
          {
            fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsForm.tsx",
            lineNumber: 61,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => handleMoodSelect("ムカムカ"),
            className: "flex items-center justify-center rounded-xl bg-rose-500 w-30 h-10 m-5 p-5 shadow-2xl cursor-pointer border-2 border-white focus:border-gray-300 focus:border-4 active:shadow-2xl focus:scale-120 focus-rounded-2xl transition-transform hover:bg-accent",
            children: "ムカムカ"
          },
          void 0,
          false,
          {
            fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsForm.tsx",
            lineNumber: 67,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => handleMoodSelect("モヤモヤ"),
            className: "flex items-center justify-center rounded-xl bg-indigo-600 w-30 h-10 m-5 p-5 shadow-2xl cursor-pointer border-2 border-white focus:border-gray-300 focus:border-4 active:shadow-2xl focus:scale-120 focus-rounded-2xl transition-transform hover:bg-accent",
            children: "モヤモヤ"
          },
          void 0,
          false,
          {
            fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsForm.tsx",
            lineNumber: 73,
            columnNumber: 11
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: () => handleMoodSelect("ホカホカ"),
            className: "flex items-center justify-center rounded-xl bg-pink-300 w-30 h-10 m-5 p-5 shadow-2xl cursor-pointer border-2 border-white focus:border-gray-300 focus:border-4 active:shadow-2xl focus:scale-120 focus-rounded-2xl transition-transform hover:bg-accent",
            children: "ホカホカ"
          },
          void 0,
          false,
          {
            fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsForm.tsx",
            lineNumber: 79,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsForm.tsx",
        lineNumber: 60,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-around", children: /* @__PURE__ */ jsxDEV(
        "button",
        {
          className: "w-full px-12 py-3 bg-cyan-300 text-white rounded-2xl shadow-2xl border-2 border-white font-bold text-xl disabled:bg-gray-300 hover:scale-110 hover:bg-pink-300 disabled:opacity-50 disabled:cursor-not-allowed",
          onClick: handleGenerateColor,
          disabled: !mood || isPending,
          children: generatedColor.length > 0 ? "再生成" : "生成開始"
        },
        void 0,
        false,
        {
          fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsForm.tsx",
          lineNumber: 88,
          columnNumber: 11
        },
        this
      ) }, void 0, false, {
        fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsForm.tsx",
        lineNumber: 86,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsForm.tsx",
      lineNumber: 59,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center sm:justify-around justify-center flex-col text-sm leading-relaxed border-2 border-accent rounded-xl p-4 shadow-sm space-y-2 my-4", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "w-full sm:max-w-1/3 max-w-3xl m-2 p-2 text-center text-sm border-2 border-accent rounded-2xl shadow-2xl", children: [
        /* @__PURE__ */ jsxDEV("p", { children: [
          "選択中の気分:",
          mood
        ] }, void 0, true, {
          fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsForm.tsx",
          lineNumber: 102,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("p", { children: [
          "選択中のcolor:",
          selectedColorName
        ] }, void 0, true, {
          fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsForm.tsx",
          lineNumber: 106,
          columnNumber: 11
        }, this),
        selectedColorName ? /* @__PURE__ */ jsxDEV(
          "div",
          {
            className: "rounded-full sm:w-20 sm:h-20 w-10 h-10 mx-auto border-2 border-white shadow-sm",
            style: { backgroundColor: selectedColorName }
          },
          void 0,
          false,
          {
            fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsForm.tsx",
            lineNumber: 112,
            columnNumber: 11
          },
          this
        ) : /* @__PURE__ */ jsxDEV("p", { children: "`colorが未選択です`" }, void 0, false, {
          fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsForm.tsx",
          lineNumber: 117,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsForm.tsx",
        lineNumber: 101,
        columnNumber: 9
      }, this),
      isSuccess && /* @__PURE__ */ jsxDEV("div", { className: "bg-white w-full rounded-2xl shadow-2xl opacity-90 mt-4 p-2 flex flex-col sm:flex-row gap-2 justify-around items-center", children: [
        /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV("p", { className: "text-xs block sm:hidden", children: "colorを選択してください" }, void 0, false, {
          fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsForm.tsx",
          lineNumber: 125,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsForm.tsx",
          lineNumber: 124,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-around gap-2", children: generatedColor.map(
          (c) => /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col items-center gap-2", children: [
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => setSelectedColorName(c.hex),
                className: "rounded-full border border-gray-300 sm:w-30 w-10  sm:h-30 h-10 hover:scale-110 hover:shadow-2xl transition-transform",
                style: { backgroundColor: c.hex }
              },
              void 0,
              false,
              {
                fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsForm.tsx",
                lineNumber: 131,
                columnNumber: 19
              },
              this
            ),
            /* @__PURE__ */ jsxDEV("p", { className: "text-sm hidden sm:block wrap-break-word", children: c.name }, void 0, false, {
              fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsForm.tsx",
              lineNumber: 136,
              columnNumber: 19
            }, this)
          ] }, c.hex, true, {
            fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsForm.tsx",
            lineNumber: 130,
            columnNumber: 13
          }, this)
        ) }, void 0, false, {
          fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsForm.tsx",
          lineNumber: 128,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsForm.tsx",
        lineNumber: 123,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsForm.tsx",
      lineNumber: 100,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsForm.tsx",
    lineNumber: 44,
    columnNumber: 5
  }, this);
};
_s(ColorsForm, "OD7bBpZva5O2jO+Puf00hKivP7c=");
_c = ColorsForm;
var _c;
$RefreshReg$(_c, "ColorsForm");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsForm.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsForm.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) {
  return RefreshRuntime.register(type, "/Users/inoueyuuji/ColorMirror_Re/front/App_front/src/app/features/colors/components/colorsForm.tsx " + id);
}
function $RefreshSig$() {
  return RefreshRuntime.createSignatureFunctionForTransform();
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBK0NVOztBQS9DVixlQUF3QztBQUN4QyxlQUFxQztBQUNyQyxTQUFTQSxpQkFBaUI7QUFDMUIsU0FBU0MsYUFBYTtBQUN0QixTQUFTQyxlQUFlO0FBQ2pCLGFBQU1DLGFBQWFBLENBQUM7QUFBQSxFQUN6QkM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFDZSxNQUFNO0FBQUFDLEtBQUE7QUFDckIsUUFBTUMsc0JBQXNCQSxNQUFNO0FBRWhDLFFBQUlILFVBQVc7QUFFZixVQUFNSSxlQUFtQztBQUFBLE1BQ3ZDWDtBQUFBQSxJQUNGO0FBRUFJLGtCQUFjTyxZQUFZO0FBQUEsRUFDNUI7QUFHQSxRQUFNQyxtQkFBbUJBLENBQUNDLFlBQW9CO0FBQzVDWixZQUFRWSxPQUFPO0FBQ2ZWLHlCQUFxQixFQUFFO0FBQ3ZCRyxnQkFBWTtBQUFBLEVBQ2Q7QUFHQVYsWUFBVSxNQUFNO0FBQ2QsUUFBSVksV0FBVztBQUNiWCxZQUFNaUIsUUFBUSx1Q0FBdUM7QUFDckRYLDJCQUFxQixFQUFFO0FBQUEsSUFDekI7QUFBQSxFQUNGLEdBQUcsQ0FBQ0ssV0FBV0wsb0JBQW9CLENBQUM7QUFFcEMsU0FDRSx1QkFBQyxTQUFJLFdBQVUsOEZBRVpJO0FBQUFBLGlCQUNDLHVCQUFDLFNBQUksV0FBVSx1RkFDYixpQ0FBQyxhQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBUSxLQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLElBR0YsdUJBQUMsU0FBSSxXQUFVLGNBQ2IsaUNBQUMsU0FBSSxXQUFVLDZCQUNiO0FBQUEsNkJBQUMsT0FBRSx1QkFBSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQVU7QUFBQSxNQUNWLHVCQUFDLE9BQUUsK0JBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFrQjtBQUFBLFNBRnBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQSxLQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FLQTtBQUFBLElBRUEsdUJBQUMsU0FBSSxXQUFVLHlEQUNiO0FBQUEsNkJBQUMsU0FBSSxXQUFVLDhEQUNiO0FBQUE7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFNBQVMsTUFBTUssaUJBQWlCLE1BQU07QUFBQSxZQUN0QyxXQUFVO0FBQUEsWUFBMFA7QUFBQTtBQUFBLFVBRnRRO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUtBO0FBQUEsUUFDQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsU0FBUyxNQUFNQSxpQkFBaUIsTUFBTTtBQUFBLFlBQ3RDLFdBQVU7QUFBQSxZQUF5UDtBQUFBO0FBQUEsVUFGclE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBS0E7QUFBQSxRQUNBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxTQUFTLE1BQU1BLGlCQUFpQixNQUFNO0FBQUEsWUFDdEMsV0FBVTtBQUFBLFlBQTJQO0FBQUE7QUFBQSxVQUZ2UTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFLQTtBQUFBLFFBQ0E7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFNBQVMsTUFBTUEsaUJBQWlCLE1BQU07QUFBQSxZQUN0QyxXQUFVO0FBQUEsWUFBeVA7QUFBQTtBQUFBLFVBRnJRO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUtBO0FBQUEsV0F4QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXlCQTtBQUFBLE1BQ0EsdUJBQUMsU0FBSSxXQUFVLG9DQUViO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxXQUFVO0FBQUEsVUFDVixTQUFTRjtBQUFBQSxVQUNULFVBQVUsQ0FBQ1YsUUFBUU87QUFBQUEsVUFJbEJGLHlCQUFlVSxTQUFTLElBQUksUUFBUTtBQUFBO0FBQUEsUUFQdkM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BUUEsS0FWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBV0E7QUFBQSxTQXRDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBdUNBO0FBQUEsSUFFQSx1QkFBQyxTQUFJLFdBQVUsc0pBQ2I7QUFBQSw2QkFBQyxTQUFJLFdBQVUsMkdBQ2I7QUFBQSwrQkFBQyxPQUFDO0FBQUE7QUFBQSxVQUVDZjtBQUFBQSxhQUZIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFHQTtBQUFBLFFBQ0EsdUJBQUMsT0FBQztBQUFBO0FBQUEsVUFFQ0U7QUFBQUEsYUFGSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBR0E7QUFBQSxRQUVDQSxvQkFDQztBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsV0FBVTtBQUFBLFlBQ1YsT0FBTyxFQUFFYyxpQkFBaUJkLGtCQUFrQjtBQUFBO0FBQUEsVUFGOUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBR0MsSUFFRCx1QkFBQyxPQUFFLDZCQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0I7QUFBQSxXQWhCcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWtCQTtBQUFBLE1BR0NNLGFBQ0MsdUJBQUMsU0FBSSxXQUFVLDBIQUNiO0FBQUEsK0JBQUMsU0FDQyxpQ0FBQyxPQUFFLFdBQVUsMkJBQTBCLDhCQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXFELEtBRHZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBRUEsdUJBQUMsU0FBSSxXQUFVLDBDQUNaSCx5QkFBZVk7QUFBQUEsVUFBSSxDQUFDQyxNQUNuQix1QkFBQyxTQUFnQixXQUFVLG9DQUN6QjtBQUFBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsU0FBUyxNQUFNZixxQkFBcUJlLEVBQUVDLEdBQUc7QUFBQSxnQkFDekMsV0FBVTtBQUFBLGdCQUNWLE9BQU8sRUFBRUgsaUJBQWlCRSxFQUFFQyxJQUFJO0FBQUE7QUFBQSxjQUhsQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFHb0M7QUFBQSxZQUVwQyx1QkFBQyxPQUFFLFdBQVUsMkNBQTJDRCxZQUFFRSxRQUExRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUErRDtBQUFBLGVBTnZERixFQUFFQyxLQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBT0E7QUFBQSxRQUNELEtBVkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVdBO0FBQUEsV0FoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWlCQTtBQUFBLFNBeENKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0EwQ0E7QUFBQSxPQWxHRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBbUdBO0FBRUo7QUFBRVYsR0EzSVdWLFlBQVU7QUFBQXNCLEtBQVZ0QjtBQUFVLElBQUFzQjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlRWZmZWN0IiwidG9hc3QiLCJTcGlubmVyIiwiQ29sb3JzRm9ybSIsIm1vb2QiLCJzZXRNb29kIiwic2VsZWN0ZWRDb2xvck5hbWUiLCJzZXRTZWxlY3RlZENvbG9yTmFtZSIsImdlbmVyYXRlQ29sb3IiLCJnZW5lcmF0ZWRDb2xvciIsInJlc2V0Q29sb3JzIiwiaXNQZW5kaW5nIiwiaXNTdWNjZXNzIiwiX3MiLCJoYW5kbGVHZW5lcmF0ZUNvbG9yIiwiZ2VuZXJhdGVNb29kIiwiaGFuZGxlTW9vZFNlbGVjdCIsIm5ld01vb2QiLCJzdWNjZXNzIiwibGVuZ3RoIiwiYmFja2dyb3VuZENvbG9yIiwibWFwIiwiYyIsImhleCIsIm5hbWUiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJjb2xvcnNGb3JtLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB0eXBlIEdlbmVyYXRlTW9vZFBhcmFtcyB9IGZyb20gJ0AvYXBwL2ZlYXR1cmVzL2NvbG9ycy90eXBlcy9Db2xvcic7XG5pbXBvcnQgeyB0eXBlIENvbG9yc0Zvcm1Qcm9wcyB9IGZyb20gJ0AvYXBwL2ZlYXR1cmVzL2NvbG9ycy90eXBlcy9Db2xvcic7XG5pbXBvcnQgeyB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB0b2FzdCB9IGZyb20gJ3Nvbm5lcic7XG5pbXBvcnQgeyBTcGlubmVyIH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL3NwaW5uZXInO1xuZXhwb3J0IGNvbnN0IENvbG9yc0Zvcm0gPSAoe1xuICBtb29kLFxuICBzZXRNb29kLFxuICBzZWxlY3RlZENvbG9yTmFtZSxcbiAgc2V0U2VsZWN0ZWRDb2xvck5hbWUsXG4gIGdlbmVyYXRlQ29sb3IsXG4gIGdlbmVyYXRlZENvbG9yLFxuICByZXNldENvbG9ycyxcbiAgaXNQZW5kaW5nLFxuICBpc1N1Y2Nlc3MsXG59OiBDb2xvcnNGb3JtUHJvcHMpID0+IHtcbiAgY29uc3QgaGFuZGxlR2VuZXJhdGVDb2xvciA9ICgpID0+IHtcbiAgICAvLyDnlJ/miJDkuK3jga7loLTlkIjjga/jgq/jg6rjg4Pjgq/jgpLnhKHlirnjgavjgZnjgotcbiAgICBpZiAoaXNQZW5kaW5nKSByZXR1cm47XG4gICAgLy8gcGFyYW1z44KS5L2c5oiQ44GX44GmQVBJ44Oq44Kv44Ko44K544OI44KS6YCB44KLXG4gICAgY29uc3QgZ2VuZXJhdGVNb29kOiBHZW5lcmF0ZU1vb2RQYXJhbXMgPSB7XG4gICAgICBtb29kOiBtb29kLFxuICAgIH07XG4gICAgLy8gdGFuIFN0YWNrIFF1ZXJ544GubXV0YXRl6Zai5pWw44KS5ZG844Gz5Ye644GX44GmQVBJ44Oq44Kv44Ko44K544OI44KS6YCB44KLXG4gICAgZ2VuZXJhdGVDb2xvcihnZW5lcmF0ZU1vb2QpO1xuICB9O1xuXG4gIC8vIG1vb2TjgpLmm7TmlrDjgZfjgZ/jgonjgIHkvp3lrZjplqLkv4LjgavjgYLjgotBUEnpgJrkv6HjgafnlJ/miJDjgZXjgozjgZ/oibLjga7jg4fjg7zjgr/jgpLjg6rjgrvjg4Pjg4jjgZnjgotcbiAgY29uc3QgaGFuZGxlTW9vZFNlbGVjdCA9IChuZXdNb29kOiBzdHJpbmcpID0+IHtcbiAgICBzZXRNb29kKG5ld01vb2QpO1xuICAgIHNldFNlbGVjdGVkQ29sb3JOYW1lKCcnKTtcbiAgICByZXNldENvbG9ycygpO1xuICB9O1xuXG4gIC8vIOeUn+aIkOOBq+aIkOWKn+OBl+OBn+OCieOAgeODiOODvOOCueODiOmAmuefpeOCkuihqOekuuOBl+OBpuOAgemBuOaKnuOBleOCjOOBn+iJsuOBruWQjeWJjeOCkuODquOCu+ODg+ODiOOBmeOCi1xuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChpc1N1Y2Nlc3MpIHtcbiAgICAgIHRvYXN0LnN1Y2Nlc3MoJ+iJsuOBrueUn+aIkOOBq+aIkOWKn+OBl+OBvuOBl+OBn++8gSDlpb3jgY3jgaroibLjgpLpgbjmip7jgZfjgabjgIHmrKHjga5TVEVQ44Gr6YCy44G/44G+44GX44KH44GGIScpO1xuICAgICAgc2V0U2VsZWN0ZWRDb2xvck5hbWUoJycpO1xuICAgIH1cbiAgfSwgW2lzU3VjY2Vzcywgc2V0U2VsZWN0ZWRDb2xvck5hbWVdKTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiU1RFUDEgYmctcGluay0yMDAvOTAgdy1mdWxsIG0tMiBwLTIgcm91bmRlZC0yeGwgc2hhZG93LTJ4bCBib3JkZXIgYm9yZGVyLXdoaXRlLzYwIHJlbGF0aXZlXCI+XG4gICAgICB7Lyog6YCa5L+h5Lit44Gr6KGo56S644GZ44KLbG9hZGluZ+OCouODi+ODoeODvOOCt+ODp+ODsyovfVxuICAgICAge2lzUGVuZGluZyAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgaW5zZXQtMCBiZy13aGl0ZS82MCBiYWNrZHJvcC1ibHVyLXNtIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHotMTBcIj5cbiAgICAgICAgICA8U3Bpbm5lciAvPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiRm9ybUhlYWRlclwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgdGV4dC1jZW50ZXJcIj5cbiAgICAgICAgICA8cD5+U1RFUDF+PC9wPlxuICAgICAgICAgIDxwPuawl+WIhuOCkuWFpeWKm+OBl+OBpmNvbG9y44KS5L2c5oiQPC9wPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIkZvcm1Db250ZW50IGZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic206ZmxleCBzbTpqdXN0aWZ5LWFyb3VuZCBzbTppdGVtcy1jZW50ZXIgZ3JpZCBncmlkLWNvbHMtMlwiPlxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZU1vb2RTZWxlY3QoJ+ODr+OCr+ODr+OCrycpfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC14bCBiZy1hbWJlci0zMDAgdy0zMCBoLTEwIG0tNSBwLTUgc2hhZG93LTJ4bCBjdXJzb3ItcG9pbnRlciBib3JkZXItMiBib3JkZXItd2hpdGUgZm9jdXM6Ym9yZGVyLWdyYXktMzAwIGZvY3VzOmJvcmRlci00IGFjdGl2ZTpzaGFkb3ctMnhsIGZvY3VzOnNjYWxlLTEyMCBmb2N1cy1yb3VuZGVkLTJ4bCB0cmFuc2l0aW9uLXRyYW5zZm9ybSBob3ZlcjpiZy1hY2NlbnRcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIOODr+OCr+ODr+OCr1xuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZU1vb2RTZWxlY3QoJ+ODoOOCq+ODoOOCqycpfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC14bCBiZy1yb3NlLTUwMCB3LTMwIGgtMTAgbS01IHAtNSBzaGFkb3ctMnhsIGN1cnNvci1wb2ludGVyIGJvcmRlci0yIGJvcmRlci13aGl0ZSBmb2N1czpib3JkZXItZ3JheS0zMDAgZm9jdXM6Ym9yZGVyLTQgYWN0aXZlOnNoYWRvdy0yeGwgZm9jdXM6c2NhbGUtMTIwIGZvY3VzLXJvdW5kZWQtMnhsIHRyYW5zaXRpb24tdHJhbnNmb3JtIGhvdmVyOmJnLWFjY2VudFwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAg44Og44Kr44Og44KrXG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlTW9vZFNlbGVjdCgn44Oi44Ok44Oi44OkJyl9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciByb3VuZGVkLXhsIGJnLWluZGlnby02MDAgdy0zMCBoLTEwIG0tNSBwLTUgc2hhZG93LTJ4bCBjdXJzb3ItcG9pbnRlciBib3JkZXItMiBib3JkZXItd2hpdGUgZm9jdXM6Ym9yZGVyLWdyYXktMzAwIGZvY3VzOmJvcmRlci00IGFjdGl2ZTpzaGFkb3ctMnhsIGZvY3VzOnNjYWxlLTEyMCBmb2N1cy1yb3VuZGVkLTJ4bCB0cmFuc2l0aW9uLXRyYW5zZm9ybSBob3ZlcjpiZy1hY2NlbnRcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIOODouODpOODouODpFxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZU1vb2RTZWxlY3QoJ+ODm+OCq+ODm+OCqycpfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC14bCBiZy1waW5rLTMwMCB3LTMwIGgtMTAgbS01IHAtNSBzaGFkb3ctMnhsIGN1cnNvci1wb2ludGVyIGJvcmRlci0yIGJvcmRlci13aGl0ZSBmb2N1czpib3JkZXItZ3JheS0zMDAgZm9jdXM6Ym9yZGVyLTQgYWN0aXZlOnNoYWRvdy0yeGwgZm9jdXM6c2NhbGUtMTIwIGZvY3VzLXJvdW5kZWQtMnhsIHRyYW5zaXRpb24tdHJhbnNmb3JtIGhvdmVyOmJnLWFjY2VudFwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAg44Ob44Kr44Ob44KrXG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYXJvdW5kXCI+XG4gICAgICAgICAgey8qIOawl+WIhuOCkuWFg+OBq2NvbG9y44KS55Sf5oiQ44GZ44KL6Zai5pWw44KS5a6f6KGM44GZ44KLYnV0dG9uICovfVxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweC0xMiBweS0zIGJnLWN5YW4tMzAwIHRleHQtd2hpdGUgcm91bmRlZC0yeGwgc2hhZG93LTJ4bCBib3JkZXItMiBib3JkZXItd2hpdGUgZm9udC1ib2xkIHRleHQteGwgZGlzYWJsZWQ6YmctZ3JheS0zMDAgaG92ZXI6c2NhbGUtMTEwIGhvdmVyOmJnLXBpbmstMzAwIGRpc2FibGVkOm9wYWNpdHktNTAgZGlzYWJsZWQ6Y3Vyc29yLW5vdC1hbGxvd2VkXCJcbiAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUdlbmVyYXRlQ29sb3J9XG4gICAgICAgICAgICBkaXNhYmxlZD17IW1vb2QgfHwgaXNQZW5kaW5nfVxuICAgICAgICAgID5cbiAgICAgICAgICAgIHsvKiBnZW5lcmF0ZWRDb2xvcuOBr0FQSemAmuS/oeOBp+i/lOOBo+OBpuOBj+OCi+ODh+ODvOOCv+OBruWQjeWJjSAqL31cbiAgICAgICAgICAgIHsvKiBnZW5lcmF0ZWRDb2xvcuOBjOODh+ODvOOCv+OBqOOBl+OBpui/lOOBo+OBpuOBjeOBpuOBiuOCiuOAgemFjeWIl+OBruimgee0oOaVsOOBjO+8keOBpOS7peS4iu+8iOWtmOWcqOOBmeOCi+OBi+OBqeOBhuOBi++8ieOBp+OBguOCi+OBi+OBqeOBhuOBi+OCkuipleS+oeOBl+OBpuihqOiomOOCkuWIhuWykOOBmeOCiyAqL31cbiAgICAgICAgICAgIHtnZW5lcmF0ZWRDb2xvci5sZW5ndGggPiAwID8gJ+WGjeeUn+aIkCcgOiAn55Sf5oiQ6ZaL5aeLJ31cbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBzbTpqdXN0aWZ5LWFyb3VuZCBqdXN0aWZ5LWNlbnRlciBmbGV4LWNvbCB0ZXh0LXNtIGxlYWRpbmctcmVsYXhlZCBib3JkZXItMiBib3JkZXItYWNjZW50IHJvdW5kZWQteGwgcC00IHNoYWRvdy1zbSBzcGFjZS15LTIgbXktNFwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBzbTptYXgtdy0xLzMgbWF4LXctM3hsIG0tMiBwLTIgdGV4dC1jZW50ZXIgdGV4dC1zbSBib3JkZXItMiBib3JkZXItYWNjZW50IHJvdW5kZWQtMnhsIHNoYWRvdy0yeGxcIj5cbiAgICAgICAgICA8cD5cbiAgICAgICAgICAgIOmBuOaKnuS4reOBruawl+WIhjpcbiAgICAgICAgICAgIHttb29kfVxuICAgICAgICAgIDwvcD5cbiAgICAgICAgICA8cD5cbiAgICAgICAgICAgIOmBuOaKnuS4reOBrmNvbG9yOlxuICAgICAgICAgICAge3NlbGVjdGVkQ29sb3JOYW1lfVxuICAgICAgICAgIDwvcD5cblxuICAgICAgICAgIHtzZWxlY3RlZENvbG9yTmFtZSA/IChcbiAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicm91bmRlZC1mdWxsIHNtOnctMjAgc206aC0yMCB3LTEwIGgtMTAgbXgtYXV0byBib3JkZXItMiBib3JkZXItd2hpdGUgc2hhZG93LXNtXCJcbiAgICAgICAgICAgICAgc3R5bGU9e3sgYmFja2dyb3VuZENvbG9yOiBzZWxlY3RlZENvbG9yTmFtZSB9fVxuICAgICAgICAgICAgPjwvZGl2PlxuICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICA8cD5gY29sb3LjgYzmnKrpgbjmip7jgafjgZlgPC9wPlxuICAgICAgICAgICl9XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiDpgJrkv6HlvoznlJ/miJDjgavmiJDlip/jgZfjgZ/jgonooajnpLrjgZXjgozjgosgKi99XG4gICAgICAgIHtpc1N1Y2Nlc3MgJiYgKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctd2hpdGUgdy1mdWxsIHJvdW5kZWQtMnhsIHNoYWRvdy0yeGwgb3BhY2l0eS05MCBtdC00IHAtMiBmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IGdhcC0yIGp1c3RpZnktYXJvdW5kIGl0ZW1zLWNlbnRlclwiPlxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBibG9jayBzbTpoaWRkZW5cIj5jb2xvcuOCkumBuOaKnuOBl+OBpuOBj+OBoOOBleOBhDwvcD5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYXJvdW5kIGdhcC0yXCI+XG4gICAgICAgICAgICAgIHtnZW5lcmF0ZWRDb2xvci5tYXAoKGMpID0+IChcbiAgICAgICAgICAgICAgICA8ZGl2IGtleT17Yy5oZXh9IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNlbGVjdGVkQ29sb3JOYW1lKGMuaGV4KX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicm91bmRlZC1mdWxsIGJvcmRlciBib3JkZXItZ3JheS0zMDAgc206dy0zMCB3LTEwICBzbTpoLTMwIGgtMTAgaG92ZXI6c2NhbGUtMTEwIGhvdmVyOnNoYWRvdy0yeGwgdHJhbnNpdGlvbi10cmFuc2Zvcm1cIlxuICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyBiYWNrZ3JvdW5kQ29sb3I6IGMuaGV4IH19XG4gICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBoaWRkZW4gc206YmxvY2sgd3JhcC1icmVhay13b3JkXCI+e2MubmFtZX08L3A+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICl9XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn07XG4iXSwiZmlsZSI6Ii9Vc2Vycy9pbm91ZXl1dWppL0NvbG9yTWlycm9yX1JlL2Zyb250L0FwcF9mcm9udC9zcmMvYXBwL2ZlYXR1cmVzL2NvbG9ycy9jb21wb25lbnRzL2NvbG9yc0Zvcm0udHN4In0=